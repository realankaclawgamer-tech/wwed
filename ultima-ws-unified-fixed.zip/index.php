<?php
require_once __DIR__ . '/libs/configuration.php';
date_default_timezone_set('UTC');
$avatarBaseUrl = 'https://app.ultima.cl';
$domainNames = array_map(function($d) { return explode(' ', trim($d))[0]; }, $domain);

try {
    $pdo = new PDO(
        'mysql:host=localhost;dbname=' . $database['name'] . ';charset=utf8mb4',
        $database['username'],
        $database['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (Exception $e) {
    $pdo = null;
}

if (!empty($_SESSION['auth_code']) && !isset($_SESSION['create_pending_token'])) {
    $validCookie = true;
    if ($pdo) {
        try {
            $vstmt = $pdo->prepare("SELECT 1 FROM regular WHERE auth_code = ? LIMIT 1");
            $vstmt->execute([(string)$_SESSION['auth_code']]);
            $validCookie = (bool)$vstmt->fetchColumn();
        } catch (Exception $e) {
            $validCookie = true;
        }
    }
    if ($validCookie) {
        header('Location: /pages/dashboard');
        exit();
    }
    ultimaClearAuthCookie();
}

$showToken = false;
$pendingToken = '';
$createError = null;
$createName = '';
if (isset($_SESSION['create_pending_token'])) {
    $showToken = true;
    $pendingToken = $_SESSION['create_pending_token'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'confirm_token') {
    if (isset($_SESSION['create_pending_token'])) {
        $_SESSION['auth_code'] = $_SESSION['create_pending_token'];
        ultimaSetAuthCookie((string)$_SESSION['auth_code']);
        $_SESSION['link_id'] = $_SESSION['create_pending_link_id'];
        $_SESSION['triplehook'] = 'False';
        $_SESSION['login_method'] = 'manual';
        unset($_SESSION['create_pending_token'], $_SESSION['create_pending_link_id']);
    }
    header('Location: /pages/dashboard');
    exit();
}


if (isset($_SESSION['create_flash_error'])) {
    $createError = $_SESSION['create_flash_error'];
    $createName = $_SESSION['create_flash_name'] ?? '';
    unset($_SESSION['create_flash_error'], $_SESSION['create_flash_name']);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    $createName = trim($_POST['name'] ?? '');

    if (mb_strlen($createName) < 8 || mb_strlen($createName) > 24) {
        $createError = 'Name must be 8-24 characters';
    } elseif (!preg_match('/^[\p{L}\p{N} _.\-]+$/u', $createName)) {
        $createError = 'Name has invalid characters';
    }

    $createAvatar = null;
    if (!$createError) {
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            $createError = 'Avatar is required';
        }
    }
    if (!$createError && isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['avatar'];
        if ($f['size'] > 4 * 1024 * 1024) {
            $createError = 'Image is too large, max 4MB';
        } else {
            $inf = @getimagesize($f['tmp_name']);
            $allow = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
            if ($inf === false || !isset($allow[$inf[2]])) {
                $createError = 'Invalid image format';
            } else {
                $adir = __DIR__ . '/images/avatars';
                if (!is_dir($adir)) @mkdir($adir, 0755, true);
                $fname = bin2hex(random_bytes(16)) . '.' . $allow[$inf[2]];
                if (move_uploaded_file($f['tmp_name'], $adir . '/' . $fname)) {
                    $createAvatar = $avatarBaseUrl . '/images/avatars/' . $fname;
                } else {
                    $createError = 'Could not save image';
                }
            }
        }
    }

    if (!$createError) {
        try {
            $cpdo = $pdo;
            if (!$cpdo) throw new Exception('No DB connection');

            $ctoken = ultimaNewAuthToken($cpdo);

            $pslc = '';
            for ($i = 0; $i < 32; $i++) {
                $pslc .= random_int(0, 9);
            }

            $linkIdAttempts = 0;
            do {
                $cLinkId = random_int(100000000000, 999999999999);
                $chk = $cpdo->prepare("SELECT id FROM regular WHERE link_id = ? LIMIT 1");
                $chk->execute([$cLinkId]);
                $linkExists = $chk->rowCount() > 0;
                $linkIdAttempts++;
                if ($linkIdAttempts > 50) {
                    throw new Exception('Could not generate unique link_id');
                }
            } while ($linkExists);

            $cstmt = $cpdo->prepare("INSERT INTO regular 
                (user_id, auth_code, discord_id, discord_username, discord_avatar, last_login, link_id, privateServerLinkCode, webhook) 
                VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?)");
            $cstmt->execute([1, $ctoken, null, $createName, $createAvatar, $cLinkId, $pslc, null]);

            $_SESSION['create_pending_token'] = $ctoken;
            $_SESSION['create_pending_link_id'] = $cLinkId;
            header('Location: /');
            exit();
        } catch (Exception $e) {
            $createError = 'Could not create account';
        }
    }

    if ($createError) {
        $_SESSION['create_flash_error'] = $createError;
        $_SESSION['create_flash_name'] = $createName;
        header('Location: /');
        exit();
    }
}

try {
    if (!$pdo) throw new Exception('No DB connection');
    $pdo->exec("SET time_zone = '+00:00'");

    $totalHits = $pdo->query("SELECT COUNT(*) FROM hits")->fetchColumn();
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM regular")->fetchColumn();
    
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM hits WHERE DATE(created_at) = ?");
    $stmt->execute([$today]);
    $todayHits = $stmt->fetchColumn();
    $stmt->execute([$yesterday]);
    $yesterdayHits = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM regular WHERE DATE(created_at) = ?");
    $stmt->execute([$today]);
    $todayUsers = $stmt->fetchColumn();
    $stmt->execute([$yesterday]);
    $yesterdayUsers = $stmt->fetchColumn();
    
    $hitsPercent = $yesterdayHits > 0 ? ($todayHits / $yesterdayHits) * 100 : ($todayHits > 0 ? 100 : 0);
    $usersPercent = $yesterdayUsers > 0 ? ($todayUsers / $yesterdayUsers) * 100 : ($todayUsers > 0 ? 100 : 0);
} catch (Exception $e) {
    $totalHits = 0;
    $totalUsers = 0;
    $hitsPercent = 0;
    $usersPercent = 0;
}

$totalHitsFormatted = number_format($totalHits);
$totalUsersFormatted = number_format($totalUsers);
$hitsPercentFormatted = number_format($hitsPercent, 2) . '%';
$usersPercentFormatted = number_format($usersPercent, 2) . '%';
$hitsUp = true;
$usersUp = true;
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ULTIMA - Login Panel</title>
    <link rel="icon" type="image/png" href="/images/favicon.png">
    <link rel="apple-touch-icon" href="/images/favicon.png">
    <link href="https://fonts.googleapis.com/css2?family=Bungee&family=Outfit:wght@200;300;400;500;600&family=JetBrains+Mono:wght@400;500;700&family=Archivo+Black&family=Inter+Tight:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        html,body{width:100%;height:100%;overflow:hidden;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}
        body{font-family:'Outfit',sans-serif;background:#050506;color:#fff;display:flex;justify-content:center;align-items:center}
        canvas{position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:0}
        .glow{position:fixed;top:0;left:0;width:100vw;height:100vh;background:radial-gradient(ellipse 55% 50% at 50% 48%,rgba(150,150,160,.01) 0%,transparent 70%);pointer-events:none;z-index:1}
        .wrap{position:relative;z-index:10;text-align:center;max-width:380px;width:90%;zoom:1.25;-moz-transform:scale(1.25);-moz-transform-origin:center center}
        .logo{font-family:'Bungee',sans-serif;font-size:38px;letter-spacing:8px;color:rgba(180,185,195,.5);margin-bottom:20px;overflow:hidden;white-space:nowrap;display:inline-block;border-right:3px solid rgba(180,185,195,.5);width:0;animation:typing 1.4s cubic-bezier(0.4,0,0.2,1) .2s forwards, cursor .6s ease-in-out infinite}

        .dscan{position:relative;margin-bottom:20px;height:20px;display:flex;align-items:center;justify-content:center;gap:6px;opacity:0;animation:up .3s ease-out .05s forwards}
        .dscan-label{font-family:'Space Mono',monospace;font-size:9.5px;font-weight:400;color:rgba(255,255,255,.08);letter-spacing:.5px;white-space:nowrap}
        .dscan-track{position:relative;display:inline-block;overflow:hidden}
        .dscan-txt{font-family:'JetBrains Mono',monospace;font-size:10.5px;font-weight:400;color:rgba(255,255,255,.13);letter-spacing:1px;position:relative;display:inline-block}
        .dscan-txt::before{content:'';position:absolute;top:-2px;left:-10%;width:0;height:calc(100% + 4px);background:linear-gradient(90deg,transparent,rgba(255,255,255,.08) 40%,rgba(255,255,255,.08) 60%,transparent);animation:scanReveal 1.5s ease-out .6s forwards;z-index:0}
        .dscan-txt::after{content:'';position:absolute;top:-4px;left:-10%;width:3px;height:calc(100% + 8px);background:linear-gradient(180deg,transparent,rgba(255,255,255,.5),rgba(255,255,255,.8),rgba(255,255,255,.5),transparent);box-shadow:0 0 8px rgba(255,255,255,.4),0 0 20px rgba(255,255,255,.15);border-radius:2px;opacity:0;animation:scanBeam 1.5s ease-in-out .6s forwards;z-index:2}
        @keyframes scanBeam{0%{left:-10%;opacity:0}5%{opacity:1}85%{opacity:1}100%{left:110%;opacity:0}}
        @keyframes scanReveal{0%{width:0}100%{width:120%}}
        .dscan-glow{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:100%;height:100%;opacity:0;background:radial-gradient(ellipse at center,rgba(255,255,255,.06) 0%,transparent 70%);animation:scanGlow .4s ease-out 2.1s forwards;pointer-events:none}
        @keyframes scanGlow{0%{opacity:0;transform:translate(-50%,-50%) scale(.8)}50%{opacity:1}100%{opacity:0;transform:translate(-50%,-50%) scale(1.5)}}
        @keyframes typing{from{width:0}to{width:215px}}
        @keyframes cursor{0%,100%{border-color:rgba(180,185,195,.5)}50%{border-color:transparent}}
        .logo.done{border-color:transparent!important;animation:none;width:215px}
        .btn{width:100%;padding:13px 0;margin-top:0;background:transparent;border:1px solid rgba(255,255,255,.06);border-radius:10px;font-family:'Outfit',sans-serif;font-size:13.5px;font-weight:400;color:rgba(255,255,255,.45);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:all .3s ease;letter-spacing:.2px;position:relative;overflow:hidden}
        .btn::before{content:'';position:absolute;top:0;left:0;width:50%;height:100%;background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.015) 40%,rgba(255,255,255,.025) 50%,rgba(255,255,255,.015) 60%,transparent 100%);transform:translateX(-150%) skewX(-20deg);animation:btnFlash 6s linear infinite;animation-delay:2s;pointer-events:none}
        .btn:hover{border-color:rgba(88,101,242,.25);color:rgba(255,255,255,.7);background:rgba(88,101,242,.03)}
        .btn svg{width:16px;height:16px;fill:rgba(114,137,218,.35);transition:fill .3s}
        .btn:hover svg{fill:rgba(114,137,218,.6)}
        .btn.ld{pointer-events:none;opacity:.3}
        .btn.ld::before{display:none}
        .btn.ld svg{display:none}
        .btn.ld::after{content:'';width:14px;height:14px;border:1.5px solid transparent;border-top-color:rgba(255,255,255,.25);border-radius:50%;animation:sp .7s linear infinite}
        @keyframes sp{to{transform:rotate(360deg)}}
        @keyframes btnFlash{0%,10%{transform:translateX(-150%) skewX(-20deg)}22%{transform:translateX(300%) skewX(-20deg)}23%,100%{transform:translateX(300%) skewX(-20deg)}}
        
        .deck{margin-top:20px;position:relative;border-radius:12px;overflow:hidden;cursor:pointer}
        .stats-card{border:1px solid rgba(255,255,255,.05);border-radius:12px;background:rgba(255,255,255,.015)}
        
        .row{display:flex;align-items:center;padding:14px 16px;gap:8px;position:relative}
        .row+.row{border-top:1px solid rgba(255,255,255,.035)}
        
        .row-ico{width:20px;height:20px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
        .row-ico svg{width:18px;height:18px;fill:none;stroke:rgba(255,255,255,.3);stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
        
        .badge{font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;display:inline-flex;align-items:center;gap:3px;color:#22c55e;background:rgba(34,197,94,.1);border-radius:20px;padding:4px 10px;letter-spacing:.2px;margin-left:-4px}
        .badge .ar{width:10px;height:10px;fill:none;stroke:#22c55e;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}
        .badge.down{color:#ef4444;background:rgba(239,68,68,.1)}
        .badge.down .ar{stroke:#ef4444}
        
        .row-data{display:flex;align-items:center;gap:8px;opacity:0;transform:translateX(-8px);transition:opacity .4s ease .1s, transform .4s ease .1s}
        .deck:hover .row-data{opacity:1;transform:translateX(0)}
        
        .row-num{font-family:'Inter Tight',sans-serif;font-size:14px;font-weight:600;color:rgba(255,255,255,.7);letter-spacing:.3px}
        .row-lbl{font-family:'Inter Tight',sans-serif;font-size:11px;font-weight:500;color:rgba(255,255,255,.7);letter-spacing:.5px}
        .row:first-child .row-num,.row:first-child .row-lbl,.row:last-child .row-num,.row:last-child .row-lbl{color:rgba(255,255,255,.7)}
        
        .cover{position:absolute;top:4px;right:4px;width:69%;height:calc(100% - 8px);border-radius:8px;z-index:2;transition:transform .5s cubic-bezier(.25,.46,.45,.94),opacity .4s ease;background:rgba(6,6,8,.95);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.06);box-shadow:0 2px 12px rgba(0,0,0,.3);display:flex;flex-direction:column;justify-content:center;padding-left:14px}
        .cover::before{content:'';position:absolute;left:-1px;top:15%;width:2.5px;height:70%;border-radius:0 3px 3px 0;background:rgba(255,255,255,.08);transition:background .3s ease}
        .deck:hover .cover::before{background:transparent}
        
        .cover-lbl{font-family:'Archivo Black',sans-serif;font-size:11.5px;font-weight:400;color:rgba(255,255,255,.7);letter-spacing:1px;text-transform:uppercase;padding:14px 0;text-align:left}
        
        .deck:hover .cover{transform:translateX(100%);opacity:0}
        .deck.open .cover{transform:translateX(100%);opacity:0}
        .deck.open .row-data{opacity:1;transform:translateX(0)}
        
        .foot{margin-top:22px;font-size:11px;font-weight:300;color:rgba(255,255,255,.2)}
        .foot a{color:rgba(180,185,195,.4);text-decoration:none;transition:color .25s}
        .foot a:hover{color:rgba(180,185,195,.7)}
        .flink{background:none;border:none;padding:0;font-family:inherit;font-size:inherit;cursor:pointer;color:rgba(180,190,205,.62);transition:color .25s}
        .flink:hover{color:rgba(200,208,220,.9)}
        .btn,.deck,.foot{opacity:0;animation:up .5s ease-out forwards}
        .btn{animation-delay:.3s}
        .deck{animation-delay:.9s}
        .foot{animation-delay:1.1s}
        @keyframes up{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @media(max-width:480px){
            .wrap{max-width:340px;zoom:1.1;-moz-transform:scale(1.1);-moz-transform-origin:center center;width:92%}
            .logo{font-size:28px;letter-spacing:5px;margin-bottom:24px;border-right-width:2px}
            .dscan{margin-bottom:16px;height:18px;gap:5px}
            .dscan-label{font-size:8.5px}
            .dscan-txt{font-size:9px;letter-spacing:.6px}
            @keyframes typing{from{width:0}to{width:155px}}
            .logo.done{width:155px}
            .btn{padding:12px 0;font-size:12.5px;border-radius:8px;margin-top:0}
            .btn svg{width:14px;height:14px}
            .deck{margin-top:16px;border-radius:10px}
            .stats-card{border-radius:10px}
            .row{padding:11px 12px;gap:8px}
            .row-ico{width:18px;height:18px}
            .row-ico svg{width:16px;height:16px}
            .badge{font-size:9px;padding:3px 8px;gap:2px;border-radius:16px;margin-left:-3px}
            .badge .ar{width:8px;height:8px}
            .row-num{font-family:'Archivo Black',sans-serif;font-size:13px;font-weight:400;color:rgba(255,255,255,.7)}
            .row-lbl{font-family:'Archivo Black',sans-serif;font-size:10px;font-weight:400;color:rgba(255,255,255,.7)}
            .cover{width:69%;padding-left:12px;border-radius:6px}
            .cover-lbl{font-size:10px;padding:11px 0;letter-spacing:.8px}
            .foot{margin-top:18px;font-size:10px}
        }
        @media(max-width:360px){
            .wrap{width:95%;zoom:1.05;-moz-transform:scale(1.05);-moz-transform-origin:center center}
            .logo{font-size:24px;letter-spacing:4px}
            @keyframes typing{from{width:0}to{width:130px}}
            .logo.done{width:130px}
            .row{padding:10px 10px;gap:6px}
            .badge{font-size:8px;padding:3px 6px;border-radius:14px;margin-left:-2px}
            .cover{width:69%;padding-left:10px}
            .cover-lbl{font-size:9px;padding:10px 0}
        }

        .dc-card{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid rgba(255,255,255,.04);border-radius:10px 10px 0 0;background:transparent;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);text-decoration:none;cursor:pointer;margin:0 8px;margin-bottom:0;transition:border-color .3s ease;opacity:0;max-height:0;overflow:hidden;padding-top:0;padding-bottom:0;border-width:0;transform:translateY(10px);animation:dcSlideUp .5s cubic-bezier(.25,.46,.45,.94) .7s forwards}
        .dc-card:hover{border-color:rgba(88,101,242,.15)}
        @keyframes dcSlideUp{0%{opacity:0;max-height:0;padding-top:0;padding-bottom:0;border-width:0;transform:translateY(10px)}60%{max-height:80px;padding-top:12px;padding-bottom:12px;border-width:1px}100%{opacity:1;max-height:80px;padding-top:12px;padding-bottom:12px;border-width:1px;transform:translateY(0);overflow:visible}}
        .dc-ico{width:38px;height:38px;border-radius:8px;background:rgba(88,101,242,.15);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden}
        .dc-ico img{width:100%;height:100%;border-radius:8px;object-fit:cover}
        .dc-ico svg{width:18px;height:18px;fill:rgba(88,101,242,.5)}
        .dc-info{text-align:left;flex:1;min-width:0}
        .dc-name-row{display:flex;align-items:center;gap:6px;margin-bottom:3px}
        .dc-name{font-family:'Inter Tight',sans-serif;font-size:13px;font-weight:600;color:rgba(255,255,255,.65);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .dc-verified{font-size:11px;display:none}
        .dc-stats{display:flex;align-items:center;gap:12px}
        .dc-stat{display:flex;align-items:center;gap:4px;font-family:'JetBrains Mono',monospace;font-size:9.5px;color:rgba(255,255,255,.25);letter-spacing:.3px}
        .dc-dot{width:6px;height:6px;border-radius:50%}
        .dc-dot.on{background:#3ba55c}
        .dc-dot.off{background:rgba(255,255,255,.15)}
        @media(max-width:480px){
            .dc-card{gap:10px;border-radius:8px 8px 0 0;margin:0 6px}
            @keyframes dcSlideUp{0%{opacity:0;max-height:0;padding-top:0;padding-bottom:0;border-width:0;transform:translateY(10px)}60%{max-height:70px;padding-top:10px;padding-bottom:10px;border-width:1px}100%{opacity:1;max-height:70px;padding-top:10px;padding-bottom:10px;border-width:1px;transform:translateY(0);overflow:visible}}
            .dc-ico{width:34px;height:34px;border-radius:7px}
            .dc-ico svg{width:16px;height:16px}
            .dc-name{font-size:12px}
            .dc-stat{font-size:8.5px;gap:3px}
            .dc-dot{width:5px;height:5px}
        }
        .cm-overlay{position:fixed;inset:0;z-index:100;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(4,4,6,.45);backdrop-filter:blur(2.5px);-webkit-backdrop-filter:blur(2.5px);opacity:0;pointer-events:none;transition:opacity .35s ease}
        .cm-overlay.show{opacity:1;pointer-events:auto}
        .cm-box{position:relative;width:100%;max-width:320px;background:rgba(7,7,9,.55);border:1px solid rgba(255,255,255,.09);padding:32px 28px 26px;transform:translateY(14px) scale(.97);transition:transform .4s cubic-bezier(.25,.46,.45,.94)}
        .cm-overlay.show .cm-box{transform:translateY(0) scale(1)}
        .cm-box::before,.cm-box::after{content:'';position:absolute;width:14px;height:14px;pointer-events:none}
        .cm-box::before{top:-1px;left:-1px;border-top:1px solid rgba(255,255,255,.45);border-left:1px solid rgba(255,255,255,.45)}
        .cm-box::after{bottom:-1px;right:-1px;border-bottom:1px solid rgba(255,255,255,.45);border-right:1px solid rgba(255,255,255,.45)}
        .cm-corner{position:absolute;width:14px;height:14px;pointer-events:none}
        .cm-corner.tr{top:-1px;right:-1px;border-top:1px solid rgba(255,255,255,.45);border-right:1px solid rgba(255,255,255,.45)}
        .cm-corner.bl{bottom:-1px;left:-1px;border-bottom:1px solid rgba(255,255,255,.45);border-left:1px solid rgba(255,255,255,.45)}
        .cm-title{font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:rgba(255,255,255,.4);text-align:center;margin-bottom:24px}
        .cm-title::before{content:'// '}
        .cm-err{font-family:'JetBrains Mono',monospace;font-size:9.5px;color:rgba(239,68,68,.85);margin-bottom:18px;letter-spacing:.4px;line-height:1.5;text-align:center;text-transform:uppercase}
        .cm-err::before{content:'! '}
        .av-zone{position:relative;width:88px;height:88px;margin:0 auto 22px;border-radius:50%;cursor:pointer;border:1px solid rgba(255,255,255,.14);display:flex;align-items:center;justify-content:center;overflow:hidden;transition:all .3s ease}
        .av-zone::before{content:'';position:absolute;inset:5px;border-radius:50%;border:1px dashed rgba(255,255,255,.08);transition:border-color .3s ease;pointer-events:none}
        .av-zone:hover{border-color:rgba(255,255,255,.3)}
        .av-zone:hover::before{border-color:rgba(255,255,255,.18)}
        .av-zone.has::before{display:none}
        .av-zone img{width:100%;height:100%;object-fit:cover;display:none}
        .av-zone.has img{display:block}
        .av-ph{display:flex;flex-direction:column;align-items:center;gap:6px;pointer-events:none}
        .av-zone.has .av-ph{display:none}
        .av-ph svg{width:20px;height:20px;fill:none;stroke:rgba(255,255,255,.3);stroke-width:1.4;stroke-linecap:round;stroke-linejoin:round}
        .av-ph span{font-family:'JetBrains Mono',monospace;font-size:7.5px;color:rgba(255,255,255,.22);letter-spacing:1px}
        .av-cam{position:absolute;bottom:0;right:0;width:24px;height:24px;border-radius:50%;background:rgba(7,7,9,.95);border:1px solid rgba(255,255,255,.14);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .3s ease}
        .av-zone.has .av-cam{opacity:1}
        .av-cam svg{width:11px;height:11px;fill:none;stroke:rgba(255,255,255,.55);stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}
        .cm-fld{margin-bottom:24px}
        .cm-lbl{font-family:'JetBrains Mono',monospace;font-size:8.5px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.25);margin-bottom:8px;text-align:left}
        .cm-fld input{width:100%;padding:8px 2px;background:transparent;border:none;border-bottom:1px solid rgba(255,255,255,.12);font-family:'Outfit',sans-serif;font-size:14px;font-weight:400;color:rgba(255,255,255,.85);letter-spacing:.3px;outline:none;transition:border-color .3s ease}
        .cm-fld input::placeholder{color:rgba(255,255,255,.18)}
        .cm-fld input:focus{border-bottom-color:rgba(255,255,255,.4)}
        .cm-sbm{width:100%;padding:12px 0;background:transparent;border:1px solid rgba(255,255,255,.12);font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:500;color:rgba(255,255,255,.55);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;letter-spacing:1.5px;text-transform:uppercase;transition:all .3s ease}
        .cm-sbm svg{width:13px;height:13px;fill:none;stroke:rgba(255,255,255,.4);stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;transition:stroke .3s}
        .cm-sbm:hover{border-color:rgba(255,255,255,.3);color:rgba(255,255,255,.9);background:rgba(255,255,255,.02)}
        .cm-sbm:hover svg{stroke:rgba(255,255,255,.8)}
        .cm-sbm.ld{pointer-events:none;opacity:.4}
        .cm-sbm.ld svg{display:none}
        .cm-sbm.ld::after{content:'';width:13px;height:13px;border:1.5px solid transparent;border-top-color:rgba(255,255,255,.4);border-radius:50%;animation:sp .7s linear infinite}
        .cm-hint{font-family:'JetBrains Mono',monospace;font-size:8px;letter-spacing:1.5px;color:rgba(255,255,255,.14);text-align:center;margin-top:16px;text-transform:uppercase}
        @media(max-width:480px){
            .cm-box{max-width:300px;padding:28px 22px 22px}
            .av-zone{width:80px;height:80px}
        }
        .ts-overlay{position:fixed;inset:0;z-index:200;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(3,3,5,.92);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
        .ts-box{position:relative;width:100%;max-width:420px;background:rgba(7,7,9,.7);border:1px solid rgba(255,255,255,.1);padding:36px 30px 28px}
        .ts-box::before,.ts-box::after{content:'';position:absolute;width:16px;height:16px;pointer-events:none}
        .ts-box::before{top:-1px;left:-1px;border-top:1px solid rgba(255,255,255,.55);border-left:1px solid rgba(255,255,255,.55)}
        .ts-box::after{bottom:-1px;right:-1px;border-bottom:1px solid rgba(255,255,255,.55);border-right:1px solid rgba(255,255,255,.55)}
        .ts-corner{position:absolute;width:16px;height:16px;pointer-events:none}
        .ts-corner.tr{top:-1px;right:-1px;border-top:1px solid rgba(255,255,255,.55);border-right:1px solid rgba(255,255,255,.55)}
        .ts-corner.bl{bottom:-1px;left:-1px;border-bottom:1px solid rgba(255,255,255,.55);border-left:1px solid rgba(255,255,255,.55)}
        .ts-title{font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:rgba(255,255,255,.5);text-align:center;margin-bottom:22px}
        .ts-title::before{content:'// '}
        .ts-warn{font-family:'JetBrains Mono',monospace;font-size:9px;letter-spacing:.8px;color:rgba(255,200,80,.7);line-height:1.7;text-align:center;margin-bottom:22px;text-transform:uppercase}
        .ts-warn::before{content:'! ';color:rgba(255,200,80,.9)}
        .ts-token-wrap{position:relative;margin-bottom:16px;cursor:pointer}
        .ts-token{font-family:'JetBrains Mono',monospace;font-size:10.5px;letter-spacing:.5px;color:rgba(255,255,255,.85);word-break:break-all;line-height:1.6;padding:14px 12px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.3);filter:blur(5px);user-select:none;transition:filter .3s ease;text-align:center}
        .ts-token.revealed{filter:none;user-select:text}
        .ts-reveal-hint{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-family:'JetBrains Mono',monospace;font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,.45);pointer-events:none;transition:opacity .3s ease}
        .ts-token.revealed+.ts-reveal-hint{opacity:0}
        .ts-actions{display:flex;gap:10px;margin-bottom:20px}
        .ts-btn{flex:1;padding:9px 0;background:transparent;border:1px solid rgba(255,255,255,.1);font-family:'JetBrains Mono',monospace;font-size:9.5px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,.45);cursor:pointer;transition:all .3s ease}
        .ts-btn:hover{border-color:rgba(255,255,255,.28);color:rgba(255,255,255,.8)}
        .ts-btn.copied{border-color:rgba(80,200,120,.4);color:rgba(80,200,120,.8)}
        .ts-confirm{width:100%;padding:13px 0;background:transparent;border:1px solid rgba(255,255,255,.15);font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.6);cursor:pointer;transition:all .3s ease}
        .ts-confirm:hover{border-color:rgba(255,255,255,.35);color:rgba(255,255,255,.95);background:rgba(255,255,255,.02)}
        .ts-note{font-family:'JetBrains Mono',monospace;font-size:8px;letter-spacing:.5px;color:rgba(255,255,255,.18);text-align:center;margin-top:14px;line-height:1.5}
        @media(max-width:480px){
            .ts-box{max-width:340px;padding:28px 20px 22px}
            .ts-token{font-size:9px}
        }
    </style>
</head>
<body>
<canvas id="c"></canvas>
<div class="glow"></div>
<div class="wrap">
    <div class="dscan">
        <span class="dscan-label">Available :</span>
        <div class="dscan-track">
            <span class="dscan-txt" id="dh"><?=htmlspecialchars($domainNames[0])?></span>
            <span class="dscan-glow"></span>
        </div>
    </div>
    <h1 class="logo">ULTIMA</h1>
    <a href="https://discord.gg/JGDXgHwf3H" class="dc-card" id="dcCard" target="_blank">
        <div class="dc-ico" id="dcIco">
            <svg viewBox="0 0 127.14 96.36"><path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/></svg>
        </div>
        <div class="dc-info">
            <div class="dc-name-row">
                <span class="dc-name" id="dcName">Loading...</span>
                <span class="dc-verified" id="dcVerified">✅</span>
            </div>
            <div class="dc-stats">
                <div class="dc-stat"><span class="dc-dot on"></span><span id="dcOnline">0</span> Online</div>
                <div class="dc-stat"><span class="dc-dot off"></span><span id="dcMembers">0</span> Members</div>
            </div>
        </div>
    </a>
    <button class="btn" id="b" onclick="go()">
        <svg viewBox="0 0 127.14 96.36"><path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/></svg>
        <span>Continue with Discord</span>
    </button>
    <div class="deck">
        <div class="stats-card">
            <div class="row">
                <div class="row-ico">
                    <svg viewBox="0 0 24 24"><path d="M6 9H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h2"/><path d="M18 9h2a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-2"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>
                </div>
                <span class="badge <?php echo $hitsUp ? '' : 'down'; ?>"><svg class="ar" viewBox="0 0 24 24"><polyline points="<?php echo $hitsUp ? '18 15 12 9 6 15' : '6 9 12 15 18 9'; ?>"/></svg><span id="bpv"><?php echo $hitsPercentFormatted; ?></span></span>
                <div class="row-data">
                    <span class="row-num" id="tb">0</span>
                    <span class="row-lbl">Hits</span>
                </div>
            </div>
            <div class="row">
                <div class="row-ico">
                    <svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                </div>
                <span class="badge <?php echo $usersUp ? '' : 'down'; ?>"><svg class="ar" viewBox="0 0 24 24"><polyline points="<?php echo $usersUp ? '18 15 12 9 6 15' : '6 9 12 15 18 9'; ?>"/></svg><span id="upv"><?php echo $usersPercentFormatted; ?></span></span>
                <div class="row-data">
                    <span class="row-num" id="tu">0</span>
                    <span class="row-lbl">Users</span>
                </div>
            </div>
        </div>
        <div class="cover">
            <div class="cover-lbl">Total Accounts</div>
            <div class="cover-lbl">Total Users</div>
        </div>
    </div>
    <p class="foot">Lost access? <a href="/pages/login">Sign in with token</a> &nbsp;·&nbsp; No Discord? <button type="button" class="flink" onclick="openCreate()">Create account</button></p>
</div>
<div class="cm-overlay" id="cmOverlay">
    <div class="cm-box">
        <span class="cm-corner tr"></span>
        <span class="cm-corner bl"></span>
        <div class="cm-title">New account</div>
        <form method="post" enctype="multipart/form-data" id="cmForm" autocomplete="off" novalidate>
            <input type="hidden" name="action" value="create">
            <div class="cm-err" id="cmErr"<?php if (!$createError): ?> style="display:none"<?php endif; ?>><?=htmlspecialchars($createError)?></div>
            <div class="av-zone" id="avZone">
                <img id="avImg" alt="">
                <div class="av-ph">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c0-3.3 3.1-6 7-6s7 2.7 7 6"/></svg>
                    <span>AVATAR</span>
                </div>
                <div class="av-cam">
                    <svg viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
                </div>
                <input type="file" id="avFile" name="avatar" accept="image/png,image/jpeg,image/webp,image/gif" hidden>
            </div>
            <div class="cm-fld">
                <div class="cm-lbl">Name</div>
                <input type="text" name="name" id="cmName" placeholder="Enter your name" minlength="8" maxlength="24" value="<?=htmlspecialchars($createName)?>">
            </div>
            <button type="submit" class="cm-sbm" id="cmSbm">
                <svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Create
            </button>
        </form>
        <div class="cm-hint">esc or tap outside to close</div>
    </div>
</div>
<?php if ($showToken): ?>
<div class="ts-overlay" id="tsOverlay">
    <div class="ts-box">
        <span class="ts-corner tr"></span>
        <span class="ts-corner bl"></span>
        <div class="ts-title">Account created</div>
        <div class="ts-warn">This is the only time you will see this token.<br>Save it now — notepad, paper, anywhere safe.<br>You will need it to log in. We cannot recover it.</div>
        <div class="ts-token-wrap" onclick="revealToken()">
            <div class="ts-token" id="tsToken"><?=htmlspecialchars($pendingToken)?></div>
            <div class="ts-reveal-hint" id="tsHint">Click to reveal</div>
        </div>
        <div class="ts-actions">
            <button type="button" class="ts-btn" onclick="revealToken()" id="tsRevealBtn">Reveal</button>
            <button type="button" class="ts-btn" onclick="copyToken()" id="tsCopyBtn">Copy</button>
        </div>
        <form method="post">
            <input type="hidden" name="action" value="confirm_token">
            <button type="submit" class="ts-confirm">I&apos;ve saved my token &rarr; Go to Dashboard</button>
        </form>
        <div class="ts-note">Once you leave this page the token will not be shown again.</div>
    </div>
</div>
<?php endif; ?>
<script>
setTimeout(function(){document.querySelector('.logo').classList.add('done')},1700);

<?php if ($showToken): ?>
var tsToken=document.getElementById('tsToken'),tsHint=document.getElementById('tsHint'),tsRevealBtn=document.getElementById('tsRevealBtn'),tsCopyBtn=document.getElementById('tsCopyBtn'),tsRevealed=false;
function revealToken(){if(tsRevealed)return;tsRevealed=true;tsToken.classList.add('revealed');tsRevealBtn.textContent='Revealed';tsRevealBtn.style.opacity='.4';tsRevealBtn.style.pointerEvents='none'}
function copyToken(){
    var txt=tsToken.textContent;
    if(navigator.clipboard){navigator.clipboard.writeText(txt).then(function(){tsCopyBtn.textContent='Copied';tsCopyBtn.classList.add('copied');setTimeout(function(){tsCopyBtn.textContent='Copy';tsCopyBtn.classList.remove('copied')},2000)})}
    else{var ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);tsCopyBtn.textContent='Copied';tsCopyBtn.classList.add('copied');setTimeout(function(){tsCopyBtn.textContent='Copy';tsCopyBtn.classList.remove('copied')},2000)}
}
<?php endif; ?>

var cmOverlay=document.getElementById('cmOverlay');
function openCreate(){cmOverlay.classList.add('show')}
function closeCreate(){cmOverlay.classList.remove('show')}
cmOverlay.addEventListener('click',function(e){if(e.target===cmOverlay)closeCreate()});
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeCreate()});

var avZone=document.getElementById('avZone'),avFile=document.getElementById('avFile'),avImg=document.getElementById('avImg');
avZone.addEventListener('click',function(){avFile.click()});
avFile.addEventListener('change',function(){
    var file=this.files&&this.files[0];
    if(!file)return;
    var rd=new FileReader();
    rd.onload=function(e){avImg.src=e.target.result;avZone.classList.add('has')};
    rd.readAsDataURL(file);
});

var cmForm=document.getElementById('cmForm'),cmSbm=document.getElementById('cmSbm'),cmName=document.getElementById('cmName'),cmErr=document.getElementById('cmErr');
function showErr(m){cmErr.textContent=m;cmErr.style.display='block'}
cmName.addEventListener('input',function(){if(cmErr.textContent)cmErr.style.display='none'});
cmForm.addEventListener('submit',function(e){
    if(!avFile.files||!avFile.files[0]){e.preventDefault();showErr('Avatar is required');return}
    var v=cmName.value.trim();
    if(v.length===0){e.preventDefault();showErr('Name is empty');cmName.focus();return}
    if(v.length<8){e.preventDefault();showErr('Name must be at least 8 characters');cmName.focus();return}
    cmSbm.classList.add('ld');
    cmSbm.querySelector('svg').style.display='none';
    cmSbm.lastChild.textContent='';
});
<?php if ($createError): ?>
openCreate();
<?php endif; ?>

(async function(){
try{
var r=await fetch('https://discord.com/api/v9/invites/JGDXgHwf3H?with_counts=true&with_expiration=true');
var d=await r.json();
if(d.guild){
var g=d.guild;
document.getElementById('dcName').textContent=g.name;
if(g.icon){var ic=document.getElementById('dcIco');ic.innerHTML='<img src="https://cdn.discordapp.com/icons/'+g.id+'/'+g.icon+'.png?size=128" alt="'+g.name+'">';}
if(g.features&&g.features.includes('VERIFIED'))document.getElementById('dcVerified').style.display='inline';
if(d.approximate_presence_count)document.getElementById('dcOnline').textContent=d.approximate_presence_count.toLocaleString();
if(d.approximate_member_count)document.getElementById('dcMembers').textContent=d.approximate_member_count.toLocaleString();
}else{
document.getElementById('dcCard').style.display='none';
}
}catch(e){document.getElementById('dcCard').style.display='none';}
})();

<?php if (count($domain) > 1): ?>
var dms=<?=json_encode(array_values($domainNames))?>,di=0,dh=document.getElementById('dh');
function glitchSwap(){
    di=(di+1)%dms.length;
    var chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789./-';
    var target=dms[di],steps=6,step=0;
    var iv=setInterval(function(){
        step++;
        if(step>=steps){clearInterval(iv);dh.textContent=target;return}
        var t='';
        for(var i=0;i<target.length;i++){
            t+=Math.random()<step/steps?target[i]:chars[Math.floor(Math.random()*chars.length)]
        }
        dh.textContent=t
    },60)
}
setInterval(glitchSwap,5000);
<?php endif; ?>

var deck = document.querySelector('.deck');
var isMobile = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
var counted = false;

function startCount(){
    if(counted) return;
    counted = true;
    av(document.getElementById('tb'), <?php echo $totalHits; ?>);
    av(document.getElementById('tu'), <?php echo $totalUsers; ?>);
}

if(isMobile){
    deck.addEventListener('click', function(){
        this.classList.toggle('open');
        startCount();
    });
} else {
    deck.addEventListener('mouseenter', function(){
        startCount();
    });
}

var CID='1462060640201084958',RU=encodeURIComponent(location.origin+'/pages/auth'),OA='https://discord.com/api/oauth2/authorize?client_id='+CID+'&redirect_uri='+RU+'&response_type=code&scope=identify';
function go(){var b=document.getElementById('b');b.classList.add('ld');b.querySelector('span').textContent='Redirecting...';setTimeout(function(){location.href=OA},400)}
function av(el,to){var fr=0;if(fr===to){el.textContent=to.toLocaleString();return}var st=performance.now();function t(n){var p=Math.min((n-st)/1400,1);el.textContent=Math.floor(fr+(to-fr)*(1-Math.pow(1-p,3))).toLocaleString();if(p<1)requestAnimationFrame(t)}requestAnimationFrame(t)}

var cv=document.getElementById('c'),cx=cv.getContext('2d'),W,H,af,MB=innerWidth<768;
function rz(){W=cv.width=innerWidth;H=cv.height=innerHeight}
rz();
var stars=[],nodes=[],SN=MB?80:150,NN=MB?10:18;
for(var i=0;i<SN;i++)stars.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1+.2,ba:Math.random()*.35+.1,a:0,sp:Math.random()*.01+.003,of:Math.random()*6.28,dx:(Math.random()-.5)*.05,dy:(Math.random()-.5)*.05,w:Math.random()<.65});
for(var i=0;i<NN;i++)nodes.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.5,vy:(Math.random()-.5)*.5});
function dist(a,b){var dx=a.x-b.x,dy=a.y-b.y;return Math.sqrt(dx*dx+dy*dy)}
function anim(t){
cx.fillStyle='rgba(5,5,6,0.18)';
cx.fillRect(0,0,W,H);
for(var i=0;i<stars.length;i++){var s=stars[i];s.x+=s.dx;s.y+=s.dy;if(s.x<0)s.x=W;if(s.x>W)s.x=0;if(s.y<0)s.y=H;if(s.y>H)s.y=0;s.a=s.ba+Math.sin(t*s.sp+s.of)*.12;cx.beginPath();cx.arc(s.x,s.y,s.r,0,6.28);if(s.w)cx.fillStyle='rgba(150,150,160,'+Math.max(0,s.a*.7)+')';else cx.fillStyle='rgba(160,160,170,'+Math.max(0,s.a)+')';cx.fill()}
for(var i=0;i<nodes.length;i++){var n=nodes[i];n.x+=n.vx;n.y+=n.vy;if(n.x<0||n.x>W)n.vx*=-1;if(n.y<0||n.y>H)n.vy*=-1;n.x=Math.max(0,Math.min(W,n.x));n.y=Math.max(0,Math.min(H,n.y))}
var md=MB?130:180,cc=0,mc=MB?25:50;
for(var i=0;i<nodes.length&&cc<mc;i++){for(var j=i+1;j<nodes.length&&cc<mc;j++){var d=dist(nodes[i],nodes[j]);if(d<md){cc++;var op=(1-d/md)*.18;cx.strokeStyle='rgba(120,120,130,'+op+')';cx.lineWidth=.5;cx.beginPath();cx.moveTo(nodes[i].x,nodes[i].y);var mx=nodes[i].x+(nodes[j].x-nodes[i].x)*.5,my=nodes[i].y+(nodes[j].y-nodes[i].y)*.5,off=(Math.random()-.5)*4;cx.lineTo(mx+off,my+off);cx.lineTo(nodes[j].x,nodes[j].y);cx.stroke()}}}
for(var i=0;i<nodes.length;i++){var n=nodes[i];cx.beginPath();cx.arc(n.x,n.y,MB?1:1.3,0,6.28);cx.fillStyle='rgba(130,130,140,.15)';cx.fill()}
af=requestAnimationFrame(anim)}
var rt;addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(function(){cancelAnimationFrame(af);rz();for(var i=0;i<stars.length;i++){stars[i].x=Math.random()*W;stars[i].y=Math.random()*H}for(var i=0;i<nodes.length;i++){nodes[i].x=Math.random()*W;nodes[i].y=Math.random()*H}anim(0)},120)});
anim(0);
</script>
</body>
</html>
<?php
$_html = ob_get_clean();
$_SESSION['enc_master_key'] = random_bytes(32);
$_eKey = $_SESSION['enc_master_key'];
$_eToken = 'ot_' . bin2hex(random_bytes(32));
$_tokenRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: ($_SERVER['DOCUMENT_ROOT'] ?? __DIR__);
$_tokenFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'ultima_chrome_tokens_' . substr(hash('sha256', $_tokenRoot), 0, 16) . '.json';
$_tokenHandle = @fopen($_tokenFile, 'c+');
if ($_tokenHandle) {
    if (@flock($_tokenHandle, LOCK_EX)) {
        $_tokenRaw = stream_get_contents($_tokenHandle);
        $_tokenData = json_decode($_tokenRaw, true);
        if (!is_array($_tokenData)) $_tokenData = [];
        $_tokenData[hash('sha256', $_eToken)] = ['key' => base64_encode($_eKey), 'created' => time()];
        rewind($_tokenHandle);
        ftruncate($_tokenHandle, 0);
        fwrite($_tokenHandle, json_encode($_tokenData, JSON_UNESCAPED_SLASHES));
        fflush($_tokenHandle);
        flock($_tokenHandle, LOCK_UN);
    }
    fclose($_tokenHandle);
    @chmod($_tokenFile, 0600);
}
$_eIv = random_bytes(12);
$_eTag = '';
$_eComp = @gzdeflate($_html, 4);
if ($_eComp === false) $_eComp = $_html;
$_eData = openssl_encrypt($_eComp, 'aes-256-gcm', $_eKey, OPENSSL_RAW_DATA, $_eIv, $_eTag);
$_ePayload = base64_encode($_eIv . $_eTag . $_eData);
$_useDeflate = ($_eComp !== $_html) ? '1' : '0';
if (function_exists('ultimaStateFlush')) ultimaStateFlush();
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Ultima</title><link rel="icon" type="image/png" href="/images/favicon.png"><style>body{background:#0a0b0f;margin:0}</style></head><body><script>!function(){var t="<?php echo $_eToken; ?>",df=<?php echo $_useDeflate; ?>;crypto.subtle.generateKey({name:"RSA-OAEP",modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:"SHA-1"},true,["encrypt","decrypt"]).then(function(kp){crypto.subtle.exportKey("spki",kp.publicKey).then(function(pub){var b=new Uint8Array(pub);var s="";for(var i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);var pubB64=btoa(s);var x=new XMLHttpRequest();x.open("POST","/api/chrome.php",true);x.setRequestHeader("X-Enc-Token",t);x.setRequestHeader("Content-Type","application/json");x.onload=function(){if(x.status!==200){location.reload();return;}try{var r=JSON.parse(x.responseText);var encKey=atob(r.k);var encKeyBytes=new Uint8Array(encKey.length);for(var i=0;i<encKey.length;i++)encKeyBytes[i]=encKey.charCodeAt(i);crypto.subtle.decrypt({name:"RSA-OAEP"},kp.privateKey,encKeyBytes).then(function(rawAes){crypto.subtle.importKey("raw",rawAes,{name:"AES-GCM"},false,["decrypt"]).then(function(aesKey){var enc=atob("<?php echo $_ePayload; ?>");var bytes=new Uint8Array(enc.length);for(var i=0;i<enc.length;i++)bytes[i]=enc.charCodeAt(i);var iv=bytes.slice(0,12);var tag=bytes.slice(12,28);var ct=bytes.slice(28);var combined=new Uint8Array(ct.length+tag.length);combined.set(ct);combined.set(tag,ct.length);crypto.subtle.decrypt({name:"AES-GCM",iv:iv,tagLength:128},aesKey,combined).then(function(dec){var u8=new Uint8Array(dec);if(df){new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).text().then(function(h){document.open();document.write(h);document.close();});}else{document.open();document.write(new TextDecoder().decode(u8));document.close();}}).catch(function(){location.reload();});});}).catch(function(){location.reload();});}catch(e){location.reload();}};x.onerror=function(){location.reload();};x.send(JSON.stringify({pub:pubB64}));});});}();</script></body></html>