<?php
    include 'configuration.php';
    if(basename($_SERVER['SCRIPT_FILENAME']) == basename(__FILE__)) die('{"errors":[{"code":401,"message":"Unauthorized"}]}');

    try{
        
        
        
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        ];

        $pdo = new PDO(
            'mysql:host=127.0.0.1;dbname=' . $database['name'] . ';charset=utf8mb4',
            $database['username'],
            $database['password'],
            $options
        );
        
        $db = $pdo;
        
    } catch(PDOException $Exception) {
        die('Database failed to connect.');
    }
?>