<?php
if (!function_exists('ultimaAuthCode')) {
    define('ULTIMA_AUTH_COOKIE', 'auth');
    define('ULTIMA_STATE_COOKIE', 'ust');
    define('ULTIMA_AUTH_LIFETIME', 30 * 24 * 60 * 60);
    define('ULTIMA_STATE_LIFETIME', 2 * 60 * 60);
    define('ULTIMA_AUTH_SECRET', '161f82a4af0a66391ddc2e4ffe5ba9928e60132cdcf0a5ae57a6f43cb2710e63');

    define('ULTIMA_TOKEN_LENGTH', 200);

    function ultimaAuthCodeMaxLength($db = null): int
    {
        $sql = "SELECT MIN(CHARACTER_MAXIMUM_LENGTH) AS m FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_NAME = 'auth_code' AND TABLE_NAME IN ('regular', 'triplehook')";
        try {
            if ($db instanceof \PDO) {
                $max = $db->query($sql)->fetchColumn();
            } elseif (function_exists('executeSafeQuery')) {
                $rows = executeSafeQuery($sql, []);
                $max = is_array($rows) ? ($rows[0]['m'] ?? null) : null;
            } else {
                $max = null;
            }
        } catch (\Throwable $e) {
            $max = null;
        }
        return $max ? (int)$max : 0;
    }

    function ultimaNewAuthToken($db = null): string
    {
        $max = ultimaAuthCodeMaxLength($db);
        $length = $max > 0 ? max(100, min(ULTIMA_TOKEN_LENGTH, $max - 4)) : 100;
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $token = '';
        for ($i = 0; $i < $length; $i++) {
            $token .= $chars[random_int(0, 35)];
        }
        return $token . '-tkn';
    }

    function ultimaAuthCode(): string
    {
        $code = $_COOKIE[ULTIMA_AUTH_COOKIE] ?? '';
        return is_string($code) && preg_match('/^[A-Za-z0-9_-]{1,256}$/', $code) ? $code : '';
    }

    function ultimaCookieSecure(): bool
    {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
            || ((string)($_SERVER['SERVER_PORT'] ?? '') === '443');
    }

    function ultimaCookie(string $name, string $value, int $expires): void
    {
        if (headers_sent()) return;
        setcookie($name, $value, [
            'expires' => $expires,
            'path' => '/',
            'secure' => ultimaCookieSecure(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    function ultimaSetAuthCookie(string $code): void
    {
        $code = trim($code);
        if ($code === '' || !preg_match('/^[A-Za-z0-9_-]{1,256}$/', $code)) return;
        ultimaCookie(ULTIMA_AUTH_COOKIE, $code, time() + ULTIMA_AUTH_LIFETIME);
        $_COOKIE[ULTIMA_AUTH_COOKIE] = $code;
    }

    function ultimaClearAuthCookie(): void
    {
        ultimaCookie(ULTIMA_AUTH_COOKIE, '', time() - 86400);
        unset($_COOKIE[ULTIMA_AUTH_COOKIE]);
        if (isset($_SESSION) && is_array($_SESSION)) unset($_SESSION['auth_code']);
    }

    function ultimaDropLegacySessionCookies(): void
    {
        foreach (['token', 'PHPSESSID'] as $name) {
            if (isset($_COOKIE[$name])) {
                ultimaCookie($name, '', time() - 86400);
                unset($_COOKIE[$name]);
            }
        }
    }

    function ultimaUseAuthCookie(): bool
    {
        if (!defined('ULTIMA_COOKIE_AUTH')) define('ULTIMA_COOKIE_AUTH', true);
        ultimaDropLegacySessionCookies();
        if (!isset($_SESSION) || !is_array($_SESSION)) $_SESSION = [];
        $code = ultimaAuthCode();
        $_SESSION['auth_code'] = $code;
        if ($code !== '') {
            $_SESSION['xor_page_key'] = substr(hash_hmac('sha256', 'xor|' . $code, ULTIMA_AUTH_SECRET), 0, 32);
            $_SESSION['storage_token'] = hash_hmac('sha256', 'storage|' . $code, ULTIMA_AUTH_SECRET);
        }
        return true;
    }

    function ultimaStateKey(): string
    {
        return hash('sha256', 'state|' . ULTIMA_AUTH_SECRET, true);
    }

    function ultimaStateDecode(string $raw): array
    {
        $bin = base64_decode(strtr($raw, '-_', '+/'), true);
        if (!is_string($bin) || strlen($bin) < 29) return [];
        $plain = openssl_decrypt(substr($bin, 28), 'aes-256-gcm', ultimaStateKey(), OPENSSL_RAW_DATA, substr($bin, 0, 12), substr($bin, 12, 16));
        if (!is_string($plain)) return [];
        $data = @unserialize($plain, ['allowed_classes' => false]);
        return is_array($data) ? $data : [];
    }

    function ultimaStateEncode(array $data): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $ct = openssl_encrypt(serialize($data), 'aes-256-gcm', ultimaStateKey(), OPENSSL_RAW_DATA, $iv, $tag);
        return rtrim(strtr(base64_encode($iv . $tag . $ct), '+/', '-_'), '=');
    }

    function ultimaStatePayload(): array
    {
        $data = (isset($_SESSION) && is_array($_SESSION)) ? $_SESSION : [];
        unset($data['auth_code'], $data['link_id'], $data['triplehook'], $data['xor_page_key'], $data['storage_token']);
        return $data;
    }

    function ultimaStateFlush(): void
    {
        if (!defined('ULTIMA_STATE_STARTED') || headers_sent()) return;
        $code = trim((string)($_SESSION['auth_code'] ?? ''));
        if ($code !== '' && $code !== ultimaAuthCode()) ultimaSetAuthCookie($code);
        $data = ultimaStatePayload();
        if ($data === ($GLOBALS['__ultimaStateLast'] ?? [])) return;
        $GLOBALS['__ultimaStateLast'] = $data;
        if ($data) {
            ultimaCookie(ULTIMA_STATE_COOKIE, ultimaStateEncode($data), time() + ULTIMA_STATE_LIFETIME);
        } else {
            ultimaCookie(ULTIMA_STATE_COOKIE, '', time() - 86400);
        }
    }

    function ultimaStateStart(): bool
    {
        if (defined('ULTIMA_STATE_STARTED')) return true;
        define('ULTIMA_STATE_STARTED', true);
        ultimaDropLegacySessionCookies();
        $raw = $_COOKIE[ULTIMA_STATE_COOKIE] ?? '';
        $_SESSION = is_string($raw) && $raw !== '' ? ultimaStateDecode($raw) : [];
        $GLOBALS['__ultimaStateLast'] = ultimaStatePayload();
        if (ultimaAuthCode() !== '') $_SESSION['auth_code'] = ultimaAuthCode();
        header_register_callback('ultimaStateFlush');
        return true;
    }

    function ultimaStateClear(): bool
    {
        $_SESSION = [];
        return true;
    }
}
