<?php
if (!function_exists('ultimaSealScript')) {
    function ultimaSealScript(string $html): string
    {
        $alpha = '';
        for ($c = 32; $c <= 126; $c++) $alpha .= chr($c);
        $special = ['<', '"', '\\'];
        $rare = ['`', '$', '~'];
        $src = array_values(array_diff(str_split($alpha), $rare));
        $dst = array_values(array_diff(str_split($alpha), $special));
        for ($i = count($dst) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$dst[$i], $dst[$j]] = [$dst[$j], $dst[$i]];
        }
        for ($i = count($special) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$special[$i], $special[$j]] = [$special[$j], $special[$i]];
        }
        $map = [];
        foreach ($rare as $i => $ch) $map[$ch] = $special[$i];
        foreach ($src as $i => $ch) $map[$ch] = $dst[$i];
        $perm = '';
        for ($c = 32; $c <= 126; $c++) $perm .= $map[chr($c)];
        $json = function (string $s): string {
            return str_replace('<', '\\u003C', (string)json_encode($s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE));
        };
        return '<script>(function(){var q=' . $json($perm) . ',s=' . $json(strtr($html, $alpha, $perm))
            . ',m=new Uint16Array(128),n=s.length,o=new Uint16Array(n),r="",i,c;for(i=0;i<128;i++)m[i]=i;for(i=0;i<95;i++)m[q.charCodeAt(i)]=i+32;'
            . 'for(i=0;i<n;i++){c=s.charCodeAt(i);o[i]=c<127?m[c]:c}for(i=0;i<n;i+=8192)r+=String.fromCharCode.apply(null,o.subarray(i,i+8192));document.write(r)})();</script>';
    }

    function ultimaProtectPage(): void
    {
        if (defined('ULTIMA_PROTECT_ON')) return;
        define('ULTIMA_PROTECT_ON', true);
        ob_start(function ($buffer) {
            if (!is_string($buffer) || !preg_match('/^\s*(<!DOCTYPE html|<html)/i', $buffer)) return $buffer;
            foreach (headers_list() as $h) {
                if (stripos($h, 'Content-Type:') === 0 && stripos($h, 'text/html') === false) return $buffer;
            }
            $title = preg_match('/<title[^>]*>.*?<\/title>/is', $buffer, $m) ? $m[0] : '';
            $icon = preg_match('/<link\b[^>]*rel=["\'](?:shortcut )?icon["\'][^>]*>/i', $buffer, $mi) ? $mi[0] : '';
            return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">'
                . $title . $icon . ultimaSealScript($buffer) . '</head><body></body></html>';
        });
    }
}
