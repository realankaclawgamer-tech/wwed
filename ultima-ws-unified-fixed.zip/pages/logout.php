<?php
require_once __DIR__ . '/../libs/auth.php';

ultimaStateStart();
ultimaStateClear();
ultimaClearAuthCookie();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['ok' => true, 'redirect' => '/']);
    exit;
}

header('Location: /');
exit;
