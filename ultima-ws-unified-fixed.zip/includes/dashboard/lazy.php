<?php
if (!function_exists('ultimaBlocksMode')) {
    function ultimaBlocksMode()
    {
        return !empty($_GET['__blocks']);
    }

    function ultimaReleaseSession()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return;
        }
        if (empty($_SESSION['xor_page_key']) || !is_string($_SESSION['xor_page_key']) || strlen($_SESSION['xor_page_key']) < 16) {
            $_SESSION['xor_page_key'] = bin2hex(random_bytes(16));
        }
        unset($_SESSION['ultima_page_query_cache'], $_SESSION['triplehook_scope_ids_cache'], $_SESSION['dashboard_runtime_cache']);
        session_write_close();
    }

    function ultimaLazySkel($class = '', $style = '')
    {
        return '<div class="dash-skel' . ($class !== '' ? ' ' . htmlspecialchars($class, ENT_QUOTES) : '') . '" data-lazy="1" aria-hidden="true"'
            . ($style !== '' ? ' style="' . htmlspecialchars($style, ENT_QUOTES) . '"' : '') . '></div>';
    }

    function ultimaBlockWanted($key)
    {
        if (!ultimaBlocksMode() || !isset($_GET['__only'])) {
            return true;
        }
        return in_array((string)$key, explode(',', (string)$_GET['__only']), true);
    }

    function ultimaBlockOpen($key, $group = '')
    {
        return '<div data-block="' . htmlspecialchars((string)$key, ENT_QUOTES) . '"'
            . ($group !== '' ? ' data-group="' . htmlspecialchars((string)$group, ENT_QUOTES) . '"' : '')
            . ' style="display:contents">';
    }

    function ultimaLazyStart($key, $skeleton = '', $group = '')
    {
        $open = !empty($GLOBALS['ultimaLazyDepth']) || ultimaBlockWanted($key);
        $GLOBALS['ultimaLazyOpen'][] = $open;
        if (!$open) {
            return false;
        }
        echo ultimaBlockOpen($key, $group);
        if (ultimaBlocksMode()) {
            $GLOBALS['ultimaLazyDepth'] = ($GLOBALS['ultimaLazyDepth'] ?? 0) + 1;
            return true;
        }
        echo $skeleton !== '' ? $skeleton : ultimaLazySkel();
        return false;
    }

    function ultimaLazyEnd()
    {
        $open = isset($GLOBALS['ultimaLazyOpen']) ? array_pop($GLOBALS['ultimaLazyOpen']) : true;
        if ($open !== false) {
            echo '</div>';
            if (ultimaBlocksMode() && !empty($GLOBALS['ultimaLazyDepth'])) $GLOBALS['ultimaLazyDepth']--;
        }
    }

    function ultimaLazyStyles()
    {
        echo <<<'CSS'
<style>
.dash-skel{position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.07);border-radius:18px;background:rgba(255,255,255,.028)}
.dash-skel::after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(100deg,transparent 20%,rgba(255,255,255,.04) 38%,rgba(255,255,255,.085) 50%,rgba(255,255,255,.04) 62%,transparent 80%);transform:translateX(-100%);animation:dashWave 2s cubic-bezier(.45,0,.25,1) infinite;animation-delay:var(--wave,0s)}
@media(max-width:768px){.dash-skel{border-radius:14px}}
@keyframes dashWave{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
[data-block]>*{animation:dashBlockIn .35s ease}
@keyframes dashBlockIn{from{opacity:0}to{opacity:1}}
@media (prefers-reduced-motion: reduce){.dash-skel::after{animation:none;display:none}[data-block]>*{animation:none}}
</style>
CSS;
    }

    function ultimaLazyScript()
    {
        echo <<<'JS'
<script>
(function(){
    var main=(document.currentScript&&document.currentScript.closest('main.main-content'))||document.querySelector('#bootChrome main.main-content')||document.querySelector('main.main-content');
    if(!main)return;
    var skels=[].slice.call(main.querySelectorAll('[data-block] > .dash-skel[data-lazy="1"]'));
    if(!skels.length)return;
    var token='b'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
    main.__blocksGen=token;
    var SK=window.ultimaSkel||null;
    if(SK)SK.fit(main);
    skels.forEach(function(s){s.setAttribute('data-lazy',token)});
    function blockOf(el){var p=el&&el.parentNode;return p&&p.getAttribute?p.getAttribute('data-block'):null}
    function boxes(root,out){[].slice.call(root.children).forEach(function(c){var t=c.tagName;if(t==='SCRIPT'||t==='STYLE'||t==='LINK'||t==='TEMPLATE'||t==='META')return;var cs=getComputedStyle(c);if(cs.display==='none'||cs.position==='fixed'||cs.position==='absolute')return;if(cs.display==='contents'||c.classList.contains('tab-content')){boxes(c,out);return}var r=c.getBoundingClientRect(),dy=0;if(cs.transform&&cs.transform!=='none'&&window.DOMMatrixReadOnly){try{dy=new DOMMatrixReadOnly(cs.transform).m42||0}catch(e){}}out.push({el:c,cs:cs,r:dy?{top:r.top-dy,bottom:r.bottom-dy,left:r.left,right:r.right,width:r.width,height:r.height}:r})});return out}
    function measure(d){var bx=boxes(d,[]).filter(function(b){return b.r.width>0||b.r.height>0}),top=Infinity,bot=-Infinity;if(!bx.length)return {h:0,n:0,mt:0,mb:0,top:null,bottom:null};var lf=Infinity,rt=-Infinity;bx.forEach(function(b){if(b.r.top<top)top=b.r.top;if(b.r.bottom>bot)bot=b.r.bottom;if(b.r.left<lf)lf=b.r.left;if(b.r.right>rt)rt=b.r.right});var one=bx.length===1;return {h:Math.max(0,Math.round(bot-top)),w:Math.max(0,Math.round(rt-lf)),n:bx.length,mt:one?(parseFloat(bx[0].cs.marginTop)||0):0,mb:one?(parseFloat(bx[0].cs.marginBottom)||0):0,top:top,bottom:bot}}
    function settle(filled){
        if(!window.ResizeObserver||!SK)return;
        var t=0,ro=new ResizeObserver(function(){clearTimeout(t);t=setTimeout(function(){if(main.__blocksGen===token)remember(filled)},150)});
        filled.forEach(function(d){boxes(d,[]).forEach(function(b){ro.observe(b.el)})});
        setTimeout(function(){ro.disconnect();clearTimeout(t);if(main.__blocksGen===token)remember(filled)},2500);
    }
    function remember(filled){if(!SK)return;try{var m=SK.load();filled.forEach(function(d){var b=d.getAttribute('data-block');if(!b||!d.isConnected)return;var v=measure(d);if(!v.n&&boxes(d,[]).length)return;m[SK.key(main,b)]={h:v.h,w:v.w,n:v.n,mt:v.mt,mb:v.mb}});SK.store(m)}catch(e){}}
    var wraps=[],groups={},order=[];
    skels.forEach(function(s){
        var w=s.parentNode;
        if(wraps.indexOf(w)!==-1)return;
        wraps.push(w);
        var g=w.getAttribute('data-group')||'';
        if(!groups[g]){groups[g]=[];order.push(g)}
        groups[g].push(w.getAttribute('data-block'));
    });
    function pickAnchor(){
        if(window.__ultimaRestoring||(window.scrollY||window.pageYOffset||0)<=0)return null;
        var mid=(window.innerHeight||document.documentElement.clientHeight||0)/2,best=null,bd=Infinity;
        wraps.forEach(function(w){
            var b=w.getAttribute('data-block');
            if(!b||!w.isConnected)return;
            var m=measure(w);
            if(m.top===null)return;
            var d=mid<m.top?m.top-mid:(mid>m.bottom?mid-m.bottom:0);
            if(d<bd){bd=d;best={b:b,edge:m.bottom<mid?'bottom':'top',v:m.bottom<mid?m.bottom:m.top}}
        });
        return best;
    }
    function fixer(a){
        var moved=false,evs=['wheel','touchstart','keydown','mousedown'];
        function mv(){moved=true}
        if(a)evs.forEach(function(t){window.addEventListener(t,mv,{capture:true,passive:true})});
        var fn=function(){
            if(!a||moved)return;
            var d=main.querySelector('[data-block="'+a.b+'"]');if(!d)return;
            var m=measure(d);if(m.top===null)return;
            var delta=(a.edge==='top'?m.top:m.bottom)-a.v;
            if(Math.abs(delta)>=1)window.scrollBy(0,delta);
        };
        fn.end=function(){if(a)evs.forEach(function(t){window.removeEventListener(t,mv,true)})};
        return fn;
    }
    function xdec(b64,k){var b=atob(b64),n=b.length,kl=k.length,u=new Uint8Array(n);for(var i=0;i<n;i++)u[i]=b.charCodeAt(i)^k.charCodeAt(i%kl);return new TextDecoder('utf-8').decode(u)}
    function bootChart(){try{
        var cards=main.querySelectorAll('.overview-card .chart-container,.chart-container');
        for(var j=0;j<cards.length;j++){var box=cards[j],cv=box.querySelector('canvas');if(!cv)continue;var w=box.clientWidth||box.offsetWidth||0,hh=box.clientHeight||box.offsetHeight||235;if(w<10)w=box.parentElement?box.parentElement.clientWidth:0;if(w>10){cv.style.width=w+'px';cv.style.height=Math.max(hh,220)+'px';cv.width=w;cv.height=Math.max(hh,220)}if(window.Chart&&typeof Chart.getChart==='function'){var old=Chart.getChart(cv);if(old&&old.destroy)old.destroy()}}
        window.dispatchEvent(new Event('resize'));
        if(typeof OverviewChart!=='undefined'&&OverviewChart.init)OverviewChart.init();else if(typeof Dashboard!=='undefined'&&Dashboard.init)Dashboard.init();
    }catch(e){}}
    var aelDepth=0,aelOrig=null;
    function hookAEL(){
        if(aelDepth++)return;
        aelOrig=document.addEventListener;
        var baseAEL=aelOrig.bind(document);
        document.addEventListener=function(type,fn,opts){if(type==='DOMContentLoaded'&&document.readyState!=='loading'){setTimeout(function(){try{if(typeof fn==='function')fn.call(document,new Event('DOMContentLoaded'));else if(fn&&typeof fn.handleEvent==='function')fn.handleEvent(new Event('DOMContentLoaded'))}catch(e){}},0);return}return baseAEL(type,fn,opts)};
    }
    function unhookAEL(){if(aelDepth>0&&!--aelDepth)document.addEventListener=aelOrig}
    function runScripts(scripts,step,done,chart){
        hookAEL();
        (function next(i){
            if(i>=scripts.length){
                unhookAEL();step();
                setTimeout(function(){step();requestAnimationFrame(function(){requestAnimationFrame(function(){if(chart)bootChart();step();requestAnimationFrame(done)})})},80);
                try{window.dispatchEvent(new CustomEvent('ultima:blocks-loaded'))}catch(e){}
                return;
            }
            var old=scripts[i],s=document.createElement('script');
            [].slice.call(old.attributes).forEach(function(a){s.setAttribute(a.name,a.value)});
            if(old.src){s.async=false;s.onload=s.onerror=function(){next(i+1)}}else{s.text=old.textContent}
            try{old.parentNode.replaceChild(s,old)}catch(e){}
            if(!old.src)next(i+1);
        })(0);
    }
    window.ultimaCountUp=function(root,loadMs){
        var dur=Math.max(450,Math.min(2500,(loadMs||600)*1.3));
        [].slice.call((root||document).querySelectorAll('[data-countup]')).forEach(function(el){
            if(el.__cu)return; el.__cu=1;
            var raw=(el.getAttribute('data-countup-to')||el.textContent||'').replace(/[^0-9.\-]/g,'');
            var target=parseFloat(raw); if(!isFinite(target)){return;}
            var dec=(raw.indexOf('.')>=0)?(raw.split('.')[1]||'').length:0;
            var grp=/,/.test(el.textContent);
            function fmt(v){var n=dec?v.toFixed(dec):String(Math.round(v));if(grp){var p=n.split('.');p[0]=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,',');n=p.join('.');}return n;}
            if(target<=0){el.textContent=fmt(0);return;}
            var t0=null,last=fmt(0);
            function step(ts){if(el.textContent!==last)return;if(t0===null)t0=ts;var p=Math.min(1,(ts-t0)/dur);var e=1-Math.pow(1-p,3);last=p<1?fmt(target*e):fmt(target);el.textContent=last;if(p<1)requestAnimationFrame(step);}
            el.textContent=last;
            requestAnimationFrame(step);
        });
    };
    var anchorLocks=0;
    function apply(html,loadMs){
        if(main.__blocksGen!==token)return;
        var doc=new DOMParser().parseFromString(html,'text/html');
        var fix=fixer(pickAnchor()),de=document.documentElement;
        if(!(anchorLocks++))de.style.overflowAnchor='none';
        var filled=[],locks=[];
        [].slice.call(doc.querySelectorAll('[data-block]')).forEach(function(src){
            var dst=main.querySelector('[data-block="'+src.getAttribute('data-block')+'"]');
            var sk=dst&&dst.querySelector('.dash-skel');
            if(!sk||sk.getAttribute('data-lazy')!==token)return;
            var lockH=dst.querySelectorAll('.dash-skel').length===1?sk.getBoundingClientRect().height:0;
            dst.innerHTML=src.innerHTML;
            filled.push(dst);
            if(lockH>0){
                var cands=[].slice.call(dst.children).filter(function(c){
                    if(/^(SCRIPT|STYLE|LINK|TEMPLATE|META)$/.test(c.tagName))return false;
                    var st=getComputedStyle(c);
                    return st.display!=='none'&&st.display!=='contents'&&st.position!=='fixed'&&st.position!=='absolute';
                });
                if(cands.length===1){
                    var el=cands[0],cs=getComputedStyle(el),extra=cs.boxSizing==='border-box'?0:(parseFloat(cs.paddingTop)||0)+(parseFloat(cs.paddingBottom)||0)+(parseFloat(cs.borderTopWidth)||0)+(parseFloat(cs.borderBottomWidth)||0);
                    locks.push([el,el.style.minHeight]);
                    el.style.minHeight=Math.max(0,lockH-extra)+'px';
                }
            }
        });
        fix();
        var scripts=[].slice.call(main.querySelectorAll('[data-block] script')).filter(function(s){
            return filled.some(function(d){return d.contains(s)});
        });
        filled.forEach(function(d){window.ultimaCountUp(d,loadMs);});
        var chart=filled.some(function(d){return !!d.querySelector('.chart-container')});
        runScripts(scripts,fix,function(){
            locks.forEach(function(l){l[0].style.minHeight=l[1]});
            fix();fix.end();
            if(!(--anchorLocks))de.style.overflowAnchor='';
            if(main.__blocksGen===token){remember(filled);settle(filled)}
        },chart);
    }
    var base=location.pathname+(location.search?location.search+'&':'?')+'__blocks=1';
    var split=order.length>1||order[0]!=='';
    var ctls=[];
    var t0=Date.now(),held=[],waitFor={},waiting=0,released=false,holdT=0;
    order.forEach(function(g){
        var vis=groups[g].some(function(b){var w=main.querySelector('[data-block="'+b+'"]'),s=w&&w.querySelector('.dash-skel');return !!(s&&s.getClientRects().length)});
        if(vis){waitFor[g]=1;waiting++}
    });
    if(waiting<2)released=true;else holdT=setTimeout(release,10000);
    function release(){
        if(released)return;
        released=true;clearTimeout(holdT);
        var h=held;held=[];
        if(main.__blocksGen!==token)return;
        var ms=Date.now()-t0;
        h.forEach(function(x){apply(x,ms)});
    }
    function settleGroup(g){if(released||!waitFor[g])return false;delete waitFor[g];waiting--;return true}
    function deliver(g,html,ms){if(settleGroup(g)){held.push(html);if(!waiting)release();return}apply(html,ms)}
    function failed(g){if(settleGroup(g)&&!waiting)release()}
    window.addEventListener('ultima:softnav-start',function onNav(){
        window.removeEventListener('ultima:softnav-start',onNav);
        if(main.__blocksGen===token)main.__blocksGen=null;
        clearTimeout(holdT);held=[];
        ctls.forEach(function(c){try{c.abort()}catch(e){}});
    });
    order.forEach(function(g){load(g,split?base+'&__only='+encodeURIComponent(groups[g].join(',')):base,0)});
    function load(g,url,attempt){
        var started=Date.now();
        var ctl=window.AbortController?new AbortController():null;
        if(ctl)ctls.push(ctl);
        fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'X-Soft-Nav':'1'},signal:ctl?ctl.signal:undefined})
            .then(function(r){if(!r.ok)throw new Error('http '+r.status);return r.text()})
            .then(function(t){
                var j=JSON.parse(t),key=window.__ultimaXorKey;
                if(!j||typeof j.p!=='string'||!key)throw new Error('payload');
                deliver(g,xdec(j.p,key),Date.now()-started);
            })
            .catch(function(){
                if(main.__blocksGen!==token)return;
                if(attempt<2)setTimeout(function(){load(g,url,attempt+1)},800*(attempt+1));
                else failed(g);
            });
    }
})();
</script>
JS;
    }
}
