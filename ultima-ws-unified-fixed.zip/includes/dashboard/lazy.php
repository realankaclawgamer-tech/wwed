<?php
/*
 * Anlık sayfa, veriler sonradan: ağır bölümler ilk render'da iskelet olarak basılır
 * (DB sorgusu yok -> sayfa hemen gelir), gerçek içerik aynı URL'e ?__blocks=1 ile
 * yapılan ikinci istekte hesaplanıp iskeletlerin yerine konur.
 *
 * Kullanım:
 *   <?php ultimaLazyStyles(); ?>                       // main'in başında
 *   <?php if (ultimaLazyStart('key', ultimaLazySkel('cls'))): ?> ...ağır içerik... <?php endif; ultimaLazyEnd(); ?>
 *   <?php ultimaLazyScript(); ?>                       // main'in sonunda
 * Ağır sorgular: if (ultimaBlocksMode()) { ... } ile yalnızca veri isteğinde çalıştırılır.
 */
if (!function_exists('ultimaBlocksMode')) {
    function ultimaBlocksMode()
    {
        return !empty($_GET['__blocks']);
    }

    function ultimaLazySkel($class = '', $style = '')
    {
        return '<div class="dash-skel' . ($class !== '' ? ' ' . htmlspecialchars($class, ENT_QUOTES) : '') . '" data-lazy="1" aria-hidden="true"'
            . ($style !== '' ? ' style="' . htmlspecialchars($style, ENT_QUOTES) . '"' : '') . '></div>';
    }

    // Blok sarmalayıcısını açar. Veri isteğinde true döner (gerçek içerik basılır),
    // sayfa render'ında iskeleti basıp false döner. display:contents yerleşimi bozmaz.
    function ultimaLazyStart($key, $skeleton = '')
    {
        echo '<div data-block="' . htmlspecialchars((string)$key, ENT_QUOTES) . '" style="display:contents">';
        if (ultimaBlocksMode()) {
            return true;
        }
        echo $skeleton !== '' ? $skeleton : ultimaLazySkel();
        return false;
    }

    function ultimaLazyEnd()
    {
        echo '</div>';
    }

    function ultimaLazyStyles()
    {
        echo <<<'CSS'
<style>
.dash-skel{border:1px solid rgba(255,255,255,.07);border-radius:18px;background:linear-gradient(100deg,rgba(255,255,255,.03) 30%,rgba(255,255,255,.08) 50%,rgba(255,255,255,.03) 70%);background-size:200% 100%;animation:dashSkel 1.15s ease-in-out infinite}
@media(max-width:768px){.dash-skel{border-radius:14px}}
@keyframes dashSkel{0%{background-position:200% 0}100%{background-position:-200% 0}}
[data-block]>*{animation:dashBlockIn .35s ease}
@keyframes dashBlockIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion: reduce){.dash-skel{animation:none}[data-block]>*{animation:none}}
</style>
CSS;
    }

    function ultimaLazyScript()
    {
        echo <<<'JS'
<script>
(function(){
    var main=(document.currentScript&&document.currentScript.closest('main.main-content'))||document.querySelector('#bootChrome main.main-content')||document.querySelector('main.main-content');
    if(!main)return;
    // Partial swap'te main elementi kalıcı; bu yüzden elemana kalıcı bayrak koymak
    // yerine bu render'ın iskeletlerini token'la işaretle. Yeni bir render (toggle,
    // sayfaya geri dönüş) yeni iskeletler ve yeni token getirir; eski yanıt atılır.
    var skels=[].slice.call(main.querySelectorAll('[data-block] > .dash-skel[data-lazy="1"]'));
    if(!skels.length)return;
    var token='b'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
    main.__blocksGen=token;
    skels.forEach(function(s){s.setAttribute('data-lazy',token)});
    function xdec(b64,k){var b=atob(b64),o=new Array(b.length),kl=k.length;for(var i=0;i<b.length;i++)o[i]=String.fromCharCode(b.charCodeAt(i)^k.charCodeAt(i%kl));return o.join('')}
    function bootChart(){try{
        var cards=main.querySelectorAll('.overview-card .chart-container,.chart-container');
        for(var j=0;j<cards.length;j++){var box=cards[j],cv=box.querySelector('canvas');if(!cv)continue;var w=box.clientWidth||box.offsetWidth||0,hh=box.clientHeight||box.offsetHeight||235;if(w<10)w=box.parentElement?box.parentElement.clientWidth:0;if(w>10){cv.style.width=w+'px';cv.style.height=Math.max(hh,220)+'px';cv.width=w;cv.height=Math.max(hh,220)}if(window.Chart&&typeof Chart.getChart==='function'){var old=Chart.getChart(cv);if(old&&old.destroy)old.destroy()}}
        window.dispatchEvent(new Event('resize'));
        if(typeof OverviewChart!=='undefined'&&OverviewChart.init)OverviewChart.init();else if(typeof Dashboard!=='undefined'&&Dashboard.init)Dashboard.init();
    }catch(e){}}
    // Tüm bloklar DOM'a girdikten SONRA scriptleri belge sırasıyla çalıştır —
    // bir bloğun scripti başka bir bloğun elemanını arayabiliyor.
    function runScripts(scripts){
        var oldAEL=document.addEventListener,baseAEL=oldAEL.bind(document);
        document.addEventListener=function(type,fn,opts){if(type==='DOMContentLoaded'&&document.readyState!=='loading'){setTimeout(function(){try{if(typeof fn==='function')fn.call(document,new Event('DOMContentLoaded'));else if(fn&&typeof fn.handleEvent==='function')fn.handleEvent(new Event('DOMContentLoaded'))}catch(e){}},0);return}return baseAEL(type,fn,opts)};
        (function next(i){
            if(i>=scripts.length){document.addEventListener=oldAEL;setTimeout(function(){requestAnimationFrame(function(){requestAnimationFrame(bootChart)})},80);try{window.dispatchEvent(new CustomEvent('ultima:blocks-loaded'))}catch(e){}return}
            var old=scripts[i],s=document.createElement('script');
            [].slice.call(old.attributes).forEach(function(a){s.setAttribute(a.name,a.value)});
            if(old.src){s.async=false;s.onload=s.onerror=function(){next(i+1)}}else{s.text=old.textContent}
            try{old.parentNode.replaceChild(s,old)}catch(e){}
            if(!old.src)next(i+1);
        })(0);
    }
    // Sayı elemanlarını 0'dan hedefe say. Süre yükleme süresine bağlı: hızlı
    // geldiyse hızlı, yavaşsa daha uzun ama en fazla ~2.5 sn. [data-countup]
    // taşıyan eleman: metni hedef sayıdır (number_format edilmiş olabilir).
    window.ultimaCountUp=function(root,loadMs){
        var dur=Math.max(450,Math.min(2500,(loadMs||600)*1.3));
        [].slice.call((root||document).querySelectorAll('[data-countup]')).forEach(function(el){
            if(el.__cu)return; el.__cu=1;
            var raw=(el.getAttribute('data-countup-to')||el.textContent||'').replace(/[^0-9.\-]/g,'');
            var target=parseFloat(raw); if(!isFinite(target)){return;}
            var dec=(raw.indexOf('.')>=0)?(raw.split('.')[1]||'').length:0;
            var grp=/,/.test(el.textContent);
            function fmt(v){var n=dec?v.toFixed(dec):String(Math.round(v));if(grp){var p=n.split('.');p[0]=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,',');n=p.join('.');}return n;}
            if(target<=0){el.textContent=fmt(0);return;}
            var t0=null;
            function step(ts){if(t0===null)t0=ts;var p=Math.min(1,(ts-t0)/dur);var e=1-Math.pow(1-p,3);el.textContent=fmt(target*e);if(p<1)requestAnimationFrame(step);else el.textContent=fmt(target);}
            el.textContent=fmt(0);
            requestAnimationFrame(step);
        });
    };
    function apply(html,loadMs){
        if(main.__blocksGen!==token)return;
        var doc=new DOMParser().parseFromString(html,'text/html');
        var filled=[];
        [].slice.call(doc.querySelectorAll('[data-block]')).forEach(function(src){
            var dst=main.querySelector('[data-block="'+src.getAttribute('data-block')+'"]');
            var sk=dst&&dst.querySelector('.dash-skel');
            if(!sk||sk.getAttribute('data-lazy')!==token)return;
            dst.innerHTML=src.innerHTML;
            filled.push(dst);
        });
        var scripts=[].slice.call(main.querySelectorAll('[data-block] script')).filter(function(s){
            return filled.some(function(d){return d.contains(s)});
        });
        filled.forEach(function(d){window.ultimaCountUp(d,loadMs);});
        runScripts(scripts);
    }
    var url=location.pathname+(location.search?location.search+'&':'?')+'__blocks=1';
    (function load(attempt){
        var started=Date.now();
        fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'X-Soft-Nav':'1'}})
            .then(function(r){if(!r.ok)throw new Error('http '+r.status);return r.text()})
            .then(function(t){
                var j=JSON.parse(t),key=window.__ultimaXorKey;
                if(!j||typeof j.p!=='string'||!key)throw new Error('payload');
                apply(xdec(j.p,key),Date.now()-started);
            })
            .catch(function(){
                if(main.__blocksGen!==token)return;
                if(attempt<2)setTimeout(function(){load(attempt+1)},800*(attempt+1));
            });
    })(0);
})();
</script>
JS;
    }
}
