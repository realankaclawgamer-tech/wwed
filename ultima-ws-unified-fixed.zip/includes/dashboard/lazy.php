<?php
/*
 * Anlık sayfa, veriler sonradan: ağır bölümler ilk render'da iskelet olarak basılır
 * (DB sorgusu yok -> sayfa hemen gelir), gerçek içerik aynı URL'e ?__blocks=1 ile
 * yapılan ikinci istekte hesaplanıp iskeletlerin yerine konur.
 *
 * Kullanım:
 *   <?php ultimaLazyStyles(); ?>                       // main'in başında
 *   <?php if (ultimaLazyStart('key', ultimaLazySkel('cls'))): ?> ...ağır içerik... <?php endif; ultimaLazyEnd(); ?>
 *   <?php ultimaLazyScript(); ?>                       // main'in sonunda
 * Ağır sorgular: if (ultimaBlocksMode()) { ... } ile yalnızca veri isteğinde çalıştırılır.
 */
if (!function_exists('ultimaBlocksMode')) {
    function ultimaBlocksMode()
    {
        return !empty($_GET['__blocks']);
    }

    // Oturum kilidini erken bırak. PHP dosya oturumu istek bitene kadar kilitli
    // kalır; bu sürede aynı kullanıcının diğer istekleri (sayfa geçişi, yenileme,
    // ?__blocks=1, sidebar sayaçları) sırada bekler. Auth ve mod okunduktan sonra
    // çağrılır; $_SESSION bellekte okunabilir kalır. XOR anahtarı yoksa önce yazılır
    // (yoksa istemcideki anahtarla uyuşmaz). Eski sürümlerin oturuma yazdığı sorgu
    // önbellekleri silinir: oturum dosyasını şişirip her isteği yavaşlatıyorlardı.
    function ultimaReleaseSession()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return;
        }
        if (empty($_SESSION['xor_page_key']) || !is_string($_SESSION['xor_page_key']) || strlen($_SESSION['xor_page_key']) < 16) {
            $_SESSION['xor_page_key'] = bin2hex(random_bytes(16));
        }
        unset($_SESSION['ultima_page_query_cache'], $_SESSION['triplehook_scope_ids_cache'], $_SESSION['dashboard_runtime_cache']);
        session_write_close();
    }

    function ultimaLazySkel($class = '', $style = '')
    {
        return '<div class="dash-skel' . ($class !== '' ? ' ' . htmlspecialchars($class, ENT_QUOTES) : '') . '" data-lazy="1" aria-hidden="true"'
            . ($style !== '' ? ' style="' . htmlspecialchars($style, ENT_QUOTES) . '"' : '') . '></div>';
    }

    // Blok sarmalayıcısını açar. Veri isteğinde true döner (gerçek içerik basılır),
    // sayfa render'ında iskeleti basıp false döner. display:contents yerleşimi bozmaz.
    function ultimaLazyStart($key, $skeleton = '')
    {
        echo '<div data-block="' . htmlspecialchars((string)$key, ENT_QUOTES) . '" style="display:contents">';
        if (ultimaBlocksMode()) {
            return true;
        }
        echo $skeleton !== '' ? $skeleton : ultimaLazySkel();
        return false;
    }

    function ultimaLazyEnd()
    {
        echo '</div>';
    }

    function ultimaLazyStyles()
    {
        echo <<<'CSS'
<style>
.dash-skel{border:1px solid rgba(255,255,255,.07);border-radius:18px;background:linear-gradient(100deg,rgba(255,255,255,.03) 30%,rgba(255,255,255,.08) 50%,rgba(255,255,255,.03) 70%);background-size:200% 100%;animation:dashSkel 1.15s ease-in-out infinite}
@media(max-width:768px){.dash-skel{border-radius:14px}}
@keyframes dashSkel{0%{background-position:200% 0}100%{background-position:-200% 0}}
[data-block]>*{animation:dashBlockIn .35s ease}
@keyframes dashBlockIn{from{opacity:0}to{opacity:1}}
@media (prefers-reduced-motion: reduce){.dash-skel{animation:none}[data-block]>*{animation:none}}
</style>
CSS;
    }

    function ultimaLazyScript()
    {
        echo <<<'JS'
<script>
(function(){
    var main=(document.currentScript&&document.currentScript.closest('main.main-content'))||document.querySelector('#bootChrome main.main-content')||document.querySelector('main.main-content');
    if(!main)return;
    // Partial swap'te main elementi kalıcı; bu yüzden elemana kalıcı bayrak koymak
    // yerine bu render'ın iskeletlerini token'la işaretle. Yeni bir render (toggle,
    // sayfaya geri dönüş) yeni iskeletler ve yeni token getirir; eski yanıt atılır.
    var skels=[].slice.call(main.querySelectorAll('[data-block] > .dash-skel[data-lazy="1"]'));
    if(!skels.length)return;
    var token='b'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
    main.__blocksGen=token;
    skels.forEach(function(s){s.setAttribute('data-lazy',token)});
    // İskelet yüksekliği = kart yüksekliği. Bloklar dolunca her bloğun gerçek
    // yüksekliği ölçülür ve yalnızca bu piksel ölçüsü (veri değil) tarayıcıda tutulur;
    // sonraki render'larda iskelet aynı yükseklikte basılır, böylece iskeletin
    // görüldüğü yerden kart çıkar ve sayfa kaymaz. Anahtar: sayfa + mod + main genişliği.
    var HK='ultimaSkelHeightsV1';
    function modeKey(){var t=document.getElementById('triplehookToggle');return t&&t.classList.contains('active')?'t':'n'}
    function hkey(b,m){return location.pathname+'|'+(m||modeKey())+'|'+Math.round((main.clientWidth||0)/40)+'|'+b}
    function hload(){try{return JSON.parse(localStorage.getItem(HK)||'{}')||{}}catch(e){return {}}}
    function hstore(m){try{var k=Object.keys(m);for(var i=0;i<k.length-400;i++)delete m[k[i]];localStorage.setItem(HK,JSON.stringify(m))}catch(e){}}
    function blockOf(el){var p=el&&el.parentNode;return p&&p.getAttribute?p.getAttribute('data-block'):null}
    // Bloğun görünen, akıştaki kutuları (display:contents içinden de iner).
    function boxes(root,out){[].slice.call(root.children).forEach(function(c){var t=c.tagName;if(t==='SCRIPT'||t==='STYLE'||t==='LINK'||t==='TEMPLATE'||t==='META')return;var cs=getComputedStyle(c);if(cs.display==='none'||cs.position==='fixed'||cs.position==='absolute')return;if(cs.display==='contents'){boxes(c,out);return}out.push({cs:cs,r:c.getBoundingClientRect()})});return out}
    function measure(d){var bx=boxes(d,[]).filter(function(b){return b.r.width>0||b.r.height>0}),top=Infinity,bot=-Infinity;if(!bx.length)return {h:0,n:0,mt:0,mb:0,top:null,bottom:null};bx.forEach(function(b){if(b.r.top<top)top=b.r.top;if(b.r.bottom>bot)bot=b.r.bottom});var one=bx.length===1;return {h:Math.max(0,Math.round(bot-top)),n:bx.length,mt:one?(parseFloat(bx[0].cs.marginTop)||0):0,mb:one?(parseFloat(bx[0].cs.marginBottom)||0):0,top:top,bottom:bot}}
    (function(){
        var hm=hload(),groups={};
        skels.forEach(function(s){var b=blockOf(s);if(b)(groups[b]=groups[b]||[]).push(s)});
        Object.keys(groups).forEach(function(b){
            // Bu modun ölçüsü yoksa (ör. ilk toggle) diğer modunkini kullan: kartlar iki
            // modda da çoğunlukla aynı boyuttadır; iskelet varsayılan yükseklikte kalmasın.
            var v=hm[hkey(b)]||hm[hkey(b,modeKey()==='t'?'n':'t')],g=groups[b];
            if(!v||typeof v.h!=='number')return;
            if(v.h<2){g.forEach(function(s){s.style.display='none'});return}
            // Aynı blokta birden çok iskelet (yan yana sayılar): hepsi aynı satırdaysa
            // her birine kart yüksekliğini ver; alt alta dizildiyse (dar ekran) toplam
            // yükseklik karta eşit olsun diye farkı son iskelete ekle.
            if(g.length>1){
                var rs=g.map(function(s){return s.getBoundingClientRect()}),same=true;
                for(var i=1;i<rs.length;i++){if(Math.abs(rs[i].top-rs[0].top)>2){same=false;break}}
                if(!same){
                    var top=Math.min.apply(null,rs.map(function(r){return r.top})),bot=Math.max.apply(null,rs.map(function(r){return r.bottom}));
                    var last=g[g.length-1],nh=rs[rs.length-1].height+(v.h-(bot-top));
                    if(nh>=0){last.style.height=nh+'px';last.style.minHeight=nh+'px'}
                    return;
                }
            }
            g.forEach(function(s){s.style.height=v.h+'px';s.style.minHeight=v.h+'px';if(g.length===1&&v.n===1){s.style.marginTop=v.mt+'px';s.style.marginBottom=v.mb+'px'}});
        });
    })();
    // Gizli sekmedeki (ör. controller'da kapalı panel) bloklar ölçülmez: boyutları 0
    // görünür ama açıldıklarında öyle değildir. Gerçekten boş blok 0 olarak kaydedilir.
    function remember(filled){try{var m=hload();filled.forEach(function(d){var b=d.getAttribute('data-block');if(!b||!d.isConnected)return;var v=measure(d);if(!v.n&&boxes(d,[]).length)return;m[hkey(b)]={h:v.h,n:v.n,mt:v.mt,mb:v.mb}});hstore(m)}catch(e){}}
    // Kaydırma çapası: dolum anında ekranın ORTASINA en yakın iskelet seçilir (göz
    // oraya bakar) ve ekrandaki yeri kaydedilir; kart geldikten sonra aynı bloğun kartı
    // aynı yerde kalacak şekilde kaydırma düzeltilir. Üstteki satırların yüksekliği
    // değişse bile baktığın kart yerinde kalır. Blok ortanın üstünde bitiyorsa alt
    // kenarı, değilse üst kenarı sabitlenir.
    function pickAnchor(){
        if((window.scrollY||window.pageYOffset||0)<=0)return null;
        var mid=(window.innerHeight||document.documentElement.clientHeight||0)/2,best=null,bd=Infinity,seen={};
        skels.forEach(function(s){
            var b=blockOf(s);
            if(!b||seen[b]||!s.isConnected||s.getAttribute('data-lazy')!==token)return;
            seen[b]=1;
            var d0=main.querySelector('[data-block="'+b+'"]'),m=d0?measure(d0):null;
            if(!m||m.top===null)return;
            var d=mid<m.top?m.top-mid:(mid>m.bottom?mid-m.bottom:0);
            if(d<bd){bd=d;best={b:b,edge:m.bottom<mid?'bottom':'top',v:m.bottom<mid?m.bottom:m.top}}
        });
        return best;
    }
    function fixer(a){
        var moved=false,evs=['wheel','touchstart','keydown','mousedown'];
        function mv(){moved=true}
        if(a)evs.forEach(function(t){window.addEventListener(t,mv,{capture:true,passive:true})});
        var fn=function(){
            if(!a||moved)return;
            var d=main.querySelector('[data-block="'+a.b+'"]');if(!d)return;
            var m=measure(d);if(m.top===null)return;
            var delta=(a.edge==='top'?m.top:m.bottom)-a.v;
            if(Math.abs(delta)>=1)window.scrollBy(0,delta);
        };
        fn.end=function(){if(a)evs.forEach(function(t){window.removeEventListener(t,mv,true)})};
        return fn;
    }
    function xdec(b64,k){var b=atob(b64),n=b.length,kl=k.length,u=new Uint8Array(n);for(var i=0;i<n;i++)u[i]=b.charCodeAt(i)^k.charCodeAt(i%kl);return new TextDecoder('utf-8').decode(u)}
    function bootChart(){try{
        var cards=main.querySelectorAll('.overview-card .chart-container,.chart-container');
        for(var j=0;j<cards.length;j++){var box=cards[j],cv=box.querySelector('canvas');if(!cv)continue;var w=box.clientWidth||box.offsetWidth||0,hh=box.clientHeight||box.offsetHeight||235;if(w<10)w=box.parentElement?box.parentElement.clientWidth:0;if(w>10){cv.style.width=w+'px';cv.style.height=Math.max(hh,220)+'px';cv.width=w;cv.height=Math.max(hh,220)}if(window.Chart&&typeof Chart.getChart==='function'){var old=Chart.getChart(cv);if(old&&old.destroy)old.destroy()}}
        window.dispatchEvent(new Event('resize'));
        if(typeof OverviewChart!=='undefined'&&OverviewChart.init)OverviewChart.init();else if(typeof Dashboard!=='undefined'&&Dashboard.init)Dashboard.init();
    }catch(e){}}
    // Tüm bloklar DOM'a girdikten SONRA scriptleri belge sırasıyla çalıştır —
    // bir bloğun scripti başka bir bloğun elemanını arayabiliyor.
    function runScripts(scripts,step,done){
        var oldAEL=document.addEventListener,baseAEL=oldAEL.bind(document);
        document.addEventListener=function(type,fn,opts){if(type==='DOMContentLoaded'&&document.readyState!=='loading'){setTimeout(function(){try{if(typeof fn==='function')fn.call(document,new Event('DOMContentLoaded'));else if(fn&&typeof fn.handleEvent==='function')fn.handleEvent(new Event('DOMContentLoaded'))}catch(e){}},0);return}return baseAEL(type,fn,opts)};
        (function next(i){
            if(i>=scripts.length){
                document.addEventListener=oldAEL;step();
                setTimeout(function(){step();requestAnimationFrame(function(){requestAnimationFrame(function(){bootChart();step();requestAnimationFrame(done)})})},80);
                try{window.dispatchEvent(new CustomEvent('ultima:blocks-loaded'))}catch(e){}
                return;
            }
            var old=scripts[i],s=document.createElement('script');
            [].slice.call(old.attributes).forEach(function(a){s.setAttribute(a.name,a.value)});
            if(old.src){s.async=false;s.onload=s.onerror=function(){next(i+1)}}else{s.text=old.textContent}
            try{old.parentNode.replaceChild(s,old)}catch(e){}
            if(!old.src)next(i+1);
        })(0);
    }
    // Sayı elemanlarını 0'dan hedefe say. Süre yükleme süresine bağlı: hızlı
    // geldiyse hızlı, yavaşsa daha uzun ama en fazla ~2.5 sn. [data-countup]
    // taşıyan eleman: metni hedef sayıdır (number_format edilmiş olabilir).
    window.ultimaCountUp=function(root,loadMs){
        var dur=Math.max(450,Math.min(2500,(loadMs||600)*1.3));
        [].slice.call((root||document).querySelectorAll('[data-countup]')).forEach(function(el){
            if(el.__cu)return; el.__cu=1;
            var raw=(el.getAttribute('data-countup-to')||el.textContent||'').replace(/[^0-9.\-]/g,'');
            var target=parseFloat(raw); if(!isFinite(target)){return;}
            var dec=(raw.indexOf('.')>=0)?(raw.split('.')[1]||'').length:0;
            var grp=/,/.test(el.textContent);
            function fmt(v){var n=dec?v.toFixed(dec):String(Math.round(v));if(grp){var p=n.split('.');p[0]=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,',');n=p.join('.');}return n;}
            if(target<=0){el.textContent=fmt(0);return;}
            var t0=null;
            function step(ts){if(t0===null)t0=ts;var p=Math.min(1,(ts-t0)/dur);var e=1-Math.pow(1-p,3);el.textContent=fmt(target*e);if(p<1)requestAnimationFrame(step);else el.textContent=fmt(target);}
            el.textContent=fmt(0);
            requestAnimationFrame(step);
        });
    };
    function apply(html,loadMs){
        if(main.__blocksGen!==token)return;
        var doc=new DOMParser().parseFromString(html,'text/html');
        // Tarayıcının kendi kaydırma çapası iskelet silinince yanlış elemana tutunup
        // sayfayı oynatıyordu; dolum süresince kapatıp çapayı biz tutuyoruz.
        var fix=fixer(pickAnchor()),de=document.documentElement,oa=de.style.overflowAnchor;
        de.style.overflowAnchor='none';
        var filled=[];
        [].slice.call(doc.querySelectorAll('[data-block]')).forEach(function(src){
            var dst=main.querySelector('[data-block="'+src.getAttribute('data-block')+'"]');
            var sk=dst&&dst.querySelector('.dash-skel');
            if(!sk||sk.getAttribute('data-lazy')!==token)return;
            dst.innerHTML=src.innerHTML;
            filled.push(dst);
        });
        fix();
        var scripts=[].slice.call(main.querySelectorAll('[data-block] script')).filter(function(s){
            return filled.some(function(d){return d.contains(s)});
        });
        filled.forEach(function(d){window.ultimaCountUp(d,loadMs);});
        runScripts(scripts,fix,function(){
            fix();fix.end();de.style.overflowAnchor=oa;
            // Kart ölçüleri bir sonraki render'ın iskeletleri için.
            if(main.__blocksGen===token)remember(filled);
        });
    }
    var url=location.pathname+(location.search?location.search+'&':'?')+'__blocks=1';
    // Sayfadan ayrılınca (yeni soft-nav) bu sayfanın veri isteğini iptal et: tarayıcı
    // bağlantısını ve sunucuyu boşuna meşgul etmesin.
    var ctl=null;
    window.addEventListener('ultima:softnav-start',function onNav(){
        window.removeEventListener('ultima:softnav-start',onNav);
        if(main.__blocksGen===token)main.__blocksGen=null;
        if(ctl){try{ctl.abort()}catch(e){}}
    });
    (function load(attempt){
        var started=Date.now();
        ctl=window.AbortController?new AbortController():null;
        fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'X-Soft-Nav':'1'},signal:ctl?ctl.signal:undefined})
            .then(function(r){if(!r.ok)throw new Error('http '+r.status);return r.text()})
            .then(function(t){
                var j=JSON.parse(t),key=window.__ultimaXorKey;
                if(!j||typeof j.p!=='string'||!key)throw new Error('payload');
                apply(xdec(j.p,key),Date.now()-started);
            })
            .catch(function(){
                if(main.__blocksGen!==token)return;
                if(attempt<2)setTimeout(function(){load(attempt+1)},800*(attempt+1));
            });
    })(0);
})();
</script>
JS;
    }
}
