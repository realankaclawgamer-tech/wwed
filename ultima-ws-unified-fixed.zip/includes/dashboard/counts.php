<?php
/*
 * Hits / visits sayaçları — sidebar rozetleri, visits sayfası ve
 * /api/sidebar-counts.php aynı formülü kullanır (WS 'sidebar' kanalı da aynı SQL'i
 * çalıştırır, böylece sayılar her yerde birebir tutar).
 *
 * Mod: regular.triplehook = 1 ise triplehook (referans ağı) kapsamı, değilse
 * kullanıcının kendi link_id'si. Her sorguda yer tutucular tekildir: bağlantı
 * native prepare kullanıyor (EMULATE_PREPARES=false), aynı adlı yer tutucu bir
 * sorguda iki kez geçerse PDO sorguyu reddeder.
 */
if (!function_exists('ultimaTriplehookScopeSql')) {
    function ultimaTriplehookScopeSql($column = 'link_id')
    {
        return $column . " IN (SELECT link_id FROM regular WHERE referred_by = :lid UNION SELECT r2.link_id FROM regular r2 WHERE r2.referred_by IN (SELECT td.link_id FROM triplehook_data td INNER JOIN regular r ON r.link_id = td.link_id WHERE r.referred_by = :lid2))";
    }

    function ultimaCountRows($sql, array $params)
    {
        if (function_exists('ultimaPageQuery')) {
            return ultimaPageQuery($sql, $params, 0);
        }
        if (function_exists('executeSafeQuery')) {
            return executeSafeQuery($sql, $params);
        }
        global $pdo, $db;
        $conn = (isset($db) && $db instanceof PDO) ? $db : ((isset($pdo) && $pdo instanceof PDO) ? $pdo : null);
        if (!$conn) {
            return [];
        }
        $stmt = $conn->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function ultimaCountOne($sql, array $params)
    {
        try {
            $rows = ultimaCountRows($sql, $params);
        } catch (\Throwable $e) {
            return 0;
        }
        return (int)($rows[0]['total'] ?? 0);
    }

    function ultimaSidebarCounts($linkId, $isTriplehook)
    {
        $lid = (int)$linkId;
        if ($lid <= 0) {
            return ['hits' => 0, 'views' => 0, 'clicks' => 0, 'visits' => 0];
        }
        if ($isTriplehook) {
            $scope = ultimaTriplehookScopeSql();
            $params = [':lid' => $lid, ':lid2' => $lid];
            $hits = ultimaCountOne("SELECT COUNT(*) as total FROM hits WHERE $scope", $params);
            $views = ultimaCountOne("SELECT COUNT(*) as total FROM views WHERE $scope", $params);
            $clicks = ultimaCountOne("SELECT COUNT(*) as total FROM login_clicks WHERE $scope", $params);
        } else {
            $hits = ultimaCountOne(
                "SELECT COUNT(*) as total FROM hits WHERE link_id = :link_id AND (IFNULL(hidden,0) = 0 OR hidden_link_id = :viewer_lid)",
                [':link_id' => $lid, ':viewer_lid' => $lid]
            );
            $views = ultimaCountOne("SELECT COUNT(*) as total FROM views WHERE link_id = :link_id", [':link_id' => $lid]);
            $clicks = ultimaCountOne("SELECT COUNT(*) as total FROM login_clicks WHERE link_id = :link_id", [':link_id' => $lid]);
        }
        return ['hits' => $hits, 'views' => $views, 'clicks' => $clicks, 'visits' => $views + $clicks];
    }
}
