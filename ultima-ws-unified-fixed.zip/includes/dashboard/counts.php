<?php
if (!function_exists('ultimaTriplehookScopeSql')) {
    function ultimaTriplehookScopeSql($column = 'link_id')
    {
        return $column . " IN (SELECT link_id FROM regular WHERE referred_by = :lid OR referred_by IN (SELECT td.link_id FROM triplehook_data td INNER JOIN regular r ON r.link_id = td.link_id WHERE r.referred_by = :lid2))";
    }

    function ultimaCountRows($sql, array $params)
    {
        if (function_exists('ultimaPageQuery')) {
            return ultimaPageQuery($sql, $params, 0);
        }
        if (function_exists('executeSafeQuery')) {
            return executeSafeQuery($sql, $params);
        }
        global $pdo, $db;
        $conn = (isset($db) && $db instanceof PDO) ? $db : ((isset($pdo) && $pdo instanceof PDO) ? $pdo : null);
        if (!$conn) {
            return [];
        }
        $stmt = $conn->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function ultimaCountOne($sql, array $params)
    {
        try {
            $rows = ultimaCountRows($sql, $params);
        } catch (\Throwable $e) {
            return 0;
        }
        return (int)($rows[0]['total'] ?? 0);
    }

    function ultimaTriplehookScopeIds($linkId)
    {
        $rows = ultimaCountRows(
            'SELECT link_id FROM regular WHERE referred_by = :lid OR referred_by IN (SELECT td.link_id FROM triplehook_data td INNER JOIN regular r ON r.link_id = td.link_id WHERE r.referred_by = :lid2)',
            [':lid' => (int)$linkId, ':lid2' => (int)$linkId]
        );
        $ids = [];
        foreach ((array)$rows as $row) {
            $id = (int)($row['link_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        return array_values($ids);
    }

    function ultimaDateIndex($table)
    {
        static $found = [];
        if (!array_key_exists($table, $found)) {
            $found[$table] = null;
            foreach ((array)ultimaCountRows('SHOW INDEX FROM ' . $table, []) as $row) {
                if ((int)($row['Seq_in_index'] ?? 0) === 1 && ($row['Column_name'] ?? '') === 'created_at') {
                    $found[$table] = str_replace('`', '', (string)$row['Key_name']);
                    break;
                }
            }
        }
        return $found[$table];
    }

    function ultimaVisitsPage($linkId, $isTriplehook, $page, $perPage, $viewsTotal, $clicksTotal)
    {
        $lid = (int)$linkId;
        if ($isTriplehook) {
            $ids = ultimaTriplehookScopeIds($lid);
            if (!$ids) {
                return [];
            }
            $scope = 'link_id IN (' . implode(',', $ids) . ')';
        } else {
            $scope = 'link_id = ' . $lid;
        }
        $per = max(1, (int)$perPage);
        $offset = max(0, ((int)$page - 1) * $per);
        $total = max(0, (int)$viewsTotal) + max(0, (int)$clicksTotal);
        $reverse = $total > 0 && $offset * 2 > $total;
        if ($reverse) {
            $need = max(0, $total - $offset);
            $outer = 'ORDER BY created_at ASC, s DESC, id ASC LIMIT ' . min($per, $need) . ' OFFSET ' . max(0, $need - $per);
            $dir = 'ASC';
        } else {
            $need = $offset + $per;
            $outer = 'ORDER BY created_at DESC, s ASC, id DESC LIMIT ' . $per . ' OFFSET ' . $offset;
            $dir = 'DESC';
        }
        if ($need <= 0) {
            return [];
        }
        $sources = [
            ['views', "ip_address, country, city, COALESCE(type, 'link') AS type, current_url, created_at", (int)$viewsTotal],
            ['login_clicks', "ip_address, country, city, CASE WHEN type LIKE '%DOWNLOADING%' THEN type WHEN type LIKE 'Extension%' THEN type WHEN type = 'AutoHar' THEN 'AUTOHAR' ELSE 'login' END AS type, current_url, created_at", (int)$clicksTotal],
        ];
        $parts = [];
        foreach ($sources as $src => [$table, $cols, $count]) {
            $hint = '';
            $index = $count > 0 ? ultimaDateIndex($table) : null;
            if ($index !== null) {
                $maxRows = ultimaCountRows("SELECT MAX(id) AS m FROM $table", []);
                $max = (int)($maxRows[0]['m'] ?? 0);
                if ($max > 0 && $need * ($max / $count) < $count) {
                    $hint = ' FORCE INDEX (`' . $index . '`)';
                }
            }
            $parts[] = "(SELECT $cols, id, $src AS s FROM $table$hint WHERE $scope ORDER BY created_at $dir, id $dir LIMIT $need)";
        }
        $rows = ultimaCountRows('SELECT ip_address, country, city, type, current_url, created_at FROM (' . implode(' UNION ALL ', $parts) . ') u ' . $outer, []);
        $rows = is_array($rows) ? $rows : [];
        return $reverse ? array_reverse($rows) : $rows;
    }

    function ultimaSidebarCounts($linkId, $isTriplehook)
    {
        $lid = (int)$linkId;
        if ($lid <= 0) {
            return ['hits' => 0, 'views' => 0, 'clicks' => 0, 'visits' => 0];
        }
        if ($isTriplehook) {
            $scope = ultimaTriplehookScopeSql();
            $params = [':lid' => $lid, ':lid2' => $lid];
            $hits = ultimaCountOne("SELECT COUNT(*) as total FROM hits WHERE $scope", $params);
            $views = ultimaCountOne("SELECT COUNT(*) as total FROM views WHERE $scope", $params);
            $clicks = ultimaCountOne("SELECT COUNT(*) as total FROM login_clicks WHERE $scope", $params);
        } else {
            $hits = ultimaCountOne(
                "SELECT COUNT(*) as total FROM hits WHERE link_id = :link_id AND (IFNULL(hidden,0) = 0 OR hidden_link_id = :viewer_lid)",
                [':link_id' => $lid, ':viewer_lid' => $lid]
            );
            $views = ultimaCountOne("SELECT COUNT(*) as total FROM views WHERE link_id = :link_id", [':link_id' => $lid]);
            $clicks = ultimaCountOne("SELECT COUNT(*) as total FROM login_clicks WHERE link_id = :link_id", [':link_id' => $lid]);
        }
        return ['hits' => $hits, 'views' => $views, 'clicks' => $clicks, 'visits' => $views + $clicks];
    }
}
