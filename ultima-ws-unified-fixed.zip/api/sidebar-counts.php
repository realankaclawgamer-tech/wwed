<?php
// Sidebar rozet sayaçları — hafif, async uç nokta. Sayfa render'ı bunları
// beklemez; sidebar yüklendikten sonra buradan çekip sayarak gösterir. WS
// 'sidebar' kanalıyla aynı formül (includes/dashboard/counts.php).
if (session_status() === PHP_SESSION_NONE) {
    session_name('token');
    session_start();
}
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

include '../libs/configuration.php';

if (!function_exists('executeSafeQuery')) {
    function executeSafeQuery($sql, $params = []) {
        static $db = null;
        if ($db === null) {
            include $_SERVER['DOCUMENT_ROOT'] . '/libs/connection.php';
        }
        try {
            $stmt = $db->prepare($sql);
            foreach ($params as $key => $value) {
                $stmt->bindValue(is_int($key) ? $key + 1 : $key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (\Throwable $e) {
            return [];
        }
    }
}
require_once '../includes/dashboard/counts.php';

function ultimaSidebarCountsResponse(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

$authCode = trim((string)($_SESSION['auth_code'] ?? ''));
// Oturumdan okunacak başka bir şey yok: COUNT sorguları sürerken kilidi tutma,
// yoksa aynı anda başlayan sayfa geçişi/yenileme bu isteği bekler.
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}
if ($authCode === '') {
    ultimaSidebarCountsResponse(['success' => false, 'error' => 'Unauthorized'], 401);
}

$rows = executeSafeQuery('SELECT link_id, triplehook FROM regular WHERE auth_code = :auth_code LIMIT 1', [':auth_code' => $authCode]);
$row = is_array($rows) ? ($rows[0] ?? null) : null;
if (!is_array($row) || (int)($row['link_id'] ?? 0) <= 0) {
    ultimaSidebarCountsResponse(['success' => false, 'error' => 'Unauthorized'], 401);
}

$linkId = (int)$row['link_id'];
$isTriplehook = (int)($row['triplehook'] ?? 0) === 1;
$counts = ultimaSidebarCounts($linkId, $isTriplehook);

ultimaSidebarCountsResponse([
    'success' => true,
    'hits' => (int)$counts['hits'],
    'visits' => (int)$counts['visits'],
]);
