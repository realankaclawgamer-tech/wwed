<?php
require __DIR__ . '/vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use React\EventLoop\Loop;
use React\Socket\SocketServer;

const DB_HOST = '127.0.0.1';
const DB_NAME = 'database';
const DB_USER = 'ws_reader';
const DB_PASS = 'abckenlegit';

const SESSION_PATH = '/var/lib/php/sessions';
const SESSION_COOKIE_NAME = 'token';

const LISTEN_HOST = '127.0.0.1';
const LISTEN_PORT = 9094;

const MAX_CONNECTIONS = 500;
const MAX_CONNECTIONS_PER_IP = 20;
const MAX_ROWS = 6;
const VISITS_WINDOW_MINUTES = 5;
const HITS_WINDOW_NOREF_SECONDS = 1200;
const HITS_WINDOW_HASREF_SECONDS = 43200;
const DB_PING_INTERVAL = 60;
const ENCRYPT_KEY_HEX = 'a7f3d1b9c8e2547809badcfe12345678abcdef0123456789fedcba9876543210';

const WS_VERSION = '2026.09.27-log2';
const SESSION_DIRS = [SESSION_PATH, '/var/www/vhosts/app.ultima.cl/session', '/var/www/vhosts/app.beamse.pro/session'];
const HEALTH_INTERVAL = 60;
const SLOW_TICK_MS = 300;
const SHORT_LIVED_SECONDS = 3;

function ws_encrypt(array $data): string {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    $key = hex2bin(ENCRYPT_KEY_HEX);
    $iv = random_bytes(16);
    $ct = openssl_encrypt($json, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $ct);
}

function ws_log(string $msg): void {
    error_log('[ws4] [' . date('Y-m-d H:i:s') . '] ' . $msg);
}

function ws_header($conn, string $name): string {
    try {
        $req = $conn->httpRequest ?? null;
        return $req ? trim($req->getHeaderLine($name)) : '';
    } catch (\Throwable $e) {
        return '';
    }
}

function ws_peer_ip($conn): string {
    $ip = trim((string)($conn->remoteAddress ?? ''), '[] ');
    if (str_starts_with($ip, 'tcp://')) $ip = substr($ip, 6);
    if (substr_count($ip, ':') === 1) $ip = explode(':', $ip)[0];
    return $ip;
}

function ws_client_ip($conn): string {
    foreach (['X-Forwarded-For', 'X-Real-IP', 'CF-Connecting-IP'] as $h) {
        $first = trim(explode(',', ws_header($conn, $h))[0]);
        if ($first !== '' && filter_var($first, FILTER_VALIDATE_IP)) return $first;
    }
    return ws_peer_ip($conn);
}

function ws_ip_limited(string $ip): bool {
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

function ws_token($conn): ?string {
    foreach (explode(';', ws_header($conn, 'Cookie')) as $part) {
        $part = trim($part);
        if (str_starts_with($part, SESSION_COOKIE_NAME . '=')) return rawurldecode(substr($part, strlen(SESSION_COOKIE_NAME) + 1));
    }
    return null;
}

function ws_auth_diag($conn): string {
    if (!($conn->httpRequest ?? null)) return 'http_request_yok';
    if (ws_header($conn, 'Cookie') === '') return 'cookie_header_yok (tarayıcı/proxy çerez göndermiyor)';
    $token = ws_token($conn);
    if ($token === null) return SESSION_COOKIE_NAME . '_cookie_yok';
    if (!preg_match('/^[a-zA-Z0-9,\-]+$/', $token)) return 'gecersiz_token_formati';
    $blocked = [];
    foreach (SESSION_DIRS as $dir) {
        $file = $dir . '/sess_' . $token;
        if (is_file($file)) {
            if (!is_readable($file)) {
                $owner = @fileowner($file);
                $name = function_exists('posix_getpwuid') && $owner !== false ? (posix_getpwuid($owner)['name'] ?? $owner) : $owner;
                return 'session_dosyasi_okunamiyor ' . $file . ' sahip=' . $name . ' mod=' . substr(sprintf('%o', (int)@fileperms($file)), -4) . ' daemon_user=' . ws_daemon_user();
            }
            $raw = (string)@file_get_contents($file);
            if ($raw === '') return 'session_bos (oturum kapanmis) ' . $file;
            if (!str_contains($raw, 'link_id')) return 'session_link_id_yok (giris yapilmamis/oturum dusmus) ' . $file;
            return 'session_gecerli_ama_reddedildi (db=' . Db::state() . ')';
        }
        if (is_dir($dir) && !is_executable($dir)) $blocked[] = $dir;
    }
    if ($blocked) return 'session_klasorune_erisim_yok ' . implode(',', $blocked) . ' daemon_user=' . ws_daemon_user();
    return 'session_dosyasi_bulunamadi (oturum suresi dolmus veya farkli sunucu/klasor) token=' . substr($token, 0, 6) . '…';
}

function ws_daemon_user(): string {
    if (function_exists('posix_geteuid') && function_exists('posix_getpwuid')) {
        return (posix_getpwuid(posix_geteuid())['name'] ?? (string)posix_geteuid());
    }
    return (string)getmyuid();
}

function ws_short(string $s, int $max = 90): string {
    $s = preg_replace('/\s+/', ' ', $s);
    return mb_strlen($s) > $max ? mb_substr($s, 0, $max) . '…' : $s;
}

final class WsLog {
    private static array $windows = [];
    private static array $conns = [];
    private static array $stats = [];
    private static array $ticks = [];

    public static function limited(string $key, string $msg, int $burst = 5, int $per = 10): void {
        $now = time();
        $w = self::$windows[$key] ?? null;
        if ($w === null || $now - $w['start'] >= $per) {
            if ($w !== null && $w['dropped'] > 0) {
                ws_log('  …' . $w['dropped'] . ' benzer satır gizlendi (' . $key . ', ' . ($now - $w['start']) . ' sn)');
            }
            $w = ['start' => $now, 'n' => 0, 'dropped' => 0];
        }
        if ($w['n'] < $burst) {
            $w['n']++;
            ws_log($msg);
        } else {
            $w['dropped']++;
        }
        self::$windows[$key] = $w;
    }

    private static function count(string $group, string $key, int $by = 1): void {
        self::$stats[$group][$key] = (self::$stats[$group][$key] ?? 0) + $by;
    }

    public static function open($conn, string $route): void {
        $id = (int)($conn->resourceId ?? 0);
        $ip = ws_client_ip($conn);
        $peer = ws_peer_ip($conn);
        $query = '';
        try { $query = (string)$conn->httpRequest->getUri()->getQuery(); } catch (\Throwable $e) {}
        self::$conns[$id] = [
            'route' => $route,
            'ip' => $ip,
            'at' => microtime(true),
            'reason' => null,
        ];
        self::count('open', $route);
        self::count('ip', $ip);
        $origin = ws_header($conn, 'Origin');
        $referer = ws_header($conn, 'Referer');
        $ua = ws_header($conn, 'User-Agent');
        self::limited('open:' . $ip . $route,
            'open #' . $id . ' route=' . $route . ($query !== '' ? '?' . ws_short($query, 80) : '')
            . ' ip=' . $ip . ($peer !== $ip ? ' (proxy=' . $peer . ')' : ' (XFF yok)')
            . ' cookie=' . (ws_token($conn) !== null ? 'var' : 'YOK')
            . ' origin=' . ($origin !== '' ? ws_short($origin, 60) : '-')
            . ($referer !== '' ? ' referer=' . ws_short($referer, 80) : '')
            . ' ua=' . ($ua !== '' ? ws_short($ua, 70) : '-'));
    }

    public static function reject($conn, string $hub, string $reason, string $detail = ''): void {
        $id = (int)($conn->resourceId ?? 0);
        $ip = self::$conns[$id]['ip'] ?? ws_client_ip($conn);
        if (isset(self::$conns[$id]) && self::$conns[$id]['reason'] === null) self::$conns[$id]['reason'] = $hub . ':' . $reason;
        self::count('reject', $hub . ':' . $reason);
        self::limited('reject:' . $reason . ':' . $ip . ':' . strtok($detail . ' ', ' '),
            'REDDEDİLDİ #' . $id . ' hub=' . $hub . ' sebep=' . $reason . ' ip=' . $ip . ($detail !== '' ? ' -> ' . $detail : ''), 3, 30);
    }

    public static function close($conn): void {
        $id = (int)($conn->resourceId ?? 0);
        $info = self::$conns[$id] ?? null;
        unset(self::$conns[$id]);
        if ($info === null) return;
        $life = microtime(true) - $info['at'];
        self::count('close', $info['route']);
        if ($life < SHORT_LIVED_SECONDS) self::count('short', $info['route'] . ' ' . ($info['reason'] ?? 'sebepsiz(istemci kapattı)'));
        self::limited('close:' . $info['ip'] . $info['route'],
            'close #' . $id . ' route=' . $info['route'] . ' ip=' . $info['ip'] . ' süre=' . self::duration($life)
            . ($info['reason'] !== null ? ' sebep=' . $info['reason'] : ($life < SHORT_LIVED_SECONDS ? ' sebep=istemci/proxy kapattı (sunucu reddetmedi)' : '')));
    }

    public static function error($conn, string $where, \Throwable $e): void {
        $id = (int)($conn->resourceId ?? 0);
        self::count('error', $where);
        self::limited('error:' . $where . ':' . get_class($e), 'HATA #' . $id . ' ' . $where . ': ' . get_class($e) . ' ' . ws_short($e->getMessage(), 200), 3, 30);
    }

    public static function tick(string $hub, float $ms, ?\Throwable $e): void {
        $t = self::$ticks[$hub] ?? ['n' => 0, 'sum' => 0.0, 'max' => 0.0, 'slow' => 0, 'fail' => 0];
        $t['n']++;
        $t['sum'] += $ms;
        $t['max'] = max($t['max'], $ms);
        if ($ms >= SLOW_TICK_MS) {
            $t['slow']++;
            self::limited('slow:' . $hub, 'YAVAŞ TICK hub=' . $hub . ' ' . round($ms) . 'ms (döngü bu sürede başka işi yapamaz)', 2, 60);
        }
        if ($e !== null) {
            $t['fail']++;
            self::limited('tickerr:' . $hub . ':' . get_class($e), 'TICK HATASI hub=' . $hub . ': ' . get_class($e) . ' ' . ws_short($e->getMessage(), 200) . ' @' . basename($e->getFile()) . ':' . $e->getLine(), 2, 60);
        }
        self::$ticks[$hub] = $t;
    }

    private static function duration(float $s): string {
        if ($s < 1) return round($s * 1000) . 'ms';
        if ($s < 120) return round($s, 1) . 'sn';
        if ($s < 7200) return round($s / 60, 1) . 'dk';
        return round($s / 3600, 1) . 'sa';
    }

    private static function top(array $counts, int $n = 5): string {
        if (!$counts) return '-';
        arsort($counts);
        $out = [];
        foreach (array_slice($counts, 0, $n, true) as $k => $v) $out[] = $k . '=' . $v;
        return implode(' ', $out);
    }

    public static function health(array $routes, array $hubs): void {
        $now = time();
        foreach (self::$windows as $key => $w) {
            if ($now - $w['start'] < 10) continue;
            if ($w['dropped'] > 0) ws_log('  …' . $w['dropped'] . ' benzer satır gizlendi (' . $key . ', ' . ($now - $w['start']) . ' sn)');
            unset(self::$windows[$key]);
        }
        $s = self::$stats;
        $ticks = [];
        foreach (self::$ticks as $hub => $t) {
            $ticks[] = $hub . '=' . round($t['sum'] / max(1, $t['n'])) . '/' . round($t['max']) . 'ms' . ($t['slow'] ? ' yavaş=' . $t['slow'] : '') . ($t['fail'] ? ' hata=' . $t['fail'] : '');
        }
        ws_log('SAĞLIK v' . WS_VERSION . ' bağlı=' . array_sum($routes) . ' [' . self::top($routes, 10) . ']'
            . ' kanal=[' . self::top($hubs, 10) . ']'
            . ' | son ' . HEALTH_INTERVAL . 'sn: açılan=[' . self::top($s['open'] ?? []) . '] kapanan=[' . self::top($s['close'] ?? []) . ']'
            . ' red=[' . self::top($s['reject'] ?? [], 8) . ']'
            . ' kısa_ömürlü(<' . SHORT_LIVED_SECONDS . 'sn)=[' . self::top($s['short'] ?? [], 6) . ']'
            . ' hata=[' . self::top($s['error'] ?? []) . ']'
            . ' en_çok_bağlanan_ip=[' . self::top($s['ip'] ?? [], 5) . ']'
            . ' | tick ort/max=[' . ($ticks ? implode(' ', $ticks) : '-') . ']'
            . ' | db=' . Db::state() . ' async=' . AsyncSql::state()
            . ' | bellek=' . round(memory_get_usage(true) / 1048576, 1) . 'MB tepe=' . round(memory_get_peak_usage(true) / 1048576, 1) . 'MB');
        self::$stats = [];
        self::$ticks = [];
    }
}

final class Db {
    private static ?\PDO $pdo = null;
    private static array $owners = [];
    private static bool $broken = false;
    private static float $triedAt = 0.0;
    private static float $brokenAt = 0.0;
    private static int $failures = 0;
    private static string $lastError = '';

    public static function state(): string {
        if (self::$pdo === null) return 'bağlanmadı';
        if (!self::$broken) return 'ok';
        return 'KOPUK(' . round(microtime(true) - self::$brokenAt) . 'sn, ' . self::$failures . ' deneme: ' . ws_short(self::$lastError, 80) . ')';
    }

    public static function isLost(\Throwable $e): bool {
        return (bool)preg_match('/\b(2002|2003|2006|2013|2055|1927|4031)\b|gone away|lost connection|connection was killed|server closed|error while sending|no connection|broken pipe|connection refused/i', $e->getMessage());
    }

    private static function connect(): \PDO {
        return new LivePdo('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES => false,
            \PDO::ATTR_TIMEOUT => 5,
            \PDO::ATTR_STATEMENT_CLASS => [LiveStatement::class],
        ]);
    }

    public static function shared(object $owner, callable $set): \PDO {
        self::$owners[spl_object_id($owner)] = $set;
        if (self::$pdo === null) {
            try {
                self::$pdo = self::connect();
            } catch (\Throwable $e) {
                ws_log('DB BAĞLANTISI KURULAMADI (' . DB_HOST . '/' . DB_NAME . ' kullanıcı=' . DB_USER . '): ' . $e->getMessage());
                throw $e;
            }
        }
        return self::$pdo;
    }

    public static function lost(\Throwable $e, string $sql = ''): void {
        if (!self::isLost($e)) {
            if ($sql !== '') {
                $where = ws_short(trim($sql), 110);
                WsLog::limited('sql:' . md5($sql), 'SQL HATASI: ' . ws_short($e->getMessage(), 200) . ' | sorgu: ' . $where, 1, 300);
            }
            return;
        }
        if (!self::$broken) {
            self::$brokenAt = microtime(true);
            self::$failures = 0;
            ws_log('DB bağlantısı koptu: ' . ws_short($e->getMessage(), 200) . ' — yeniden bağlanılıyor');
        }
        self::$lastError = $e->getMessage();
        self::$broken = true;
    }

    public static function reconnect(): bool {
        $now = microtime(true);
        if ($now - self::$triedAt < 1.0) return false;
        self::$triedAt = $now;
        if (!self::$broken) self::$brokenAt = $now;
        try {
            $pdo = self::connect();
        } catch (\Throwable $e) {
            self::$broken = true;
            self::$failures++;
            self::$lastError = $e->getMessage();
            WsLog::limited('db:reconnect', 'DB yeniden bağlanma başarısız (' . self::$failures . '. deneme): ' . ws_short($e->getMessage(), 200), 3, 60);
            return false;
        }
        ws_log('DB yeniden bağlandı (' . round($now - self::$brokenAt, 1) . ' sn kopuk kaldı, ' . (self::$failures + 1) . ' deneme)');
        self::$pdo = $pdo;
        self::$broken = false;
        self::$failures = 0;
        foreach (self::$owners as $set) {
            try { $set($pdo); } catch (\Throwable $e) {}
        }
        return true;
    }

    public static function heal(): void {
        if (self::$broken) self::reconnect();
    }
}

final class LivePdo extends \PDO {
    public function prepare(string $query, array $options = []): \PDOStatement|false {
        try { return parent::prepare($query, $options); } catch (\Throwable $e) { Db::lost($e, $query); throw $e; }
    }

    public function query(string $query, ?int $fetchMode = null, mixed ...$fetchModeArgs): \PDOStatement|false {
        try {
            return $fetchMode === null ? parent::query($query) : parent::query($query, $fetchMode, ...$fetchModeArgs);
        } catch (\Throwable $e) { Db::lost($e, $query); throw $e; }
    }

    public function exec(string $statement): int|false {
        try { return parent::exec($statement); } catch (\Throwable $e) { Db::lost($e, $statement); throw $e; }
    }
}

class LiveStatement extends \PDOStatement {
    protected function __construct() {}

    public function execute(?array $params = null): bool {
        try { return parent::execute($params); } catch (\Throwable $e) { Db::lost($e, $this->queryString); throw $e; }
    }
}

function ws_tick(string $hub, callable $fn): \Closure {
    return function () use ($hub, $fn) {
        $t = microtime(true);
        $error = null;
        try {
            Db::heal();
            $fn();
        } catch (\Throwable $e) {
            $error = $e;
        }
        WsLog::tick($hub, (microtime(true) - $t) * 1000, $error);
    };
}

final class AsyncSql {
    private const POOL = 2;
    private static array $idle = [];
    private static array $busy = [];
    private static array $queue = [];
    private static $timer = null;

    public static function available(): bool {
        return class_exists('mysqli') && defined('MYSQLI_ASYNC') && function_exists('mysqli_poll');
    }

    public static function state(): string {
        if (!self::available()) return 'yok(mysqli)';
        return 'boşta=' . count(self::$idle) . ' meşgul=' . count(self::$busy) . ' kuyruk=' . count(self::$queue);
    }

    private static function connect(): ?\mysqli {
        try {
            mysqli_report(MYSQLI_REPORT_OFF);
            $m = mysqli_init();
            $m->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, 1);
            if (!@$m->real_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME)) {
                WsLog::limited('async:connect', 'AsyncSql bağlantısı kurulamadı: ' . ws_short((string)$m->connect_error, 200), 2, 60);
                return null;
            }
            $m->set_charset('utf8mb4');
            return $m;
        } catch (\Throwable $e) {
            WsLog::limited('async:connect', 'AsyncSql bağlantısı kurulamadı: ' . ws_short($e->getMessage(), 200), 2, 60);
            return null;
        }
    }

    public static function all(array $sqls, callable $done): void {
        if ($sqls === []) {
            $done([]);
            return;
        }
        $results = [];
        $left = count($sqls);
        $failed = false;
        foreach ($sqls as $key => $sql) {
            self::$queue[] = [$sql, function (?array $rows) use ($key, &$results, &$left, &$failed, $done) {
                if ($rows === null) $failed = true;
                $results[$key] = $rows;
                if (--$left === 0) $done($failed ? null : $results);
            }];
        }
        self::pump();
    }

    private static function pump(): void {
        while (self::$queue && (self::$idle || count(self::$busy) < self::POOL)) {
            $m = array_pop(self::$idle) ?: self::connect();
            [$sql, $cb] = array_shift(self::$queue);
            if (!$m || !$m->query($sql, MYSQLI_ASYNC)) {
                if ($m) {
                    WsLog::limited('async:query', 'AsyncSql sorgu gönderilemedi: ' . ws_short((string)$m->error, 200), 2, 60);
                    $m->close();
                }
                $cb(null);
                continue;
            }
            self::$busy[spl_object_id($m)] = [$m, $cb];
        }
        if (self::$busy && self::$timer === null) {
            self::$timer = Loop::get()->addPeriodicTimer(0.01, function () {
                try { self::poll(); } catch (\Throwable $e) {
                    WsLog::limited('async:poll', 'AsyncSql poll hatası: ' . ws_short($e->getMessage(), 200), 2, 60);
                }
            });
        }
    }

    public static function poll(): void {
        if (!self::$busy) {
            if (self::$timer !== null) {
                Loop::get()->cancelTimer(self::$timer);
                self::$timer = null;
            }
            return;
        }
        $read = $error = $reject = [];
        foreach (self::$busy as [$m]) {
            $read[] = $m;
            $error[] = $m;
            $reject[] = $m;
        }
        if (mysqli_poll($read, $error, $reject, 0, 0) === false) return;
        foreach (array_merge($read, $error, $reject) as $m) {
            $id = spl_object_id($m);
            if (!isset(self::$busy[$id])) continue;
            $cb = self::$busy[$id][1];
            unset(self::$busy[$id]);
            $res = $m->reap_async_query();
            $rows = null;
            if ($res instanceof \mysqli_result) {
                $rows = $res->fetch_all(MYSQLI_ASSOC);
                $res->free();
            } elseif ($res === true) {
                $rows = [];
            }
            if ($rows === null) {
                WsLog::limited('async:reap', 'AsyncSql sorgu hatası: ' . ws_short((string)$m->error, 200), 2, 60);
                $m->close();
            } else {
                self::$idle[] = $m;
            }
            try { $cb($rows); } catch (\Throwable $e) {
                WsLog::limited('async:cb', 'AsyncSql sonuç işleme hatası: ' . ws_short($e->getMessage(), 200) . ' @' . basename($e->getFile()) . ':' . $e->getLine(), 2, 60);
            }
        }
        self::pump();
    }

    public static function inline(string $sql, array $params): string {
        uksort($params, fn($a, $b) => strlen((string)$b) <=> strlen((string)$a));
        foreach ($params as $name => $value) {
            if (is_int($value) || (is_string($value) && preg_match('/^-?\d{1,18}$/', $value))) $literal = (string)(int)$value;
            elseif ($value === null) $literal = 'NULL';
            else $literal = "'" . str_replace(["\\", "'", "\0"], ["\\\\", "\\'", ''], (string)$value) . "'";
            $sql = preg_replace('/' . preg_quote((string)$name, '/') . '(?![A-Za-z0-9_])/', $literal, $sql);
        }
        return $sql;
    }
}

final class LiveScope {
    private const LATE = 200;
    private const MAX_ROWS = 2000;
    private const KEEP = 120;
    private static ?\PDO $pdo = null;
    private static ?array $max = null;
    private static array $seen = [];
    private static string $structure = '';
    private static float $polledAt = 0.0;
    private static float $structureAt = 0.0;
    private static int $seq = 0;
    private static array $batches = [];
    private static array $sets = [];
    private static string $today = '';
    private static string $weekStart = '';

    private static function db(): \PDO {
        if (self::$pdo === null) {
            self::$pdo = new \PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                \PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        }
        return self::$pdo;
    }

    public static function rows(string $sql, array $params = []): array {
        for ($attempt = 0; ; $attempt++) {
            try {
                $stmt = self::db()->prepare($sql);
                $stmt->execute($params);
                return $stmt->fetchAll();
            } catch (\Throwable $e) {
                self::$pdo = null;
                if ($attempt >= 1) throw $e;
            }
        }
    }

    public static function today(): string { return self::$today !== '' ? self::$today : date('Y-m-d'); }
    public static function weekStart(): string { return self::$weekStart !== '' ? self::$weekStart : date('Y-m-d', strtotime('monday this week')); }
    public static function cursor(): int { return self::$seq; }
    public static function maxHit(): int { return (int)(self::$max['hits'] ?? 0); }
    public static function maxOf(string $key): int { return (int)(self::$max[$key] ?? 0); }

    private static function newRows(string $table, string $cols, string $key, int $current, array &$batch): void {
        $from = max(0, self::$max[$key] - self::LATE);
        $rows = self::rows("SELECT $cols FROM $table WHERE id > :from ORDER BY id LIMIT " . (self::MAX_ROWS + 1), [':from' => $from]);
        if (count($rows) > self::MAX_ROWS) $batch['overflow'] = true;
        foreach ($rows as $row) {
            $id = (int)$row['id'];
            if (isset(self::$seen[$key][$id])) continue;
            self::$seen[$key][$id] = true;
            $batch[$key][] = $row;
            $batch[$key . '_links'][(int)$row['link_id']] = true;
        }
        self::$max[$key] = max(self::$max[$key], $current);
        $floor = self::$max[$key] - 2 * self::LATE;
        foreach (self::$seen[$key] as $id => $unused) {
            if ($id <= $floor) unset(self::$seen[$key][$id]);
        }
    }

    public static function poll(): void {
        $now = microtime(true);
        if ($now - self::$polledAt < 0.4) return;
        self::$polledAt = $now;
        try {
            $m = self::rows("SELECT COALESCE((SELECT MAX(id) FROM hits),0) AS hits, COALESCE((SELECT MAX(id) FROM views),0) AS views, COALESCE((SELECT MAX(id) FROM login_clicks),0) AS clicks, CURDATE() AS today, DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) AS week_start")[0];
            self::$today = (string)$m['today'];
            self::$weekStart = (string)$m['week_start'];
            $current = ['hits' => (int)$m['hits'], 'views' => (int)$m['views'], 'clicks' => (int)$m['clicks']];
            if (self::$max === null) {
                self::$max = $current;
                foreach (['hits' => 'hits', 'views' => 'views', 'clicks' => 'login_clicks'] as $key => $table) {
                    self::$seen[$key] = [];
                    foreach (self::rows("SELECT id FROM $table WHERE id > :from", [':from' => max(0, $current[$key] - self::LATE)]) as $row) self::$seen[$key][(int)$row['id']] = true;
                }
                self::$structure = self::structureSignature();
                self::$structureAt = $now;
                return;
            }
            $batch = ['hits' => [], 'views' => [], 'clicks' => [], 'hits_links' => [], 'views_links' => [], 'clicks_links' => [], 'structure' => false, 'overflow' => false];
            if ($current['hits'] > self::$max['hits']) self::newRows('hits', 'id, link_id, username, summary, rap, robux, created_at', 'hits', $current['hits'], $batch);
            if ($current['views'] > self::$max['views']) self::newRows('views', 'id, link_id, created_at', 'views', $current['views'], $batch);
            if ($current['clicks'] > self::$max['clicks']) self::newRows('login_clicks', 'id, link_id, created_at', 'clicks', $current['clicks'], $batch);
            if ($now - self::$structureAt >= 3) {
                self::$structureAt = $now;
                $signature = self::structureSignature();
                if ($signature !== self::$structure) {
                    self::$structure = $signature;
                    self::$sets = [];
                    $batch['structure'] = true;
                }
            }
            if ($batch['hits'] || $batch['views'] || $batch['clicks'] || $batch['structure'] || $batch['overflow']) {
                self::$batches[++self::$seq] = $batch;
                if (count(self::$batches) > self::KEEP) unset(self::$batches[array_key_first(self::$batches)]);
            }
        } catch (\Throwable $e) {
        }
    }

    private static function structureSignature(): string {
        $r = self::rows("SELECT COUNT(*) AS n, COALESCE(MAX(link_id),0) AS m, COALESCE(BIT_XOR(CRC32(CONCAT_WS('|', link_id, IFNULL(referred_by, '')))),0) AS x FROM regular")[0];
        $t = self::rows('SELECT COUNT(*) AS n, COALESCE(BIT_XOR(link_id),0) AS x FROM triplehook_data')[0];
        return implode(':', [$r['n'], $r['m'], $r['x'], $t['n'], $t['x']]);
    }

    public static function since(int &$cursor): array {
        $out = ['hits' => [], 'views' => [], 'clicks' => [], 'hits_links' => [], 'views_links' => [], 'clicks_links' => [], 'structure' => false, 'overflow' => false, 'empty' => true];
        if ($cursor >= self::$seq) {
            $cursor = self::$seq;
            return $out;
        }
        $first = self::$batches ? array_key_first(self::$batches) : self::$seq + 1;
        if ($cursor + 1 < $first) $out['overflow'] = $out['structure'] = true;
        foreach (self::$batches as $seq => $batch) {
            if ($seq <= $cursor) continue;
            foreach (['hits', 'views', 'clicks'] as $key) {
                foreach ($batch[$key] as $row) $out[$key][] = $row;
                $out[$key . '_links'] += $batch[$key . '_links'];
            }
            $out['structure'] = $out['structure'] || $batch['structure'];
            $out['overflow'] = $out['overflow'] || $batch['overflow'];
        }
        $cursor = self::$seq;
        $out['empty'] = false;
        return $out;
    }

    private static function set(string $key, string $sql, array $params): array {
        if (!isset(self::$sets[$key])) {
            $ids = [];
            foreach (self::rows($sql, $params) as $row) $ids[(int)$row['link_id']] = true;
            self::$sets[$key] = $ids;
        }
        return self::$sets[$key];
    }

    public static function network(int $link): array {
        return self::set("net:$link", 'SELECT link_id FROM regular WHERE referred_by = :l OR referred_by IN (SELECT td.link_id FROM triplehook_data td INNER JOIN regular r ON r.link_id = td.link_id WHERE r.referred_by = :l2)', [':l' => $link, ':l2' => $link]);
    }

    public static function direct(int $link): array {
        return self::set("dir:$link", 'SELECT link_id FROM regular WHERE referred_by = :l', [':l' => $link]);
    }

    public static function referrerNetwork(int $referrer): array {
        return self::set("refnet:$referrer", 'SELECT r3.link_id FROM regular r3 WHERE r3.referred_by IN (SELECT td.link_id FROM triplehook_data td INNER JOIN regular r2 ON r2.link_id = td.link_id WHERE r2.referred_by = :rb)', [':rb' => $referrer]);
    }

    public static function allTriplehookReferrals(): array {
        return self::set('thref', 'SELECT link_id FROM regular WHERE referred_by IN (SELECT link_id FROM triplehook_data)', []);
    }

    public static function touches(array $set, array $links): bool {
        if (count($links) > count($set)) {
            foreach ($set as $id => $unused) if (isset($links[$id])) return true;
            return false;
        }
        foreach ($links as $id => $unused) if (isset($set[$id])) return true;
        return false;
    }
}

class MainLiveHub implements MessageComponentInterface {
    private ?\PDO $pdo = null;
    private \SplObjectStorage $clients;
    private array $perIp = [];
    private int $tickCounter = 0;
    private int $lastDbPing = 0;
    private string $lastVersion = '';
    private int $lastRefresh = 0;

    public function __construct() {
        $this->clients = new \SplObjectStorage();
        $this->connectDb();
    }

    private function connectDb(): void {
        try {
            $this->pdo = Db::shared($this, function (\PDO $pdo) { $this->pdo = $pdo; });
            $this->lastDbPing = time();
        } catch (\Throwable $e) {
            $this->pdo = null;
        }
    }

    private function ensureDb(): bool {
        $now = time();
        if ($this->pdo === null) {
            $this->connectDb();
            return $this->pdo !== null;
        }
        if (($now - $this->lastDbPing) >= DB_PING_INTERVAL) {
            try {
                $this->pdo->query('SELECT 1');
                $this->lastDbPing = $now;
            } catch (\Throwable $e) {
                Db::lost($e);
                Db::reconnect();
                return $this->pdo !== null;
            }
        }
        return true;
    }

    private function handleDbException(\Throwable $e): void {
        Db::lost($e);
    }

    private function emit(ConnectionInterface $conn, array $data): void {
        try {
            $conn->send(ws_encrypt($data));
        } catch (\Throwable $e) {
        }
    }

    public function onOpen(ConnectionInterface $conn) {
        if (count($this->clients) >= MAX_CONNECTIONS) {
            WsLog::reject($conn, 'live', 'server_full', 'bağlı=' . count($this->clients) . ' limit=' . MAX_CONNECTIONS);
            $this->emit($conn, ['type' => 'fatal', 'error' => 'server_full']);
            $conn->close();
            return;
        }

        $ip = ws_client_ip($conn);
        $limited = ws_ip_limited($ip);
        if ($limited && ($this->perIp[$ip] ?? 0) >= MAX_CONNECTIONS_PER_IP) {
            WsLog::reject($conn, 'live', 'too_many_connections', 'bu ip zaten ' . $this->perIp[$ip] . ' bağlantı açık, limit=' . MAX_CONNECTIONS_PER_IP);
            $this->emit($conn, ['type' => 'fatal', 'error' => 'too_many_connections']);
            $conn->close();
            return;
        }

        $auth = $this->authenticate($conn);
        if (!$auth) {
            WsLog::reject($conn, 'live', 'unauthorized', ws_auth_diag($conn));
            $this->emit($conn, ['type' => 'fatal', 'error' => 'unauthorized']);
            $conn->close();
            return;
        }

        if ($limited) $this->perIp[$ip] = ($this->perIp[$ip] ?? 0) + 1;

        $meta = [
            'link_id' => $auth['link_id'],
            'is_triplehook' => $auth['is_triplehook'],
            'has_referrer' => $auth['has_referrer'],
            'referred_by' => $auth['referred_by'],
            'ip' => $ip,
            'last_hits_signature' => '',
            'last_visits_signature' => '',
            'connected_at' => time(),
        ];

        $this->clients->attach($conn, $meta);
        $this->sendUpdate($conn, true);
    }

    private function authenticate(ConnectionInterface $conn): ?array {
        if (!$this->ensureDb()) return null;

        $req = $conn->httpRequest;
        if (!$req) return null;

        $cookieHeader = '';
        foreach ($req->getHeader('Cookie') as $h) { $cookieHeader .= $h . ';'; }
        if ($cookieHeader === '') return null;

        $sessionId = null;
        $parts = explode(';', $cookieHeader);
        foreach ($parts as $p) {
            $p = trim($p);
            if (str_starts_with($p, SESSION_COOKIE_NAME . '=')) {
                $sessionId = rawurldecode(substr($p, strlen(SESSION_COOKIE_NAME) + 1));
                break;
            }
        }
        if (!$sessionId || !preg_match('/^[a-zA-Z0-9,\-]+$/', $sessionId)) return null;

        $sessionFile = null;
        foreach ([SESSION_PATH, '/var/www/vhosts/app.ultima.cl/session', '/var/www/vhosts/app.beamse.pro/session'] as $sessionDir) {
            $candidate = $sessionDir . '/sess_' . $sessionId;
            if (is_file($candidate)) {
                $sessionFile = $candidate;
                break;
            }
        }
        if ($sessionFile === null) {
            return null;
        }
        if (!is_file($sessionFile) || !is_readable($sessionFile)) return null;

        $raw = @file_get_contents($sessionFile);
        if ($raw === false || $raw === '') return null;

        $data = $this->parseSession($raw);
        $linkId = $data['link_id'] ?? null;
        if (!$linkId) return null;

        $isTriplehook = false;
        $referredBy = 0;
        try {
            $stmt = $this->pdo->prepare("SELECT triplehook, referred_by FROM regular WHERE link_id = :lid LIMIT 1");
            $stmt->execute([':lid' => $linkId]);
            $row = $stmt->fetch();
            if ($row) {
                $isTriplehook = (int)$row['triplehook'] === 1;
                $referredBy = (int)($row['referred_by'] ?? 0);
            }
        } catch (\Throwable $e) {
            $this->handleDbException($e);
            return null;
        }

        return [
            'link_id' => strval($linkId),
            'is_triplehook' => $isTriplehook,
            'has_referrer' => $referredBy > 0,
            'referred_by' => $referredBy,
        ];
    }

    private function parseSession(string $raw): array {
        $result = [];
        $offset = 0;
        $len = strlen($raw);
        while ($offset < $len) {
            $pipe = strpos($raw, '|', $offset);
            if ($pipe === false) break;
            $key = substr($raw, $offset, $pipe - $offset);
            $offset = $pipe + 1;
            $val = null;
            $consumed = 0;
            try {
                $val = @unserialize(substr($raw, $offset), ['allowed_classes' => false]);
                if ($val === false && substr($raw, $offset, 2) !== 'b:') break;
                $consumed = strlen(serialize($val));
            } catch (\Throwable $e) { break; }
            $offset += $consumed;
            if (is_scalar($val) || is_array($val)) $result[$key] = $val;
        }
        return $result;
    }

    private function queryHits(array $meta): array {
        if (!$this->ensureDb()) return [];

        $params = [];
        $scopeFilter = '';

        if ($meta['is_triplehook']) {
            if ($meta['has_referrer']) {
                $scopeFilter = " AND h.link_id IN (SELECT r3.link_id FROM regular r3 WHERE r3.referred_by IN (SELECT td.link_id FROM triplehook_data td INNER JOIN regular r2 ON r2.link_id = td.link_id WHERE r2.referred_by = :referred_by))";
                $params[':referred_by'] = $meta['referred_by'];
            } else {
                $scopeFilter = " AND h.link_id IN (SELECT r3.link_id FROM regular r3 WHERE r3.referred_by IN (SELECT td.link_id FROM triplehook_data td))";
            }
            $selectFields = "h.id, h.username, h.avatar_url, h.robux, h.summary, h.rap, h.created_at,
                             r_owner.discord_username, r_owner.discord_avatar, r_owner.avatar_hidden";
            $joinClause = "FROM hits h
                            LEFT JOIN regular r_hitter ON h.link_id = r_hitter.link_id
                            LEFT JOIN regular r_owner ON r_hitter.referred_by = r_owner.link_id";
        } else {
            if ($meta['has_referrer']) {
                $scopeFilter = " AND h.link_id IN (SELECT r2.link_id FROM regular r2 WHERE r2.referred_by = :referred_by)";
                $params[':referred_by'] = $meta['referred_by'];
            }
            $selectFields = "h.id, h.username, h.avatar_url, h.robux, h.summary, h.rap, h.created_at,
                             r.discord_username, r.discord_avatar, r.avatar_hidden";
            $joinClause = "FROM hits h LEFT JOIN regular r ON h.link_id = r.link_id";
        }

        $liveSpan = ($meta['has_referrer'] ? HITS_WINDOW_HASREF_SECONDS : HITS_WINDOW_NOREF_SECONDS) * MAX_ROWS;

        try {
            $stmt = $this->pdo->prepare("
                SELECT $selectFields, UNIX_TIMESTAMP(h.created_at) AS created_ts $joinClause
                WHERE 1=1 AND h.hidden = 0 $scopeFilter
                AND h.created_at >= NOW() - INTERVAL $liveSpan SECOND
                ORDER BY h.created_at DESC
                LIMIT " . intval(MAX_ROWS) . "
            ");
            $stmt->execute($params);
            $hits = $stmt->fetchAll();

            if (!empty($hits)) {
                $window = $meta['has_referrer'] ? HITS_WINDOW_HASREF_SECONDS : HITS_WINDOW_NOREF_SECONDS;
                $nowRow = $this->pdo->query('SELECT UNIX_TIMESTAMP() AS now_ts')->fetch();
                $now = (int)($nowRow['now_ts'] ?? time());
                $times = [];
                foreach ($hits as $h) {
                    $times[] = (int)($h['created_ts'] ?? 0);
                }
                if ($times[0] === 0 || ($now - $times[0]) > $window) {
                    $hits = [];
                } else {
                    $filtered = [$hits[0]];
                    for ($i = 1; $i < count($hits); $i++) {
                        if ($times[$i] === 0) break;
                        $gap = $times[$i - 1] - $times[$i];
                        if ($gap > $window) break;
                        $filtered[] = $hits[$i];
                    }
                    $hits = $filtered;
                }
                foreach ($hits as &$h) {
                    unset($h['created_ts']);
                }
                unset($h);
            }

            return $hits;
        } catch (\Throwable $e) {
            $this->handleDbException($e);
            return [];
        }
    }

    private function queryVisits(array $meta): array {
        if (!$this->ensureDb()) return [];

        $params = [];
        $win = intval(VISITS_WINDOW_MINUTES);

        if ($meta['is_triplehook']) {
            $params[':ref1'] = $meta['link_id'];
            $params[':ref2'] = $meta['link_id'];
            $sql = "
                (SELECT v.id, CONCAT('v-', v.id) as uid, v.ip_address, v.country, v.city, 'link' as type, v.created_at
                 FROM views v
                 WHERE v.link_id IN (SELECT r2.link_id FROM regular r2 WHERE r2.referred_by = :ref1)
                 AND v.created_at >= NOW() - INTERVAL $win MINUTE)
                UNION ALL
                (SELECT lc.id, CONCAT('c-', lc.id) as uid, lc.ip_address, lc.country, lc.city, CASE WHEN lc.type = 'AutoHar' THEN 'AUTOHAR' ELSE 'login' END as type, lc.created_at
                 FROM login_clicks lc
                 WHERE lc.link_id IN (SELECT r3.link_id FROM regular r3 WHERE r3.referred_by = :ref2)
                 AND lc.created_at >= NOW() - INTERVAL $win MINUTE)
                ORDER BY created_at DESC
                LIMIT 5
            ";
        } elseif ($meta['has_referrer']) {
            $params[':ref1'] = $meta['referred_by'];
            $params[':ref2'] = $meta['referred_by'];
            $sql = "
                (SELECT v.id, CONCAT('v-', v.id) as uid, v.ip_address, v.country, v.city, 'link' as type, v.created_at
                 FROM views v
                 WHERE v.link_id IN (SELECT r2.link_id FROM regular r2 WHERE r2.referred_by = :ref1)
                 AND v.created_at >= NOW() - INTERVAL $win MINUTE)
                UNION ALL
                (SELECT lc.id, CONCAT('c-', lc.id) as uid, lc.ip_address, lc.country, lc.city, CASE WHEN lc.type = 'AutoHar' THEN 'AUTOHAR' ELSE 'login' END as type, lc.created_at
                 FROM login_clicks lc
                 WHERE lc.link_id IN (SELECT r3.link_id FROM regular r3 WHERE r3.referred_by = :ref2)
                 AND lc.created_at >= NOW() - INTERVAL $win MINUTE)
                ORDER BY created_at DESC
                LIMIT 5
            ";
        } else {
            $params[':link_id1'] = $meta['link_id'];
            $params[':link_id2'] = $meta['link_id'];
            $sql = "
                (SELECT v.id, CONCAT('v-', v.id) as uid, v.ip_address, v.country, v.city, 'link' as type, v.created_at
                 FROM views v
                 WHERE v.link_id = :link_id1
                 AND v.created_at >= NOW() - INTERVAL $win MINUTE)
                UNION ALL
                (SELECT lc.id, CONCAT('c-', lc.id) as uid, lc.ip_address, lc.country, lc.city, CASE WHEN lc.type = 'AutoHar' THEN 'AUTOHAR' ELSE 'login' END as type, lc.created_at
                 FROM login_clicks lc
                 WHERE lc.link_id = :link_id2
                 AND lc.created_at >= NOW() - INTERVAL $win MINUTE)
                ORDER BY created_at DESC
                LIMIT 5
            ";
        }

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (\Throwable $e) {
            $this->handleDbException($e);
            return [];
        }
    }

    private function hitsKey(array $meta): string {
        return ($meta['is_triplehook'] ? 't' : 'n') . ':' . ($meta['has_referrer'] ? $meta['referred_by'] : 'all');
    }

    private function visitsKey(array $meta): string {
        if (!$meta['is_triplehook'] && $meta['has_referrer']) return 'r:' . $meta['referred_by'];
        return ($meta['is_triplehook'] ? 'lt:' : 'ln:') . $meta['link_id'];
    }

    private function dataVersion(): ?string {
        try {
            $row = $this->pdo->query("SELECT (SELECT COALESCE(MAX(id),0) FROM hits) AS h, (SELECT COALESCE(MAX(id),0) FROM views) AS v, (SELECT COALESCE(MAX(id),0) FROM login_clicks) AS c")->fetch();
            return $row ? $row['h'] . ':' . $row['v'] . ':' . $row['c'] : null;
        } catch (\Throwable $e) {
            $this->handleDbException($e);
            return null;
        }
    }

    private function sendUpdate(ConnectionInterface $conn, bool $isSnapshot, ?array &$shared = null) {
        try {
            if (!$this->clients->contains($conn)) return;
            $meta = $this->clients[$conn];

            if ($shared === null) {
                $hits = $this->queryHits($meta);
                $visits = $this->queryVisits($meta);
            } else {
                $hk = 'h:' . $this->hitsKey($meta);
                $vk = 'v:' . $this->visitsKey($meta);
                if (!array_key_exists($hk, $shared)) $shared[$hk] = $this->queryHits($meta);
                if (!array_key_exists($vk, $shared)) $shared[$vk] = $this->queryVisits($meta);
                $hits = $shared[$hk];
                $visits = $shared[$vk];
            }

            $hitsSig = '';
            foreach ($hits as $h) { $hitsSig .= $h['id'] . ','; }
            $visitsSig = '';
            foreach ($visits as $v) { $visitsSig .= $v['uid'] . ','; }

            $hitsChanged = $hitsSig !== $meta['last_hits_signature'];
            $visitsChanged = $visitsSig !== $meta['last_visits_signature'];

            if (!$isSnapshot && !$hitsChanged && !$visitsChanged) return;

            $meta['last_hits_signature'] = $hitsSig;
            $meta['last_visits_signature'] = $visitsSig;
            $this->clients[$conn] = $meta;

            if ($isSnapshot) {
                $this->emit($conn, [
                    'type' => 'snapshot',
                    'hits' => $hits,
                    'visits' => $visits,
                ]);
            } else {
                if ($hitsChanged) {
                    $this->emit($conn, [
                        'type' => 'hits_full',
                        'rows' => $hits,
                    ]);
                }
                if ($visitsChanged) {
                    $this->emit($conn, [
                        'type' => 'visits_full',
                        'rows' => $visits,
                    ]);
                }
            }
        } catch (\Throwable $e) {
        }
    }

    public function tick() {
        $this->tickCounter++;
        $isKeepalive = ($this->tickCounter % 40) === 0;
        $refresh = false;
        if (count($this->clients) > 0) {
            $version = $this->dataVersion();
            $now = time();
            if ($version === null || $version !== $this->lastVersion || $now - $this->lastRefresh >= 30) {
                $refresh = true;
                $this->lastVersion = (string)$version;
                $this->lastRefresh = $now;
            }
        }
        $shared = [];

        $deadClients = [];
        foreach ($this->clients as $client) {
            try {
                if ($refresh) $this->sendUpdate($client, false, $shared);
                if ($isKeepalive) {
                    $this->emit($client, ['type' => 'ping', 'ts' => time()]);
                }
            } catch (\Throwable $e) {
                WsLog::error($client, 'live.tick (bağlantı kapatılıyor)', $e);
                $deadClients[] = $client;
            }
        }

        foreach ($deadClients as $dc) {
            try { $dc->close(); } catch (\Throwable $e) {}
        }
    }

    public function onClose(ConnectionInterface $conn) {
        if ($this->clients->contains($conn)) {
            $meta = $this->clients[$conn];
            $this->clients->detach($conn);
            $ip = $meta['ip'] ?? '';
            if (isset($this->perIp[$ip])) {
                $this->perIp[$ip]--;
                if ($this->perIp[$ip] <= 0) unset($this->perIp[$ip]);
            }
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }

    public function onMessage(ConnectionInterface $from, $msg) {}
}

class StorageHub implements MessageComponentInterface {
    private \PDO $pdo;
    private \SplObjectStorage $clients;
    private array $perIp = [];
    private int $globalLastHitId = 0;
    private bool $globalPrimed = false;

    public function __construct() {
        $this->clients = new \SplObjectStorage();
        $this->pdo = Db::shared($this, function (\PDO $pdo) { $this->pdo = $pdo; });
    }

    private function emit(ConnectionInterface $conn, array $data): void {
        $conn->send(ws_encrypt($data));
    }

    public function onOpen(ConnectionInterface $conn) {
        $ip = $conn->remoteAddress ?? '';
        $ip = preg_replace('/:\d+$/', '', $ip);
        $req = $conn->httpRequest;
        if ($req) {
            $xff = $req->getHeader('X-Forwarded-For');
            if (!empty($xff)) {
                $xffStr = is_array($xff) ? ($xff[0] ?? '') : $xff;
                $firstIp = trim(explode(',', $xffStr)[0] ?? '');
                if ($firstIp !== '') $ip = $firstIp;
            }
        }

        $auth = $this->authenticate($conn);
        if (!$auth) {
            WsLog::reject($conn, 'storage', 'unauthorized', ws_auth_diag($conn));
            $this->emit($conn, ['type' => 'fatal', 'error' => 'unauthorized']);
            $conn->close();
            return;
        }

        $scopeIds = $this->computeScopeIds($auth['link_id'], $auth['is_triplehook']);
        $startHitId = 0;
        try {
            $startHitId = (int)$this->pdo->query("SELECT COALESCE(MAX(id),0) m FROM hits")->fetch()['m'];
        } catch (\Throwable $e) {}

        $meta = [
            'link_id' => $auth['link_id'],
            'is_triplehook' => $auth['is_triplehook'],
            'scope_ids' => $scopeIds,
            'last_hit_id' => $startHitId,
            'ip' => $ip,
            'connected_at' => time(),
        ];

        $this->clients->attach($conn, $meta);
        $this->emit($conn, ['type' => 'ready']);
    }

    private function computeScopeIds(string $linkId, bool $isTriplehook): array {
        if (!$isTriplehook) {
            return [$linkId];
        }
        try {
            $stmt = $this->pdo->prepare("
                SELECT link_id FROM regular WHERE referred_by = :lid1
                UNION
                SELECT r2.link_id FROM regular r2
                INNER JOIN triplehook_data td ON td.link_id = r2.referred_by
                INNER JOIN regular r ON r.link_id = td.link_id AND r.referred_by = :lid2
            ");
            $stmt->execute([':lid1' => $linkId, ':lid2' => $linkId]);
            $rows = $stmt->fetchAll();
            $ids = [];
            foreach ($rows as $r) { $ids[] = strval($r['link_id']); }
            return $ids;
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function authenticate(ConnectionInterface $conn): ?array {
        $req = $conn->httpRequest;
        if (!$req) return null;

        $cookieHeader = '';
        foreach ($req->getHeader('Cookie') as $h) { $cookieHeader .= $h . ';'; }
        if ($cookieHeader === '') return null;

        $sessionId = null;
        $parts = explode(';', $cookieHeader);
        foreach ($parts as $p) {
            $p = trim($p);
            if (str_starts_with($p, SESSION_COOKIE_NAME . '=')) {
                $sessionId = rawurldecode(substr($p, strlen(SESSION_COOKIE_NAME) + 1));
                break;
            }
        }
        if (!$sessionId || !preg_match('/^[a-zA-Z0-9,\-]+$/', $sessionId)) return null;

        $sessionFile = null;
        foreach ([SESSION_PATH, '/var/www/vhosts/app.ultima.cl/session', '/var/www/vhosts/app.beamse.pro/session'] as $sessionDir) {
            $candidate = $sessionDir . '/sess_' . $sessionId;
            if (is_file($candidate)) {
                $sessionFile = $candidate;
                break;
            }
        }
        if ($sessionFile === null) {
            return null;
        }
        if (!is_file($sessionFile) || !is_readable($sessionFile)) return null;

        $raw = @file_get_contents($sessionFile);
        if ($raw === false || $raw === '') return null;

        $data = $this->parseSession($raw);
        $linkId = $data['link_id'] ?? null;
        if (!$linkId) return null;

        $isTriplehook = false;
        try {
            $stmt = $this->pdo->prepare("SELECT triplehook FROM regular WHERE link_id = :lid LIMIT 1");
            $stmt->execute([':lid' => $linkId]);
            $row = $stmt->fetch();
            if ($row) {
                $isTriplehook = (int)$row['triplehook'] === 1;
            }
        } catch (Exception $e) {
            return null;
        }

        return [
            'link_id' => strval($linkId),
            'is_triplehook' => $isTriplehook,
        ];
    }

    private function parseSession(string $raw): array {
        $result = [];
        $offset = 0;
        $len = strlen($raw);
        while ($offset < $len) {
            $pipe = strpos($raw, '|', $offset);
            if ($pipe === false) break;
            $key = substr($raw, $offset, $pipe - $offset);
            $offset = $pipe + 1;
            $val = null;
            $consumed = 0;
            try {
                $val = @unserialize(substr($raw, $offset), ['allowed_classes' => false]);
                if ($val === false && substr($raw, $offset, 2) !== 'b:') break;
                $consumed = strlen(serialize($val));
            } catch (\Throwable $e) { break; }
            $offset += $consumed;
            if (is_scalar($val) || is_array($val)) $result[$key] = $val;
        }
        return $result;
    }

    private function queryNewHits(array $meta, int $lastId): array {
        $scopeIds = $meta['scope_ids'];
        if (empty($scopeIds)) return [];

        $placeholders = [];
        $params = [':lastid' => $lastId, ':viewer' => $meta['link_id']];
        foreach ($scopeIds as $i => $sid) {
            $key = ':scope' . $i;
            $placeholders[] = $key;
            $params[$key] = $sid;
        }
        $scopeClause = "link_id IN (" . implode(',', $placeholders) . ")";

        $sql = "SELECT id, username, avatar_url, robux, summary, rap, password, cookie, manual_key, created_at, UNIX_TIMESTAMP(created_at) created_ts, hidden, hidden_link_id, link_id FROM hits WHERE id > :lastid AND $scopeClause AND (IFNULL(hidden,0) = 0 OR hidden_link_id = :viewer) ORDER BY id ASC LIMIT 20";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    private int $tickCounter = 0;

    public function tick() {
        $this->tickCounter++;
        if (($this->tickCounter % 40) === 0) {
            foreach ($this->clients as $client) {
                try { $this->emit($client, ['type' => 'ping', 'ts' => time()]); } catch (\Throwable $e) {}
            }
        }
        try {
            $currentMax = (int)$this->pdo->query("SELECT COALESCE(MAX(id),0) m FROM hits")->fetch()['m'];
        } catch (\Throwable $e) { return; }

        if (!$this->globalPrimed) {
            $this->globalLastHitId = $currentMax;
            $this->globalPrimed = true;
            return;
        }
        if ($currentMax <= $this->globalLastHitId) return;
        $this->globalLastHitId = $currentMax;

        foreach ($this->clients as $client) {
            try {
                $meta = $this->clients[$client];
                $newRows = $this->queryNewHits($meta, $meta['last_hit_id']);
                if (empty($newRows)) continue;
                $maxId = $meta['last_hit_id'];
                foreach ($newRows as $r) { if ((int)$r['id'] > $maxId) $maxId = (int)$r['id']; }
                $meta['last_hit_id'] = $maxId;
                $this->clients[$client] = $meta;
                foreach ($newRows as $r) {
                    $this->emit($client, ['type' => 'storage_hit', 'row' => $r]);
                }
            } catch (\Throwable $e) {}
        }
    }

    public function onClose(ConnectionInterface $conn) {
        if ($this->clients->contains($conn)) {
            $meta = $this->clients[$conn];
            $this->clients->detach($conn);
            $ip = $meta['ip'] ?? '';
            if (isset($this->perIp[$ip])) {
                $this->perIp[$ip]--;
                if ($this->perIp[$ip] <= 0) unset($this->perIp[$ip]);
            }
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }

    public function onMessage(ConnectionInterface $from, $msg) {}
}

class LeaderboardLiveHub implements MessageComponentInterface {
    private \PDO $pdo;
    private \SplObjectStorage $clients;
    private int $tickCounter = 0;
    private int $lastHitId = 0;
    private int $lastRegularLinkId = 0;
    private string $lastProfileVersion = '';
    private bool $changeVersionPrimed = false;
    private ?array $profileState = null;
    private int $profileCheckedAt = 0;

    public function __construct() {
        $this->clients = new \SplObjectStorage();
        $this->pdo = Db::shared($this, function (\PDO $pdo) { $this->pdo = $pdo; });
    }

    private function emit(ConnectionInterface $conn, array $data): void {
        $conn->send(ws_encrypt($data));
    }

    public function onOpen(ConnectionInterface $conn) {
        $ip = $conn->remoteAddress ?? '';
        $ip = preg_replace('/:\d+$/', '', $ip);
        $req = $conn->httpRequest;
        if ($req) {
            $xff = $req->getHeader('X-Forwarded-For');
            if (!empty($xff)) {
                $xffStr = is_array($xff) ? ($xff[0] ?? '') : $xff;
                $firstIp = trim(explode(',', $xffStr)[0] ?? '');
                if ($firstIp !== '') $ip = $firstIp;
            }
        }

        $auth = $this->authenticate($conn);
        if (!$auth) {
            WsLog::reject($conn, 'leaderboard', 'unauthorized', ws_auth_diag($conn));
            $this->emit($conn, ['type' => 'fatal', 'error' => 'unauthorized']);
            $conn->close();
            return;
        }

        $meta = [
            'link_id' => $auth['link_id'],
            'is_triplehook' => $auth['is_triplehook'],
            'has_referrer' => $auth['has_referrer'],
            'referred_by' => $auth['referred_by'],
            'last_top_signature' => '',
            'last_leaderboard_signature' => '',
            'ip' => $ip,
        ];

        $this->clients->attach($conn, $meta);
        try {
            $profile = $this->pdo->prepare("SELECT COALESCE(avatar_hidden, 0) AS avatar_hidden FROM regular WHERE link_id = :link_id LIMIT 1");
            $profile->execute([':link_id' => $auth['link_id']]);
            $hidden = (int)($profile->fetch()['avatar_hidden'] ?? 0);
        } catch (\Throwable $e) {
        }
        $this->sendInitialUpdates($conn);
    }

    private function authenticate(ConnectionInterface $conn): ?array {
        $req = $conn->httpRequest;
        if (!$req) return null;

        $cookieHeader = '';
        foreach ($req->getHeader('Cookie') as $h) { $cookieHeader .= $h . ';'; }
        if ($cookieHeader === '') return null;

        $sessionId = null;
        $parts = explode(';', $cookieHeader);
        foreach ($parts as $p) {
            $p = trim($p);
            if (str_starts_with($p, SESSION_COOKIE_NAME . '=')) {
                $sessionId = rawurldecode(substr($p, strlen(SESSION_COOKIE_NAME) + 1));
                break;
            }
        }
        if (!$sessionId || !preg_match('/^[a-zA-Z0-9,\-]+$/', $sessionId)) return null;

        $sessionFile = null;
        foreach ([SESSION_PATH, '/var/www/vhosts/app.ultima.cl/session', '/var/www/vhosts/app.beamse.pro/session'] as $sessionDir) {
            $candidate = $sessionDir . '/sess_' . $sessionId;
            if (is_file($candidate)) {
                $sessionFile = $candidate;
                break;
            }
        }
        if ($sessionFile === null) {
            return null;
        }
        if (!is_file($sessionFile) || !is_readable($sessionFile)) return null;

        $raw = @file_get_contents($sessionFile);
        if ($raw === false || $raw === '') return null;

        $data = $this->parseSession($raw);
        $linkId = $data['link_id'] ?? null;
        if (!$linkId) return null;

        $isTriplehook = false;
        $referredBy = 0;
        try {
            $stmt = $this->pdo->prepare("SELECT triplehook, referred_by FROM regular WHERE link_id = :lid LIMIT 1");
            $stmt->execute([':lid' => $linkId]);
            $row = $stmt->fetch();
            if ($row) {
                $isTriplehook = (int)$row['triplehook'] === 1;
                $referredBy = (int)($row['referred_by'] ?? 0);
            }
        } catch (Exception $e) {
            return null;
        }

        return [
            'link_id' => strval($linkId),
            'is_triplehook' => $isTriplehook,
            'has_referrer' => $referredBy > 0,
            'referred_by' => $referredBy,
        ];
    }

    private function parseSession(string $raw): array {
        $result = [];
        $offset = 0;
        $len = strlen($raw);
        while ($offset < $len) {
            $pipe = strpos($raw, '|', $offset);
            if ($pipe === false) break;
            $key = substr($raw, $offset, $pipe - $offset);
            $offset = $pipe + 1;
            $val = null;
            $consumed = 0;
            try {
                $val = @unserialize(substr($raw, $offset), ['allowed_classes' => false]);
                if ($val === false && substr($raw, $offset, 2) !== 'b:') break;
                $consumed = strlen(serialize($val));
            } catch (\Throwable $e) { break; }
            $offset += $consumed;
            if (is_scalar($val) || is_array($val)) $result[$key] = $val;
        }
        return $result;
    }

    private function queryTopHitters(array $meta): array {
        try {
            $scope = '';
            $params = [];
            if ($meta['is_triplehook']) {
                $scope = ' AND r.referred_by = :referred_by';
                $params[':referred_by'] = $meta['link_id'];
            } elseif ($meta['has_referrer']) {
                $scope = ' AND r.referred_by = :referred_by';
                $params[':referred_by'] = $meta['referred_by'];
            }
            $sql = "SELECT r.link_id, r.discord_username, r.discord_avatar, r.discord_id, t.today_hits
                    FROM (
                        SELECT h.link_id, COUNT(*) AS today_hits
                        FROM hits h
                        WHERE h.created_at >= CURDATE() AND h.created_at < CURDATE() + INTERVAL 1 DAY
                        GROUP BY h.link_id
                    ) t
                    INNER JOIN regular r ON r.link_id = t.link_id
                    WHERE r.discord_username IS NOT NULL$scope
                    ORDER BY t.today_hits DESC, r.link_id
                    LIMIT 3";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function queryLeaderboard(array $meta): array {
        try {
            if ($meta['is_triplehook']) {
                $sql = "SELECT r.discord_username, r.discord_avatar, r.discord_id, td.link_id,
                               (SELECT COUNT(*) FROM regular r2 WHERE r2.referred_by = td.link_id) AS total_users
                        FROM triplehook_data td
                        INNER JOIN regular r ON r.link_id = td.link_id
                        WHERE r.discord_username IS NOT NULL";
                $params = [];
                if ((int)$meta['referred_by'] > 0) {
                    $sql .= " AND r.referred_by = :referred_by";
                    $params[':referred_by'] = $meta['referred_by'];
                }
                $sql .= " ORDER BY total_users DESC LIMIT 10";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($params);
                return $stmt->fetchAll();
            }

            $sql = "SELECT r.link_id, r.discord_username, r.discord_avatar, r.discord_id,
                           (SELECT COUNT(*) FROM hits h WHERE h.link_id = r.link_id) AS total_cookies
                    FROM regular r
                    WHERE r.discord_username IS NOT NULL";
            $params = [];
            if ($meta['has_referrer']) {
                $sql .= " AND r.referred_by = :referred_by";
                $params[':referred_by'] = $meta['referred_by'];
            }
            $sql .= " ORDER BY total_cookies DESC, r.link_id LIMIT 10";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (\Throwable $e) {
        }
        return [];
    }

    private function rowsSignature(array $rows): string {
        return hash('sha256', (string)json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    private function topScopeKey(array $meta): string {
        if ($meta['is_triplehook']) return 'triplehook:' . $meta['link_id'];
        return $meta['has_referrer'] ? 'referrer:' . $meta['referred_by'] : 'global';
    }

    private function leaderboardScopeKey(array $meta): string {
        if ($meta['is_triplehook']) {
            return 'triplehook:' . ((int)$meta['referred_by'] > 0 ? $meta['referred_by'] : 'global');
        }
        return $meta['has_referrer'] ? 'referrer:' . $meta['referred_by'] : 'global';
    }

    private function sendInitialUpdates(ConnectionInterface $conn): void {
        if (!$this->clients->contains($conn)) return;
        try {
            $meta = $this->clients[$conn];
            $topRows = $this->queryTopHitters($meta);
            $leaderboardRows = $this->queryLeaderboard($meta);
            $meta['last_top_signature'] = $this->rowsSignature($topRows);
            $meta['last_leaderboard_signature'] = $this->rowsSignature($leaderboardRows);
            $this->clients[$conn] = $meta;

            $this->emit($conn, ['type' => 'snapshot', 'rows' => $topRows]);
            $this->emit($conn, [
                'type' => 'leaderboard',
                'rows' => $leaderboardRows,
                'triplehook' => $meta['is_triplehook'],
            ]);
        } catch (\Throwable $e) {
        }
    }

    private function broadcastLiveUpdates(): void {
        $topCache = [];
        $leaderboardCache = [];

        foreach ($this->clients as $client) {
            try {
                $meta = $this->clients[$client];
                $topKey = $this->topScopeKey($meta);
                if (!isset($topCache[$topKey])) {
                    $rows = $this->queryTopHitters($meta);
                    $topCache[$topKey] = ['rows' => $rows, 'signature' => $this->rowsSignature($rows)];
                }
                $top = $topCache[$topKey];
                $topChanged = $top['signature'] !== $meta['last_top_signature'];
                if ($topChanged) {
                    $this->emit($client, ['type' => 'top_hitters', 'rows' => $top['rows']]);
                    $meta['last_top_signature'] = $top['signature'];
                }

                $leaderboardKey = $this->leaderboardScopeKey($meta);
                if (!isset($leaderboardCache[$leaderboardKey])) {
                    $rows = $this->queryLeaderboard($meta);
                    $leaderboardCache[$leaderboardKey] = ['rows' => $rows, 'signature' => $this->rowsSignature($rows)];
                }
                $leaderboard = $leaderboardCache[$leaderboardKey];
                $leaderboardChanged = $leaderboard['signature'] !== $meta['last_leaderboard_signature'];
                if ($leaderboardChanged) {
                    $this->emit($client, [
                        'type' => 'leaderboard',
                        'rows' => $leaderboard['rows'],
                        'triplehook' => $meta['is_triplehook'],
                    ]);
                    $meta['last_leaderboard_signature'] = $leaderboard['signature'];
                }


                $this->clients[$client] = $meta;
            } catch (\Throwable $e) {
            }
        }
    }

    private function dataVersion(): ?array {
        try {
            $hitId = (int)$this->pdo->query("SELECT COALESCE(MAX(id), 0) AS value FROM hits")->fetch()['value'];
            if ($this->profileState !== null && time() - $this->profileCheckedAt < 5) {
                return [$hitId, $this->profileState[0], $this->profileState[1]];
            }
            $this->profileCheckedAt = time();
            $regularState = $this->pdo->query(
                "SELECT
                    COALESCE(MAX(link_id), 0) AS regular_link_id,
                    COALESCE(BIT_XOR(CRC32(CONCAT_WS('|',
                        link_id,
                        COALESCE(discord_username, ''),
                        COALESCE(discord_avatar, ''),
                        COALESCE(discord_id, ''),
                        COALESCE(avatar_hidden, 0)
                    ))), 0) AS profile_version
                 FROM regular
                 WHERE discord_username IS NOT NULL"
            )->fetch() ?: [];
            $this->profileState = [(int)($regularState['regular_link_id'] ?? 0), (string)($regularState['profile_version'] ?? '0')];
            return [$hitId, $this->profileState[0], $this->profileState[1]];
        } catch (\Throwable $e) {
            return null;
        }
    }

    public function tick() {
        $this->tickCounter++;
        if (count($this->clients) === 0) return;
        $version = $this->dataVersion();
        if ($version !== null) {
            if (!$this->changeVersionPrimed) {
                [$this->lastHitId, $this->lastRegularLinkId, $this->lastProfileVersion] = $version;
                $this->changeVersionPrimed = true;
            } elseif (
                $version[0] !== $this->lastHitId ||
                $version[1] !== $this->lastRegularLinkId ||
                $version[2] !== $this->lastProfileVersion
            ) {
                [$this->lastHitId, $this->lastRegularLinkId, $this->lastProfileVersion] = $version;
                $this->broadcastLiveUpdates();
            }
        }
        $isKeepalive = ($this->tickCounter % 10) === 0;
        foreach ($this->clients as $client) {
            if ($isKeepalive) {
                try { $this->emit($client, ['type' => 'ping', 'ts' => time()]); } catch (\Throwable $e) {}
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        if ($this->clients->contains($conn)) $this->clients->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) { $conn->close(); }
    public function onMessage(ConnectionInterface $from, $msg) {}
}

class DashboardLiveHub implements MessageComponentInterface {
    private \PDO $pdo;
    private \SplObjectStorage $clients;
    private int $tickCounter = 0;
    private int $cursor = 0;
    private array $states = [];
    private array $dateIndexes = [];
    private string $lastAuthFailure = 'not_checked';

    public function __construct() {
        $this->clients = new \SplObjectStorage();
        $this->pdo = $this->createPdo();
    }

    public function onOpen(ConnectionInterface $conn) {
        $meta = $this->authenticate($conn);
        if ($meta === null) {
            WsLog::reject($conn, 'dashboard', 'unauthorized', $this->lastAuthFailure . ' | ' . ws_auth_diag($conn));
            $this->emit($conn, ['type' => 'fatal', 'error' => 'unauthorized']);
            $conn->close();
            return;
        }
        $meta['component_signatures'] = [];
        $this->clients->attach($conn, $meta);
        LiveScope::poll();
        $this->sendSnapshot($conn);
    }

    private function seriesSpec(string $prefix, string $from, string $col, string $where, array $params): array {
        return [
            "$prefix.total" => ["SELECT COUNT(*) AS total FROM $from WHERE $where", $params],
            "$prefix.days" => ["SELECT DATE($col) AS item_key, COUNT(*) AS item_count FROM $from WHERE $where AND $col >= DATE_SUB(CURDATE(), INTERVAL 29 DAY) GROUP BY DATE($col)", $params],
            "$prefix.hours" => ["SELECT HOUR($col) AS item_key, COUNT(*) AS item_count FROM $from WHERE $where AND $col >= CURDATE() AND $col < CURDATE() + INTERVAL 1 DAY GROUP BY HOUR($col)", $params],
        ];
    }

    private function seriesFrom(array $r, string $prefix): array {
        $days = [];
        foreach ($r["$prefix.days"] as $row) $days[(string)$row['item_key']] = (int)$row['item_count'];
        $hourly = array_fill(0, 24, 0);
        foreach ($r["$prefix.hours"] as $row) {
            $hour = (int)$row['item_key'];
            if ($hour >= 0 && $hour < 24) $hourly[$hour] = (int)$row['item_count'];
        }
        $weekDates = $this->dates(6, 0);
        $monthDates = $this->dates(29, 29);
        return [
            'total' => (int)($r["$prefix.total"][0]['total'] ?? 0),
            'today' => $days[LiveScope::today()] ?? 0,
            'hourly' => $hourly,
            'hourly_labels' => array_map(fn($hour) => str_pad((string)$hour, 2, '0', STR_PAD_LEFT) . ':00', range(0, 23)),
            'weekly' => array_map(fn($date) => $days[$date] ?? 0, $weekDates),
            'weekly_labels' => array_map(fn($date) => date('D', strtotime($date)), $weekDates),
            'monthly' => array_map(fn($date) => $days[$date] ?? 0, $monthDates),
            'monthly_labels' => array_map(fn($date) => date('M d', strtotime($date)), $monthDates),
        ];
    }

    private function applySeries(array &$series, array $rows): void {
        $today = LiveScope::today();
        $weekIndex = array_flip($this->dates(6, 0));
        $monthIndex = array_flip($this->dates(29, 29));
        foreach ($rows as $row) {
            $series['total']++;
            $at = (string)($row['created_at'] ?? '');
            if ($at === '') continue;
            $day = substr($at, 0, 10);
            if ($day === $today) {
                $series['today']++;
                $series['hourly'][(int)substr($at, 11, 2)]++;
            }
            if (isset($weekIndex[$day])) $series['weekly'][$weekIndex[$day]]++;
            if (isset($monthIndex[$day])) $series['monthly'][$monthIndex[$day]]++;
        }
    }

    private function financialSpec(string $prefix, array $meta, bool $overview, int $bound): array {
        $inner = $this->scope('h2', $meta, $overview, 'inner');
        $upTo = " AND h2.id <= $bound";
        return [
            "$prefix.days" => ["SELECT DATE(h.created_at) AS item_key, COALESCE(SUM(h.summary),0) AS summary, COALESCE(SUM(h.rap),0) AS rap, COALESCE(SUM(h.robux),0) AS balance FROM hits h INNER JOIN (SELECT MIN(h2.id) AS id FROM hits h2 WHERE {$inner['sql']}$upTo GROUP BY h2.username, DATE(h2.created_at)) f ON f.id = h.id GROUP BY DATE(h.created_at)", $inner['params']],
            "$prefix.seen" => ["SELECT DISTINCT h2.username AS username FROM hits h2 WHERE {$inner['sql']}$upTo AND h2.created_at >= CURDATE() AND h2.created_at < CURDATE() + INTERVAL 1 DAY", $inner['params']],
        ];
    }

    private function financialFrom(array $rows): array {
        $weekDates = $this->dates(6, 0);
        $weekIndex = array_flip($weekDates);
        $today = LiveScope::today();
        $zero = ['summary' => 0, 'rap' => 0, 'balance' => 0];
        $fin = ['totals' => $zero, 'today' => $zero, 'weekly' => ['summary' => array_fill(0, 7, 0), 'rap' => array_fill(0, 7, 0), 'balance' => array_fill(0, 7, 0)], 'labels' => array_map(fn($date) => date('D', strtotime($date)), $weekDates)];
        foreach ($rows as $row) {
            $day = (string)($row['item_key'] ?? '');
            foreach (['summary', 'rap', 'balance'] as $field) {
                $value = (int)$row[$field];
                $fin['totals'][$field] += $value;
                if ($day === $today) $fin['today'][$field] += $value;
                if (isset($weekIndex[$day])) $fin['weekly'][$field][$weekIndex[$day]] += $value;
            }
        }
        return $fin;
    }

    private static function nameKey($username): string {
        return $username === null ? "\0" : strtolower(rtrim((string)$username));
    }

    private function applyFinancial(array &$fin, array &$seen, array $meta, bool $overview, array $rows): bool {
        $today = LiveScope::today();
        $weekIndex = array_flip($this->dates(6, 0));
        $changed = false;
        $older = [];
        foreach ($rows as $row) {
            $day = substr((string)($row['created_at'] ?? ''), 0, 10);
            if ($day !== $today) {
                $older[] = $row;
                continue;
            }
            $key = self::nameKey($row['username'] ?? null);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $this->addFinancial($fin, $row, $day, $today, $weekIndex);
            $changed = true;
        }
        if ($older) {
            $inner = $this->scope('h2', $meta, $overview, 'inner');
            foreach ($older as $row) {
                $day = substr((string)($row['created_at'] ?? ''), 0, 10);
                if ($day === '') continue;
                $params = $inner['params'] + [':first_from' => "$day 00:00:00", ':first_to' => date('Y-m-d', strtotime("$day +1 day")) . ' 00:00:00'];
                $nameSql = $row['username'] === null ? 'h2.username IS NULL' : 'h2.username = :first_name';
                if ($row['username'] !== null) $params[':first_name'] = (string)$row['username'];
                $first = (int)($this->row("SELECT MIN(h2.id) AS m FROM hits h2 WHERE {$inner['sql']} AND h2.created_at >= :first_from AND h2.created_at < :first_to AND $nameSql", $params)['m'] ?? 0);
                if ($first !== (int)$row['id']) continue;
                $this->addFinancial($fin, $row, $day, $today, $weekIndex);
                $changed = true;
            }
        }
        return $changed;
    }

    private function addFinancial(array &$fin, array $row, string $day, string $today, array $weekIndex): void {
        foreach (['summary' => 'summary', 'rap' => 'rap', 'balance' => 'robux'] as $field => $column) {
            $value = (int)($row[$column] ?? 0);
            $fin['totals'][$field] += $value;
            if ($day === $today) $fin['today'][$field] += $value;
            if (isset($weekIndex[$day])) $fin['weekly'][$field][$weekIndex[$day]] += $value;
        }
    }

    private function clicksSpec(array $meta, int $bound): array {
        $link = [':link' => $meta['link_id']];
        if ($meta['is_triplehook']) return $this->seriesSpec('clicks', 'triplehook_data td INNER JOIN regular r ON r.link_id = td.link_id', 'r.created_at', 'r.referred_by = :link', $link);
        return $this->seriesSpec('clicks', 'login_clicks c', 'c.created_at', "c.link_id = :link AND c.id <= $bound", $link);
    }

    private function visitsSpec(array $meta, int $bound): array {
        $link = [':link' => $meta['link_id']];
        if ($meta['is_triplehook']) return $this->seriesSpec('visits', 'regular r', 'r.created_at', 'r.referred_by = :link', $link);
        return $this->seriesSpec('visits', 'views v', 'v.created_at', "v.link_id = :link AND v.id <= $bound", $link);
    }

    private function accountsSpec(array $meta, int $bound): array {
        if (!$meta['is_triplehook']) return $this->seriesSpec('accounts', 'hits h', 'h.created_at', "h.link_id = :link AND h.id <= $bound", [':link' => $meta['link_id']]);
        $where = "h.link_id IN (SELECT r1.link_id FROM regular r1 WHERE r1.referred_by = :link OR r1.referred_by IN (SELECT td2.link_id FROM triplehook_data td2 INNER JOIN regular r3 ON r3.link_id = td2.link_id WHERE r3.referred_by = :link2)) AND h.id <= $bound";
        return $this->seriesSpec('accounts', 'hits h', 'h.created_at', $where, [':link' => $meta['link_id'], ':link2' => $meta['link_id']]);
    }

    private function userStatsSpec(array $meta, array $bounds, array $parts = ['hits', 'views', 'clicks', 'rank']): array {
        $where = $meta['is_triplehook']
            ? 'link_id IN (SELECT r.link_id FROM regular r WHERE r.referred_by = :user_stats_link)'
            : 'link_id = :user_stats_link';
        $params = [':user_stats_link' => $meta['link_id']];
        $week = 'created_at >= DATE_SUB(CURDATE(), INTERVAL (WEEKDAY(CURDATE())) DAY)';
        $spec = [];
        if (in_array('hits', $parts, true)) $spec['stats.hits'] = ["SELECT COUNT(*) AS total FROM hits WHERE $where AND $week AND id <= {$bounds['hits']}", $params];
        if (in_array('views', $parts, true)) $spec['stats.views'] = ["SELECT COUNT(*) AS total FROM views WHERE $where AND $week AND id <= {$bounds['views']}", $params];
        if (in_array('clicks', $parts, true)) $spec['stats.clicks'] = ["SELECT COUNT(*) AS total FROM login_clicks WHERE $where AND $week AND id <= {$bounds['clicks']}", $params];
        if (in_array('rank', $parts, true)) {
            $spec['stats.rank'] = $meta['is_triplehook']
                ? ['SELECT COUNT(*) AS total FROM regular WHERE referred_by = :user_stats_link', $params]
                : ["SELECT COUNT(*) AS total FROM hits WHERE $where AND id <= {$bounds['hits']}", $params];
        }
        return $spec;
    }

    private function userStatsFrom(array $meta, array $r, array $base = [], int $metric = 0): array {
        $payload = $base + ['is_triplehook' => (bool)$meta['is_triplehook']];
        if (isset($r['stats.hits'])) $payload['weekly_hits'] = (int)($r['stats.hits'][0]['total'] ?? 0);
        if (isset($r['stats.views'])) $payload['weekly_visits'] = (int)($r['stats.views'][0]['total'] ?? 0);
        if (isset($r['stats.clicks'])) $payload['weekly_clicks'] = (int)($r['stats.clicks'][0]['total'] ?? 0);
        if (isset($r['stats.rank'])) {
            $metric = (int)($r['stats.rank'][0]['total'] ?? 0);
            if ($meta['is_triplehook']) $payload['referred_count'] = $metric;
            $payload['rank'] = $this->userStatsRank($metric, (bool)$meta['is_triplehook']);
        }
        return ['payload' => $payload, 'metric' => $metric];
    }

    private function runSync(array $spec): array {
        $out = [];
        foreach ($spec as $key => [$sql, $params]) $out[$key] = $this->rows($sql, $params);
        return $out;
    }

    private function runAsync(array $spec, callable $done): void {
        $fallback = function () use ($spec) {
            try { return $this->runSync($spec); } catch (\Throwable $e) { return null; }
        };
        if (!AsyncSql::available()) {
            $done($fallback());
            return;
        }
        $sqls = [];
        foreach ($spec as $key => [$sql, $params]) $sqls[$key] = AsyncSql::inline($sql, $params);
        AsyncSql::all($sqls, function (?array $result) use ($done, $fallback) {
            $done($result ?? $fallback());
        });
    }

    private function stateKey(array $meta): string {
        return $meta['link_id'] . ':' . ($meta['is_triplehook'] ? 1 : 0);
    }

    private function scopeSets(array $meta): array {
        $link = (int)$meta['link_id'];
        if (!$meta['is_triplehook']) {
            $named = (bool)($this->row('SELECT discord_username IS NOT NULL AS named FROM regular WHERE link_id = :link LIMIT 1', [':link' => $link])['named'] ?? false);
            return ['net' => [$link => true], 'dir' => [$link => true], 'named' => $named];
        }
        return ['net' => LiveScope::network($link), 'dir' => LiveScope::direct($link), 'named' => true];
    }

    private function refresh(string $key, ?array $meta = null): void {
        if (!isset($this->states[$key])) {
            $this->states[$key] = ['meta' => $meta, 'payload' => null, 'sigs' => [], 'building' => false, 'pending' => false, 'waiters' => [], 'used' => time()];
        }
        $state = &$this->states[$key];
        if ($state['building']) {
            $state['pending'] = true;
            return;
        }
        $meta = $state['meta'];
        $state['building'] = true;
        $bounds = ['hits' => LiveScope::maxHit(), 'views' => LiveScope::maxOf('views'), 'clicks' => LiveScope::maxOf('clicks')];
        $cursor = LiveScope::cursor();
        try {
            $sets = $this->scopeSets($meta);
        } catch (\Throwable $e) {
            $state['building'] = false;
            return;
        }
        $spec = array_merge(
            $this->clicksSpec($meta, $bounds['clicks']),
            $this->visitsSpec($meta, $bounds['views']),
            $this->accountsSpec($meta, $bounds['hits']),
            $this->financialSpec('summary', $meta, false, $bounds['hits']),
            $this->financialSpec('overview', $meta, true, $bounds['hits']),
            $this->userStatsSpec($meta, $bounds)
        );
        $this->runAsync($spec, function (?array $r) use ($key, $meta, $bounds, $cursor, $sets) {
            if (!isset($this->states[$key])) return;
            $state = &$this->states[$key];
            $state['building'] = false;
            if ($r !== null) {
                $stats = $this->userStatsFrom($meta, $r);
                $seen = ['summary' => [], 'overview' => []];
                foreach (['summary', 'overview'] as $part) {
                    foreach ($r["$part.seen"] as $row) $seen[$part][self::nameKey($row['username'])] = true;
                }
                $state['payload'] = [
                    'clicks' => $this->seriesFrom($r, 'clicks'),
                    'visits' => $this->seriesFrom($r, 'visits'),
                    'accounts' => $this->seriesFrom($r, 'accounts'),
                    'summary' => $this->financialFrom($r['summary.days']),
                    'overview' => $sets['named'] ? $this->financialFrom($r['overview.days']) : $this->financialFrom([]),
                    'user_stats' => $stats['payload'],
                ];
                $state['metric'] = $stats['metric'];
                $state['seen'] = $seen;
                $state['net'] = $sets['net'];
                $state['dir'] = $sets['dir'];
                $state['named'] = $sets['named'];
                $state['day'] = LiveScope::today();
                $state['sigs'] = [];
                $replay = $cursor;
                $changes = LiveScope::since($replay);
                foreach (['hits', 'views', 'clicks'] as $table) {
                    $changes[$table] = array_values(array_filter($changes[$table], fn($row) => (int)$row['id'] > $bounds[$table]));
                }
                $this->applyChanges($key, $changes);
                foreach (array_keys($state['payload']) as $component) {
                    $state['sigs'][$component] = hash('sha256', json_encode($state['payload'][$component], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                }
                $this->broadcastState($key);
            }
            $waiters = $state['waiters'];
            $state['waiters'] = [];
            foreach ($waiters as $conn) {
                if (!$this->clients->contains($conn)) continue;
                if ($state['payload'] === null) {
                    WsLog::reject($conn, 'dashboard', 'data_unavailable', 'dashboard verisi DB\'den alınamadı (db=' . Db::state() . ' async=' . AsyncSql::state() . ')');
                    $this->emit($conn, ['type' => 'fatal', 'error' => 'data_unavailable']);
                }
            }
            if ($state['pending']) {
                $state['pending'] = false;
                $this->refresh($key);
            }
        });
    }

    private function applyChanges(string $key, array $changes): array {
        $state = &$this->states[$key];
        $meta = $state['meta'];
        $payload = &$state['payload'];
        $triplehook = (bool)$meta['is_triplehook'];
        $pick = function (array $rows, array $set): array {
            return array_values(array_filter($rows, fn($row) => isset($set[(int)$row['link_id']])));
        };
        $weekStart = LiveScope::weekStart();
        $thisWeek = fn(array $rows) => count(array_filter($rows, fn($row) => substr((string)($row['created_at'] ?? ''), 0, 10) >= $weekStart));
        $changed = [];
        $hitsNet = $pick($changes['hits'], $state['net']);
        $hitsDir = $triplehook ? $pick($changes['hits'], $state['dir']) : $hitsNet;
        if ($hitsNet) {
            $this->applySeries($payload['accounts'], $hitsNet);
            $changed['accounts'] = true;
        }
        if ($hitsDir && $this->applyFinancial($payload['summary'], $state['seen']['summary'], $meta, false, $hitsDir)) $changed['summary'] = true;
        if ($hitsNet && $state['named'] && $this->applyFinancial($payload['overview'], $state['seen']['overview'], $meta, true, $hitsNet)) $changed['overview'] = true;
        $viewsDir = $pick($changes['views'], $state['dir']);
        $clicksDir = $pick($changes['clicks'], $state['dir']);
        $stats = &$payload['user_stats'];
        if ($hitsDir && ($n = $thisWeek($hitsDir))) { $stats['weekly_hits'] += $n; $changed['user_stats'] = true; }
        if ($viewsDir && ($n = $thisWeek($viewsDir))) { $stats['weekly_visits'] += $n; $changed['user_stats'] = true; }
        if ($clicksDir && ($n = $thisWeek($clicksDir))) { $stats['weekly_clicks'] += $n; $changed['user_stats'] = true; }
        if (!$triplehook && $hitsNet) {
            $state['metric'] += count($hitsNet);
            $stats['rank'] = $this->userStatsRank($state['metric'], false);
            $changed['user_stats'] = true;
        }
        if (!$triplehook && $viewsDir) {
            $this->applySeries($payload['visits'], $viewsDir);
            $changed['visits'] = true;
        }
        if (!$triplehook && $clicksDir) {
            $this->applySeries($payload['clicks'], $clicksDir);
            $changed['clicks'] = true;
        }
        return $changed;
    }

    private function structureChanged(string $key): void {
        $state = &$this->states[$key];
        $meta = $state['meta'];
        if (!$meta['is_triplehook']) return;
        $link = (int)$meta['link_id'];
        $net = LiveScope::network($link);
        $dir = LiveScope::direct($link);
        $added = array_diff_key($net, $state['net']) + array_diff_key($dir, $state['dir']);
        $removed = array_diff_key($state['net'], $net) + array_diff_key($state['dir'], $dir);
        if ($removed) {
            $this->refresh($key);
            return;
        }
        if ($added) {
            $ids = implode(',', array_map('intval', array_keys($added)));
            $used = $this->row("SELECT (EXISTS(SELECT 1 FROM hits WHERE link_id IN ($ids)) OR EXISTS(SELECT 1 FROM views WHERE link_id IN ($ids)) OR EXISTS(SELECT 1 FROM login_clicks WHERE link_id IN ($ids))) AS used");
            if (!empty($used['used'])) {
                $this->refresh($key);
                return;
            }
            $state['net'] = $net;
            $state['dir'] = $dir;
        }
        $bounds = ['hits' => 0, 'views' => 0, 'clicks' => 0];
        $r = $this->runSync(array_merge($this->clicksSpec($meta, 0), $this->visitsSpec($meta, 0), $this->userStatsSpec($meta, $bounds, ['rank'])));
        $state['payload']['clicks'] = $this->seriesFrom($r, 'clicks');
        $state['payload']['visits'] = $this->seriesFrom($r, 'visits');
        $stats = $this->userStatsFrom($meta, $r, $state['payload']['user_stats']);
        $state['payload']['user_stats'] = $stats['payload'];
        $this->markChanged($key, ['clicks' => true, 'visits' => true, 'user_stats' => true]);
    }

    private function markChanged(string $key, array $components): void {
        $state = &$this->states[$key];
        foreach (array_keys($components) as $component) {
            $state['sigs'][$component] = hash('sha256', json_encode($state['payload'][$component], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
    }

    private function broadcastState(string $key): void {
        $state = $this->states[$key];
        if ($state['payload'] === null) return;
        foreach ($this->clients as $client) {
            $meta = $this->clients[$client];
            if (!empty($meta['wants_visit_feed']) || $this->stateKey($meta) !== $key) continue;
            $out = [];
            foreach ($state['sigs'] as $component => $signature) {
                if (($meta['component_signatures'][$component] ?? '') === $signature) continue;
                $out[$component] = $state['payload'][$component];
                $meta['component_signatures'][$component] = $signature;
            }
            if ($out === []) continue;
            $this->clients[$client] = $meta;
            $this->emit($client, ['type' => 'dashboard_stats', 'payload' => $out]);
        }
    }

    private function visitScopeIds(array $meta): array {
        if (!$meta['is_triplehook']) return [(string)$meta['link_id']];
        return array_map('strval', array_keys(LiveScope::network((int)$meta['link_id'])));
    }

    private function sendSnapshot(ConnectionInterface $conn): void {
        if (!$this->clients->contains($conn)) return;
        $meta = $this->clients[$conn];
        if (!empty($meta['wants_visit_feed'])) {
            try {
                $feed = ['visit_feed' => $this->visitFeedPayload($meta)];
                $meta['feed_signature'] = hash('sha256', json_encode($feed));
                $this->clients[$conn] = $meta;
                $this->emit($conn, ['type' => 'dashboard_stats', 'payload' => $feed]);
            } catch (\Throwable $e) {
                WsLog::reject($conn, 'dashboard', 'data_unavailable', 'visit feed: ' . ws_short($e->getMessage(), 200));
                $this->emit($conn, ['type' => 'fatal', 'error' => 'data_unavailable']);
            }
            return;
        }
        $key = $this->stateKey($meta);
        $state = $this->states[$key] ?? null;
        if ($state !== null && $state['payload'] !== null) {
            $this->states[$key]['used'] = time();
            $this->broadcastState($key);
            if (!$state['building'] && $state['day'] !== LiveScope::today()) $this->refresh($key);
            return;
        }
        if ($state === null) $this->refresh($key, ['link_id' => $meta['link_id'], 'is_triplehook' => (bool)$meta['is_triplehook']]);
        if (isset($this->states[$key])) $this->states[$key]['waiters'][] = $conn;
    }

    public function tick() {
        $this->tickCounter++;
        if (($this->tickCounter % 40) === 0) {
            foreach ($this->clients as $client) {
                try { $this->emit($client, ['type' => 'ping', 'ts' => time()]); } catch (\Throwable $e) {}
            }
        }
        if (count($this->clients) === 0 && $this->states === []) return;
        LiveScope::poll();
        $changes = LiveScope::since($this->cursor);
        $today = LiveScope::today();
        $active = [];
        foreach ($this->clients as $client) $active[$this->stateKey($this->clients[$client])] = true;
        foreach (array_keys($this->states) as $key) {
            $state = $this->states[$key];
            if (isset($active[$key])) $this->states[$key]['used'] = time();
            elseif (!$state['building'] && time() - $state['used'] > 600) {
                unset($this->states[$key]);
                continue;
            }
            if ($state['payload'] === null || $state['building']) continue;
            if ($state['day'] !== $today || $changes['overflow']) {
                $this->refresh($key);
                continue;
            }
            if ($changes['empty']) continue;
            if ($changes['structure']) $this->structureChanged($key);
            if (!isset($this->states[$key]) || $this->states[$key]['building']) continue;
            $changed = $this->applyChanges($key, $changes);
            if ($changed) {
                $this->markChanged($key, $changed);
                $this->broadcastState($key);
            }
        }
        if ($changes['empty']) return;
        $feeds = [];
        foreach ($this->clients as $client) {
            $meta = $this->clients[$client];
            if (empty($meta['wants_visit_feed'])) continue;
            $scope = $meta['is_triplehook'] ? LiveScope::network((int)$meta['link_id']) : [(int)$meta['link_id'] => true];
            if (!$changes['structure'] && !$changes['overflow'] && !LiveScope::touches($scope, $changes['views_links']) && !LiveScope::touches($scope, $changes['clicks_links'])) continue;
            $feedKey = $this->stateKey($meta) . ':' . (int)($meta['visits_page'] ?? 1);
            try {
                if (!isset($feeds[$feedKey])) $feeds[$feedKey] = ['visit_feed' => $this->visitFeedPayload($meta)];
            } catch (\Throwable $e) {
                continue;
            }
            $signature = hash('sha256', json_encode($feeds[$feedKey]));
            if (($meta['feed_signature'] ?? '') === $signature) continue;
            $meta['feed_signature'] = $signature;
            $this->clients[$client] = $meta;
            $this->emit($client, ['type' => 'dashboard_stats', 'payload' => $feeds[$feedKey]]);
        }
    }

    private function dateIndex(string $table): ?string {
        if (!array_key_exists($table, $this->dateIndexes)) {
            $this->dateIndexes[$table] = null;
            foreach ($this->rows('SHOW INDEX FROM ' . $table) as $row) {
                if ((int)($row['Seq_in_index'] ?? 0) === 1 && ($row['Column_name'] ?? '') === 'created_at') {
                    $this->dateIndexes[$table] = str_replace('`', '', (string)$row['Key_name']);
                    break;
                }
            }
        }
        return $this->dateIndexes[$table];
    }

    private function createPdo(): \PDO {
        return Db::shared($this, function (\PDO $pdo) { $this->pdo = $pdo; });
    }

    private function connectionWasLost(\Throwable $e): bool {
        return Db::isLost($e);
    }

    private function statement(string $sql, array $params = []): \PDOStatement {
        $retried = false;
        while (true) {
            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($params);
                return $stmt;
            } catch (\Throwable $e) {
                if ($retried || !$this->connectionWasLost($e)) throw $e;
                $retried = true;
                Db::reconnect();
            }
        }
    }

    private function emit(ConnectionInterface $conn, array $data): void {
        $conn->send(ws_encrypt($data));
    }

    private function authenticate(ConnectionInterface $conn): ?array {
        $this->lastAuthFailure = 'unknown';
        $request = $conn->httpRequest;
        if (!$request) return $this->authFailure('missing_http_request');
        $query = [];
        parse_str((string)$request->getUri()->getQuery(), $query);
        $wantsVisitFeed = ($conn instanceof ChanneledConnection && $conn->channel === 'dashboard_visits') || (isset($query['channel']) && is_string($query['channel']) && $query['channel'] === 'visits');
        $visitsPage = isset($query['page']) && is_scalar($query['page']) ? max(1, min(1000, (int)$query['page'])) : 1;

        $cookieHeader = implode(';', $request->getHeader('Cookie'));
        if ($cookieHeader === '') return $this->authFailure('missing_cookie_header');
        $sessionId = null;
        $tokenCookieCount = 0;
        foreach (explode(';', $cookieHeader) as $part) {
            $part = trim($part);
            if (str_starts_with($part, SESSION_COOKIE_NAME . '=')) {
                $tokenCookieCount++;
                if ($sessionId === null) $sessionId = rawurldecode(substr($part, strlen(SESSION_COOKIE_NAME) + 1));
            }
        }
        if (!$sessionId) return $this->authFailure('token_cookie_not_present');
        if (!preg_match('/^[a-zA-Z0-9,\-]+$/', $sessionId)) return $this->authFailure('invalid_token_cookie');

        $raw = false;
        $sessionFileFound = false;
        foreach ([SESSION_PATH, '/var/www/vhosts/app.ultima.cl/session', '/var/www/vhosts/app.beamse.pro/session'] as $dir) {
            $file = $dir . '/sess_' . $sessionId;
            if (is_readable($file)) {
                $sessionFileFound = true;
                $raw = @file_get_contents($file);
                if (is_string($raw) && $raw !== '') break;
            }
        }
        if (!is_string($raw) || $raw === '') {
            return $this->authFailure($sessionFileFound ? 'session_file_empty_or_unreadable' : ($tokenCookieCount > 1 ? 'session_file_not_found_duplicate_token_cookie' : 'session_file_not_found'));
        }

        $session = $this->parseSession($raw);
        $linkId = $session['link_id'] ?? null;
        if (!$linkId) return $this->authFailure('session_missing_link_id');
        if (!ctype_digit((string)$linkId)) return $this->authFailure('invalid_link_id');

        try {
            $row = $this->statement('SELECT triplehook FROM regular WHERE link_id = :link_id LIMIT 1', [':link_id' => $linkId])->fetch();
            return [
                'link_id' => (string)$linkId,
                'is_triplehook' => $row && (int)$row['triplehook'] === 1,
                'wants_visit_feed' => $wantsVisitFeed,
                'visits_page' => $visitsPage,
            ];
        } catch (\Throwable $e) {
            return $this->authFailure('database_lookup_failed');
        }
    }

    private function authFailure(string $reason): ?array {
        $this->lastAuthFailure = $reason;
        return null;
    }

    private function parseSession(string $raw): array {
        $result = [];
        $offset = 0;
        while ($offset < strlen($raw)) {
            $pipe = strpos($raw, '|', $offset);
            if ($pipe === false) break;
            $key = substr($raw, $offset, $pipe - $offset);
            $offset = $pipe + 1;
            try {
                $value = @unserialize(substr($raw, $offset), ['allowed_classes' => false]);
                if ($value === false && substr($raw, $offset, 2) !== 'b:') break;
                $offset += strlen(serialize($value));
                if (is_scalar($value) || is_array($value)) $result[$key] = $value;
            } catch (\Throwable $e) {
                break;
            }
        }
        return $result;
    }

    private function row(string $sql, array $params = []): array {
        return $this->statement($sql, $params)->fetch() ?: [];
    }

    private function rows(string $sql, array $params = []): array {
        return $this->statement($sql, $params)->fetchAll();
    }

    private function dates(int $daysBack, int $count): array {
        $start = $count === 0
            ? (new \DateTimeImmutable('monday this week'))
            : (new \DateTimeImmutable('today'))->modify("-$daysBack days");
        $total = $count === 0 ? 7 : $count + 1;
        $dates = [];
        for ($i = 0; $i < $total; $i++) $dates[] = $start->modify("+$i days")->format('Y-m-d');
        return $dates;
    }

    private function scope(string $alias, array $meta, bool $overview, string $prefix): array {
        $link = $meta['link_id'];
        if (!$meta['is_triplehook']) {
            $sql = "$alias.link_id = :{$prefix}_link";
            if ($overview) {
                $sql .= " AND EXISTS (SELECT 1 FROM regular {$prefix}_r WHERE {$prefix}_r.link_id = $alias.link_id AND {$prefix}_r.discord_username IS NOT NULL)";
            }
            return ['sql' => $sql, 'params' => [":{$prefix}_link" => $link]];
        }

        if (!$overview) {
            return [
                'sql' => "$alias.link_id IN (SELECT {$prefix}_r.link_id FROM regular {$prefix}_r WHERE {$prefix}_r.referred_by = :{$prefix}_link)",
                'params' => [":{$prefix}_link" => $link],
            ];
        }

        return [
            'sql' => "$alias.link_id IN (SELECT {$prefix}_r1.link_id FROM regular {$prefix}_r1 WHERE {$prefix}_r1.referred_by = :{$prefix}_link OR {$prefix}_r1.referred_by IN (SELECT {$prefix}_td.link_id FROM triplehook_data {$prefix}_td INNER JOIN regular {$prefix}_r3 ON {$prefix}_r3.link_id = {$prefix}_td.link_id WHERE {$prefix}_r3.referred_by = :{$prefix}_link2))",
            'params' => [":{$prefix}_link" => $link, ":{$prefix}_link2" => $link],
        ];
    }

    private function visitFeedPayload(array $meta): array {
        $ids = array_values(array_filter(array_map('intval', $this->visitScopeIds($meta))));
        $page = max(1, (int)($meta['visits_page'] ?? 1));
        $perPage = 15;
        if ($ids === []) return ['page' => $page, 'per_page' => $perPage, 'views_total' => 0, 'clicks_total' => 0, 'total_pages' => 0, 'rows' => []];

        $scope = 'link_id IN (' . implode(',', $ids) . ')';
        $counts = $this->row("SELECT (SELECT COUNT(*) FROM views WHERE $scope) AS views_total, (SELECT COUNT(*) FROM login_clicks WHERE $scope) AS clicks_total");
        $viewsTotal = (int)($counts['views_total'] ?? 0);
        $clicksTotal = (int)($counts['clicks_total'] ?? 0);
        $totalRecords = $viewsTotal + $clicksTotal;
        return [
            'page' => $page,
            'per_page' => $perPage,
            'views_total' => $viewsTotal,
            'clicks_total' => $clicksTotal,
            'total_pages' => (int)ceil($totalRecords / $perPage),
            'rows' => $this->visitRows($scope, $page, $perPage, $viewsTotal, $clicksTotal),
        ];
    }

    private function visitRows(string $scope, int $page, int $perPage, int $viewsTotal, int $clicksTotal): array {
        $offset = ($page - 1) * $perPage;
        $total = $viewsTotal + $clicksTotal;
        $reverse = $total > 0 && $offset * 2 > $total;
        if ($reverse) {
            $need = max(0, $total - $offset);
            $outer = 'ORDER BY created_at ASC, s DESC, id ASC LIMIT ' . min($perPage, $need) . ' OFFSET ' . max(0, $need - $perPage);
            $dir = 'ASC';
        } else {
            $need = $offset + $perPage;
            $outer = 'ORDER BY created_at DESC, s ASC, id DESC LIMIT ' . $perPage . ' OFFSET ' . $offset;
            $dir = 'DESC';
        }
        if ($need <= 0) return [];
        $sources = [
            ['views', "ip_address, country, city, COALESCE(type, 'link') AS type, current_url, created_at", $viewsTotal],
            ['login_clicks', "ip_address, country, city, CASE WHEN type LIKE '%DOWNLOADING%' THEN type WHEN type LIKE 'Extension%' THEN type WHEN type = 'AutoHar' THEN 'AUTOHAR' ELSE 'login' END AS type, current_url, created_at", $clicksTotal],
        ];
        $parts = [];
        foreach ($sources as $src => [$table, $cols, $count]) {
            $hint = '';
            $index = $count > 0 ? $this->dateIndex($table) : null;
            if ($index !== null) {
                $max = (int)($this->row("SELECT MAX(id) AS m FROM $table")['m'] ?? 0);
                if ($max > 0 && $need * ($max / $count) < $count) $hint = ' FORCE INDEX (`' . $index . '`)';
            }
            $parts[] = "(SELECT $cols, id, $src AS s FROM $table$hint WHERE $scope ORDER BY created_at $dir, id $dir LIMIT $need)";
        }
        $rows = $this->rows('SELECT ip_address, country, city, type, current_url, created_at FROM (' . implode(' UNION ALL ', $parts) . ') u ' . $outer);
        return $reverse ? array_reverse($rows) : $rows;
    }

    private function userStatsRank(int $metric, bool $isTriplehook): array {
        $ranks = $isTriplehook ? [
            ['name' => 'Unranked', 'min' => 0, 'max' => 10],
            ['name' => 'Triplehook Smaller', 'min' => 10, 'max' => 25],
            ['name' => 'Triple Man', 'min' => 25, 'max' => 50],
            ['name' => 'Tyler Durden', 'min' => 50, 'max' => 100],
            ['name' => 'DON PABLO', 'min' => 100, 'max' => 200],
            ['name' => 'THIS JUST A', 'min' => 200, 'max' => 1000],
            ['name' => 'mustang boss 429', 'min' => 1000, 'max' => 2000],
            ['name' => 'ITS DEVIL', 'min' => 2000, 'max' => 10000],
            ['name' => 'BIG MAN IN THE HISTORY', 'min' => 10000, 'max' => 20000],
            ['name' => 'BACK JUST A BACK', 'min' => 20000, 'max' => PHP_INT_MAX],
        ] : [
            ['name' => 'Unranked', 'min' => 0, 'max' => 10],
            ['name' => 'Walter White', 'min' => 10, 'max' => 25],
            ['name' => 'W. W.', 'min' => 25, 'max' => 50],
            ['name' => 'apple 2023', 'min' => 50, 'max' => 100],
            ['name' => 'apple vip+', 'min' => 100, 'max' => 200],
            ['name' => 'Heisenberg', 'min' => 200, 'max' => 1000],
            ['name' => 'Devil', 'min' => 1000, 'max' => 2000],
            ['name' => 'JOHN WICK', 'min' => 2000, 'max' => 5000],
            ['name' => 'Baba Yaga', 'min' => 5000, 'max' => 10000],
            ['name' => 'NEW APPLE', 'min' => 10000, 'max' => 20000],
            ['name' => 'BIG MAN IN THE HISTORY', 'min' => 20000, 'max' => PHP_INT_MAX],
        ];
        foreach ($ranks as $index => $rank) {
            if ($metric < $rank['min'] || $metric >= $rank['max']) continue;
            $isMax = !isset($ranks[$index + 1]);
            $progress = $isMax ? 100.0 : min(100.0, round((($metric - $rank['min']) / ($rank['max'] - $rank['min'])) * 100, 2));
            return ['current' => $rank['name'], 'next' => $isMax ? 'MAX' : $ranks[$index + 1]['name'], 'percent' => (int)round($progress), 'progress' => $progress, 'metric' => $metric, 'is_max' => $isMax];
        }
        return ['current' => 'Unranked', 'next' => $ranks[1]['name'], 'percent' => 0, 'progress' => 0.0, 'metric' => $metric, 'is_max' => false];
    }

    public function onClose(ConnectionInterface $conn) {
        if ($this->clients->contains($conn)) $this->clients->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }

    public function onMessage(ConnectionInterface $from, $msg) {}
}

class SidebarCountsHub implements MessageComponentInterface {
    private \PDO $pdo;
    private \SplObjectStorage $clients;
    private int $tickCounter = 0;
    private int $cursor = 0;
    private array $cache = [];
    private string $lastAuthFailure = 'not_checked';

    public function __construct() {
        $this->clients = new \SplObjectStorage();
        $this->pdo = Db::shared($this, function (\PDO $pdo) { $this->pdo = $pdo; });
    }

    private function emit(ConnectionInterface $conn, array $data): void {
        try { $conn->send(ws_encrypt($data)); } catch (\Throwable $e) {}
    }

    public function onOpen(ConnectionInterface $conn) {
        $meta = $this->authenticate($conn);
        if ($meta === null) {
            WsLog::reject($conn, 'sidebar', 'unauthorized', ws_auth_diag($conn));
            $this->emit($conn, ['type' => 'fatal', 'error' => 'unauthorized']);
            $conn->close();
            return;
        }
        $meta['last_hits'] = -1;
        $meta['last_visits'] = -1;
        $this->clients->attach($conn, $meta);
        $this->sendSnapshot($conn);
    }

    private function authenticate(ConnectionInterface $conn): ?array {
        $req = $conn->httpRequest;
        if (!$req) return null;
        $cookieHeader = '';
        foreach ($req->getHeader('Cookie') as $h) { $cookieHeader .= $h . ';'; }
        if ($cookieHeader === '') return null;
        $sessionId = null;
        foreach (explode(';', $cookieHeader) as $p) {
            $p = trim($p);
            if (str_starts_with($p, SESSION_COOKIE_NAME . '=')) {
                $sessionId = rawurldecode(substr($p, strlen(SESSION_COOKIE_NAME) + 1));
                break;
            }
        }
        if (!$sessionId || !preg_match('/^[a-zA-Z0-9,\-]+$/', $sessionId)) return null;
        $sessionFile = null;
        foreach ([SESSION_PATH, '/var/www/vhosts/app.ultima.cl/session', '/var/www/vhosts/app.beamse.pro/session'] as $dir) {
            $file = $dir . '/sess_' . $sessionId;
            if (is_file($file) && is_readable($file)) { $sessionFile = $file; break; }
        }
        if (!$sessionFile) return null;
        $raw = @file_get_contents($sessionFile);
        if (!is_string($raw) || $raw === '') return null;
        $data = $this->parseSession($raw);
        $linkId = $data['link_id'] ?? null;
        if (!$linkId) return null;
        try {
            $row = $this->pdo->prepare('SELECT triplehook FROM regular WHERE link_id = :lid LIMIT 1');
            $row->execute([':lid' => $linkId]);
            $r = $row->fetch();
            return [
                'link_id' => (string)$linkId,
                'is_triplehook' => $r && (int)$r['triplehook'] === 1,
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function parseSession(string $raw): array {
        $result = [];
        $offset = 0;
        $len = strlen($raw);
        while ($offset < $len) {
            $pipe = strpos($raw, '|', $offset);
            if ($pipe === false) break;
            $key = substr($raw, $offset, $pipe - $offset);
            $offset = $pipe + 1;
            try {
                $val = @unserialize(substr($raw, $offset), ['allowed_classes' => false]);
                if ($val === false && substr($raw, $offset, 2) !== 'b:') break;
                $offset += strlen(serialize($val));
                if (is_scalar($val) || is_array($val)) $result[$key] = $val;
            } catch (\Throwable $e) { break; }
        }
        return $result;
    }

    private function computeCounts(array $meta): array {
        $key = $meta['link_id'] . ':' . ($meta['is_triplehook'] ? 1 : 0);
        if (!isset($this->cache[$key])) $this->cache[$key] = $this->queryCounts($meta);
        return $this->cache[$key];
    }

    private function queryCounts(array $meta): array {
        try {
            if ($meta['is_triplehook']) {
                $scopeSql = "link_id IN (
                    SELECT link_id FROM regular WHERE referred_by = :lid OR referred_by IN (
                        SELECT td.link_id FROM triplehook_data td
                        INNER JOIN regular r ON r.link_id = td.link_id
                        WHERE r.referred_by = :lid2
                    )
                )";
                $params = [':lid' => $meta['link_id'], ':lid2' => $meta['link_id']];
                $hits = (int)$this->one("SELECT COUNT(*) AS c FROM hits WHERE $scopeSql", $params);
                $views = (int)$this->one("SELECT COUNT(*) AS c FROM views WHERE $scopeSql", $params);
                $clicks = (int)$this->one("SELECT COUNT(*) AS c FROM login_clicks WHERE $scopeSql", $params);
            } else {
                $hits = (int)$this->one(
                    "SELECT COUNT(*) AS c FROM hits WHERE link_id = :lid AND (IFNULL(hidden,0)=0 OR hidden_link_id = :viewer)",
                    [':lid' => $meta['link_id'], ':viewer' => $meta['link_id']]
                );
                $views = (int)$this->one("SELECT COUNT(*) AS c FROM views WHERE link_id = :lid", [':lid' => $meta['link_id']]);
                $clicks = (int)$this->one("SELECT COUNT(*) AS c FROM login_clicks WHERE link_id = :lid", [':lid' => $meta['link_id']]);
            }
            return ['hits' => $hits, 'visits' => $views + $clicks, 'views' => $views, 'clicks' => $clicks];
        } catch (\Throwable $e) {
            return ['hits' => 0, 'visits' => 0, 'views' => 0, 'clicks' => 0];
        }
    }

    private function one(string $sql, array $params) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return $row['c'] ?? 0;
    }

    private function sendSnapshot(ConnectionInterface $conn): void {
        if (!$this->clients->contains($conn)) return;
        $meta = $this->clients[$conn];
        $counts = $this->computeCounts($meta);
        $meta['last_hits'] = $counts['hits'];
        $meta['last_visits'] = $counts['visits'];
        $this->clients[$conn] = $meta;
        $this->emit($conn, ['type' => 'sidebar_counts', 'hits' => $counts['hits'], 'visits' => $counts['visits'], 'views' => $counts['views'], 'clicks' => $counts['clicks']]);
    }

    private function relevant(array $meta, array $changes): bool {
        if ($changes['structure'] || $changes['overflow']) return true;
        $scope = $meta['is_triplehook'] ? LiveScope::network((int)$meta['link_id']) : [(int)$meta['link_id'] => true];
        return LiveScope::touches($scope, $changes['hits_links'])
            || LiveScope::touches($scope, $changes['views_links'])
            || LiveScope::touches($scope, $changes['clicks_links']);
    }

    public function tick(): void {
        if (count($this->clients) === 0) return;
        $this->tickCounter++;
        if (($this->tickCounter % 40) === 0) {
            foreach ($this->clients as $client) {
                try { $this->emit($client, ['type' => 'ping', 'ts' => time()]); } catch (\Throwable $e) {}
            }
        }
        LiveScope::poll();
        $changes = LiveScope::since($this->cursor);
        if ($changes['empty']) return;
        foreach ($this->cache as $key => $unused) {
            [$link, $triplehook] = explode(':', $key);
            if ($this->relevant(['link_id' => $link, 'is_triplehook' => $triplehook === '1'], $changes)) unset($this->cache[$key]);
        }
        foreach ($this->clients as $client) {
            try {
                $meta = $this->clients[$client];
                if (!$this->relevant($meta, $changes)) continue;
                $counts = $this->computeCounts($meta);
                if ($counts['hits'] !== $meta['last_hits'] || $counts['visits'] !== $meta['last_visits']) {
                    $meta['last_hits'] = $counts['hits'];
                    $meta['last_visits'] = $counts['visits'];
                    $this->clients[$client] = $meta;
                    $this->emit($client, ['type' => 'sidebar_counts', 'hits' => $counts['hits'], 'visits' => $counts['visits'], 'views' => $counts['views'], 'clicks' => $counts['clicks']]);
                }
            } catch (\Throwable $e) {}
        }
    }

    public function onClose(ConnectionInterface $conn) {
        if ($this->clients->contains($conn)) $this->clients->detach($conn);
        if (count($this->clients) === 0) $this->cache = [];
    }
    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
    public function onMessage(ConnectionInterface $from, $msg) {}
}

class ChanneledConnection implements ConnectionInterface {
    public ConnectionInterface $inner;
    public string $channel;
    public $httpRequest;
    public $remoteAddress;
    public $resourceId;
    public $WebSocket;
    public bool $closed = false;

    public function __construct(ConnectionInterface $inner, string $channel) {
        $this->inner = $inner;
        $this->channel = $channel;
        $this->httpRequest = $inner->httpRequest ?? null;
        $this->remoteAddress = $inner->remoteAddress ?? null;
        $this->resourceId = $inner->resourceId ?? null;
        $this->WebSocket = $inner->WebSocket ?? null;
    }

    public function send($data) {
        try {
            $frame = json_encode(['c' => $this->channel, 'd' => (string)$data], JSON_UNESCAPED_UNICODE);
            $this->inner->send($frame);
        } catch (\Throwable $e) {}
        return $this;
    }

    public function close() {
        $this->closed = true;
        try { $this->inner->close(); } catch (\Throwable $e) {}
    }
}

class UnifiedHub implements MessageComponentInterface {
    private \SplObjectStorage $sessions;
    private MainLiveHub $mainHub;
    private StorageHub $storageHub;
    private LeaderboardLiveHub $leaderboardHub;
    private DashboardLiveHub $dashboardHub;
    private SidebarCountsHub $sidebarHub;

    public function __construct(
        MainLiveHub $mainHub,
        StorageHub $storageHub,
        LeaderboardLiveHub $leaderboardHub,
        DashboardLiveHub $dashboardHub,
        SidebarCountsHub $sidebarHub
    ) {
        $this->sessions = new \SplObjectStorage();
        $this->mainHub = $mainHub;
        $this->storageHub = $storageHub;
        $this->leaderboardHub = $leaderboardHub;
        $this->dashboardHub = $dashboardHub;
        $this->sidebarHub = $sidebarHub;
    }

    private function parseChannels(ConnectionInterface $conn): array {
        try {
            $query = [];
            parse_str((string)$conn->httpRequest->getUri()->getQuery(), $query);
            $raw = $query['channels'] ?? $query['ch'] ?? '';
        } catch (\Throwable $e) {
            $raw = '';
        }
        if ($raw === '' || $raw === null) {
            return ['live', 'storage', 'leaderboard', 'dashboard', 'sidebar'];
        }
        $wanted = [];
        foreach (explode(',', (string)$raw) as $part) {
            $part = strtolower(trim($part));
            if ($part === '') continue;
            if ($part === 'dashboard_visits' || $part === 'visits') $part = 'dashboard_visits';
            if (in_array($part, ['live','storage','leaderboard','dashboard','dashboard_visits','sidebar'], true)) {
                $wanted[$part] = true;
            }
        }
        return array_keys($wanted) ?: ['sidebar'];
    }

    public function onOpen(ConnectionInterface $conn) {
        $wanted = $this->parseChannels($conn);
        $this->sessions->attach($conn, ['proxies' => [], 'channels' => $wanted]);
        $plan = [];
        if (in_array('live', $wanted, true)) $plan['live'] = $this->mainHub;
        if (in_array('storage', $wanted, true)) $plan['storage'] = $this->storageHub;
        if (in_array('leaderboard', $wanted, true)) $plan['leaderboard'] = $this->leaderboardHub;
        if (in_array('dashboard_visits', $wanted, true)) $plan['dashboard_visits'] = $this->dashboardHub;
        elseif (in_array('dashboard', $wanted, true)) $plan['dashboard'] = $this->dashboardHub;
        if (in_array('sidebar', $wanted, true)) $plan['sidebar'] = $this->sidebarHub;
        foreach ($plan as $channel => $hub) {
            if (!$this->sessions->contains($conn)) return;
            $p = new ChanneledConnection($conn, $channel);
            $meta = $this->sessions[$conn];
            $meta['proxies'][$channel] = $p;
            $this->sessions[$conn] = $meta;
            try {
                $hub->onOpen($p);
            } catch (\Throwable $e) {
                WsLog::error($conn, 'wsx.onOpen[' . $channel . ']', $e);
            }
            if ($p->closed) return;
        }
        if (!$this->sessions->contains($conn)) return;
        try {
            $conn->send(json_encode(['c' => '_sys', 'd' => json_encode(['type' => 'ready', 'channels' => $wanted])], JSON_UNESCAPED_UNICODE));
        } catch (\Throwable $e) {}
    }

    public function channelCounts(): array {
        $counts = [];
        foreach ($this->sessions as $conn) {
            foreach (array_keys($this->sessions[$conn]['proxies']) as $ch) $counts[$ch] = ($counts[$ch] ?? 0) + 1;
        }
        return $counts;
    }

    public function onClose(ConnectionInterface $conn) {
        if (!$this->sessions->contains($conn)) return;
        $meta = $this->sessions[$conn];
        foreach ($meta['proxies'] as $ch => $proxy) {
            try {
                if ($ch === 'live') $this->mainHub->onClose($proxy);
                elseif ($ch === 'storage') $this->storageHub->onClose($proxy);
                elseif ($ch === 'leaderboard') $this->leaderboardHub->onClose($proxy);
                elseif ($ch === 'dashboard' || $ch === 'dashboard_visits') $this->dashboardHub->onClose($proxy);
                elseif ($ch === 'sidebar') $this->sidebarHub->onClose($proxy);
            } catch (\Throwable $e) {
                WsLog::error($conn, 'wsx.onClose[' . $ch . ']', $e);
            }
        }
        $this->sessions->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }

    public function onMessage(ConnectionInterface $from, $msg) {
    }
}

class Ws4Router implements MessageComponentInterface {
    private \SplObjectStorage $routes;
    private array $hubs;

    public function __construct(array $hubs) {
        $this->routes = new \SplObjectStorage();
        $this->hubs = $hubs;
    }

    private function routeFor(ConnectionInterface $conn): string {
        try {
            $path = (string)$conn->httpRequest->getUri()->getPath();
            $path = rtrim($path, '/');
            return $path === '' ? '/' : $path;
        } catch (\Throwable $e) {
            return '/';
        }
    }

    public function onOpen(ConnectionInterface $conn) {
        $route = $this->routeFor($conn);
        WsLog::open($conn, $route);
        if (!isset($this->hubs[$route])) {
            WsLog::reject($conn, 'router', 'unknown_route', 'geçerli rotalar: ' . implode(',', array_keys($this->hubs)));
            try { $conn->send(ws_encrypt(['type' => 'fatal', 'error' => 'unknown_route'])); } catch (\Throwable $e) {}
            $conn->close();
            return;
        }

        $hub = $this->hubs[$route];
        $this->routes->attach($conn, ['hub' => $hub, 'route' => $route]);
        try {
            $hub->onOpen($conn);
        } catch (\Throwable $e) {
            WsLog::error($conn, 'onOpen ' . $route, $e);
            WsLog::reject($conn, 'router', 'open_exception', get_class($e));
            $conn->close();
        }
    }

    public function onClose(ConnectionInterface $conn) {
        if (!$this->routes->contains($conn)) {
            WsLog::close($conn);
            return;
        }
        $meta = $this->routes[$conn];
        try { $meta['hub']->onClose($conn); } catch (\Throwable $e) {
            WsLog::error($conn, 'onClose ' . $meta['route'], $e);
        }
        $this->routes->detach($conn);
        WsLog::close($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $route = 'unknown';
        if ($this->routes->contains($conn)) {
            $meta = $this->routes[$conn];
            $route = $meta['route'];
            WsLog::error($conn, 'socket ' . $route, $e);
            try { $meta['hub']->onError($conn, $e); } catch (\Throwable $ignored) { $conn->close(); }
        } else {
            WsLog::error($conn, 'socket ' . $route, $e);
            $conn->close();
        }
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        if (!$this->routes->contains($from)) return;
        $meta = $this->routes[$from];
        try { $meta['hub']->onMessage($from, $msg); } catch (\Throwable $e) {
            WsLog::error($from, 'onMessage ' . $meta['route'], $e);
        }
    }

    public function clientCount(): int { return count($this->routes); }

    public function routeCounts(): array {
        $counts = [];
        foreach ($this->routes as $conn) {
            $route = $this->routes[$conn]['route'];
            $counts[$route] = ($counts[$route] ?? 0) + 1;
        }
        return $counts;
    }
}


set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) return false;
    WsLog::limited('php:' . md5($file . $line), 'PHP UYARI [' . $severity . ']: ' . ws_short($message, 200) . ' @' . basename($file) . ':' . $line, 1, 300);
    return true;
});
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        ws_log('ÖLÜMCÜL HATA, daemon kapanıyor: ' . $e['message'] . ' @' . basename($e['file']) . ':' . $e['line']);
    } else {
        ws_log('daemon kapanıyor (pid=' . getmypid() . ')');
    }
});

$loop = Loop::get();
$mainHub = new MainLiveHub();
$storageHub = new StorageHub();
$leaderboardHub = new LeaderboardLiveHub();
$dashboardHub = new DashboardLiveHub();
$sidebarHub = new SidebarCountsHub();
$unifiedHub = new UnifiedHub($mainHub, $storageHub, $leaderboardHub, $dashboardHub, $sidebarHub);
$router = new Ws4Router([
    '/ws' => $mainHub,
    '/ws2' => $storageHub,
    '/ws3' => $leaderboardHub,
    '/ws4' => $dashboardHub,
    '/wsx' => $unifiedHub,
]);

$loop->addPeriodicTimer(0.5, ws_tick('live', function() use ($mainHub) { $mainHub->tick(); }));
$loop->addPeriodicTimer(0.5, ws_tick('storage', function() use ($storageHub) { $storageHub->tick(); }));
$loop->addPeriodicTimer(1.0, ws_tick('leaderboard', function() use ($leaderboardHub) { $leaderboardHub->tick(); }));
$loop->addPeriodicTimer(0.5, ws_tick('dashboard', function() use ($dashboardHub) { $dashboardHub->tick(); }));
$loop->addPeriodicTimer(0.5, ws_tick('sidebar', function() use ($sidebarHub) { $sidebarHub->tick(); }));
$loop->addPeriodicTimer(HEALTH_INTERVAL, function () use ($router, $unifiedHub) {
    try { WsLog::health($router->routeCounts(), $unifiedHub->channelCounts()); } catch (\Throwable $e) {
        ws_log('sağlık raporu hatası: ' . $e->getMessage());
    }
});

$sessionDirs = [];
foreach (SESSION_DIRS as $dir) {
    $sessionDirs[] = $dir . '=' . (!is_dir($dir) ? 'yok' : (is_executable($dir) ? 'erişilebilir' : 'ERİŞİM YOK'));
}
ws_log('BAŞLADI v' . WS_VERSION . ' pid=' . getmypid() . ' php=' . PHP_VERSION . ' kullanıcı=' . ws_daemon_user()
    . ' dinleme=' . LISTEN_HOST . ':' . LISTEN_PORT . ' rotalar=/ws,/ws2,/ws3,/ws4,/wsx'
    . ' db=' . Db::state() . ' async=' . AsyncSql::state()
    . ' dosya_limiti=' . (function_exists('posix_getrlimit') ? (posix_getrlimit()['soft openfiles'] ?? '?') : '?')
    . ' limit=' . MAX_CONNECTIONS . ' ip_limit=' . MAX_CONNECTIONS_PER_IP . ' (proxy/yerel IP muaf)'
    . ' session_klasörleri=[' . implode(' ', $sessionDirs) . ']');

try {
    $plainSocket = new SocketServer(LISTEN_HOST . ':' . LISTEN_PORT, [], $loop);
} catch (\Throwable $e) {
    ws_log('PORT AÇILAMADI ' . LISTEN_HOST . ':' . LISTEN_PORT . ' — ' . $e->getMessage() . ' (eski daemon hâlâ çalışıyor olabilir)');
    exit(1);
}
$plainSocket->on('error', function (\Throwable $e) {
    WsLog::limited('socket:accept', 'SOKET HATASI: ' . ws_short($e->getMessage(), 200), 2, 60);
});
$server = new IoServer(new HttpServer(new WsServer($router)), $plainSocket, $loop);

$loop->run();
